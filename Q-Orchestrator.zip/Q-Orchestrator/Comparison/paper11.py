import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches

# --- A Simple Optimization Problem and Operators ---

def evaluate_fitness(population):
    """Lower is better. Fitness is the average distance from the origin."""
    return np.mean(np.linalg.norm(population, axis=1))

def move_towards_origin(population, strength=0.5):
    """An 'exploitation' operator that moves points closer to the goal."""
    return population * (1 - strength)

def add_random_noise(population, strength=0.1):
    """An 'exploration' operator to prevent getting stuck."""
    return population + np.random.normal(0, strength, population.shape)

# --- Approach 1: Our proposed Orchestrator-Based Ensemble Method ---

def orchestrator_approach(population):
    """
    Applies a fixed sequence of operators to the entire population.
    This is analogous to Our proposed hybrid framework.
    """
    population = move_towards_origin(population)
    population = add_random_noise(population)
    return population

# --- Approach 2: DRL-Based Adaptive Selection (Conceptual) ---

def mock_drl_agent_selector(solution):
    """
    This is a placeholder for the trained Deep Q-Network from the paper.
    It returns the name of the chosen operator for visualization purposes.
    """
    distance_from_origin = np.linalg.norm(solution)
    if distance_from_origin > 1.0:
        return 'exploit'  # Far away -> Choose exploitation
    else:
        return 'explore'  # Close by -> Choose exploration

def drl_adaptive_selection_approach(population):
    """
    For each solution, asks the DRL agent to select the best operator,
    then applies only that operator.
    """
    new_population = np.zeros_like(population)
    operator_choices = [] # Store choices for visualization
    for i, solution in enumerate(population):
        choice = mock_drl_agent_selector(solution)
        operator_choices.append(choice)
        
        if choice == 'exploit':
            selected_operator = move_towards_origin
        else:
            selected_operator = add_random_noise
            
        new_population[i] = selected_operator(np.array([solution]))[0]
        
    return new_population, operator_choices

# --- Simulation and Visualization ---

if __name__ == '__main__':
    iterations = 20
    initial_population = np.random.uniform(-5, 5, (50, 2))

    # --- Run Orchestrator Simulation ---
    pop_orchestrator = np.copy(initial_population)
    history_orchestrator = [evaluate_fitness(pop_orchestrator)]
    for _ in range(iterations):
        pop_orchestrator = orchestrator_approach(pop_orchestrator)
        history_orchestrator.append(evaluate_fitness(pop_orchestrator))

    # --- Run DRL Simulation ---
    pop_drl = np.copy(initial_population)
    history_drl = [evaluate_fitness(pop_drl)]
    final_drl_choices = []
    for i in range(iterations):
        pop_drl, choices = drl_adaptive_selection_approach(pop_drl)
        history_drl.append(evaluate_fitness(pop_drl))
        if i == iterations - 1:
            final_drl_choices = choices

    # --- Create the 2x2 Visualization Dashboard ---
    fig, axes = plt.subplots(2, 2, figsize=(14, 12)) # Reduced figure size
    fig.suptitle("Comparative Analysis of Optimization Philosophies", fontsize=20)

    # 1. Fitness History (Top-Left)
    ax = axes[0, 0]
    ax.plot(history_orchestrator, 'o-', label='Our proposed Orchestrator (Ensemble)', color='blue')
    ax.plot(history_drl, 's-', label='DRL Approach (Adaptive Selection)', color='red')
    ax.set_title("1. Fitness Over Time", fontsize=14)
    ax.set_xlabel("Iteration")
    ax.set_ylabel("Average Fitness (Lower is Better)")
    ax.legend()
    ax.grid(True)

    # 2. Orchestrator Final Population (Top-Right)
    ax = axes[0, 1]
    ax.scatter(pop_orchestrator[:, 0], pop_orchestrator[:, 1], c='blue', alpha=0.7)
    ax.add_patch(patches.Circle((0, 0), radius=0.1, color='black', label='Target'))
    ax.set_title("2. Orchestrator - Final Population Distribution", fontsize=14)
    ax.set_xlabel("X-axis")
    ax.set_ylabel("Y-axis")
    ax.set_xlim(-5, 5)
    ax.set_ylim(-5, 5)
    ax.grid(True)
    ax.set_aspect('equal', adjustable='box')

    # 3. DRL Final Population (Bottom-Left)
    ax = axes[1, 0]
    ax.scatter(pop_drl[:, 0], pop_drl[:, 1], c='red', alpha=0.7)
    ax.add_patch(patches.Circle((0, 0), radius=0.1, color='black', label='Target'))
    ax.set_title("3. DRL - Final Population Distribution", fontsize=14)
    ax.set_xlabel("X-axis")
    ax.set_ylabel("Y-axis")
    ax.set_xlim(-5, 5)
    ax.set_ylim(-5, 5)
    ax.grid(True)
    ax.set_aspect('equal', adjustable='box')
    
    # 4. DRL Operator Selection Visualization (Bottom-Right)
    ax = axes[1, 1]
    colors = ['green' if choice == 'explore' else 'purple' for choice in final_drl_choices]
    scatter = ax.scatter(pop_drl[:, 0], pop_drl[:, 1], c=colors, alpha=0.7)
    ax.set_title("4. DRL - Final Operator Selection", fontsize=14)
    ax.set_xlabel("X-axis")
    ax.set_ylabel("Y-axis")
    ax.set_xlim(-5, 5)
    ax.set_ylim(-5, 5)
    ax.grid(True)
    ax.set_aspect('equal', adjustable='box')
    # Custom legend for colors
    legend_elements = [
        patches.Patch(facecolor='purple', edgecolor='purple', label='Exploit (Move to Origin)'),
        patches.Patch(facecolor='green', edgecolor='green', label='Explore (Add Noise)')
    ]
    ax.legend(handles=legend_elements, loc='upper right')

    # Use tight_layout with padding to ensure spacing is clean
    plt.tight_layout(pad=3.0, rect=[0, 0, 1, 0.95])
    plt.show()
