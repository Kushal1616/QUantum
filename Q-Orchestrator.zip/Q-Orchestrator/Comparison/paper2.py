import pennylane as qml
from pennylane import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import minimize

# --- The Shared VQE Problem: Ground State of H2 ---
# FIX: Switched from H2O (14 qubits) to H2 (4 qubits) for feasible runtime.

# Define the molecular structure and Hamiltonian
symbols = ["H", "H"]
coordinates = np.array([0.0, 0.0, -0.6614, 0.0, 0.0, 0.6614])
hamiltonian, n_qubits = qml.qchem.molecular_hamiltonian(symbols, coordinates)
true_ground_energy = -1.136189 # Known ground state energy for H2

print(f"Problem: Find ground state energy of H2 ({n_qubits} qubits).")
print(f"True Ground State Energy: {true_ground_energy:.4f} Ha")
print("-" * 50)

dev = qml.device("default.qubit", wires=n_qubits)

# --- Approach 1: Your Orchestrator (Optimizing a Fixed, Good Ansatz) ---

def run_orchestrator_approach():
    """
    Represents your approach: take a well-known, fixed circuit structure
    and use a powerful optimizer to find the best parameters.
    """
    print("\n>>> Running Your Orchestrator-Based Approach...")
    
    ansatz = qml.templates.AllSinglesDoubles
    n_electrons = 2 # H2 has 2 electrons
    
    hf_state = qml.qchem.hf_state(n_electrons, n_qubits)
    
    singles, doubles = qml.qchem.excitations(n_electrons, n_qubits)
    n_params = len(singles) + len(doubles)
    
    @qml.qnode(dev)
    def cost_function(params):
        qml.BasisState(hf_state, wires=range(n_qubits))
        ansatz(params, wires=range(n_qubits), hf_state=hf_state, singles=singles, doubles=doubles)
        return qml.expval(hamiltonian)

    initial_params = np.random.uniform(0, 2 * np.pi, n_params)

    # Use a powerful, gradient-free optimizer
    result = minimize(cost_function, initial_params, method="COBYLA", options={'maxiter': 150})
    
    final_energy = result.fun
    print(f"Orchestrator Complete. Final Energy: {final_energy:.4f} Ha")
    
    def circuit_for_drawing(params):
        qml.BasisState(hf_state, wires=range(n_qubits))
        ansatz(params, wires=range(n_qubits), hf_state=hf_state, singles=singles, doubles=doubles)
    qnode_drawer = qml.QNode(circuit_for_drawing, dev)
    
    return final_energy, qml.draw(qnode_drawer)(initial_params), result.nfev

# --- Approach 2: Differentiable Quantum Architecture Search (DQAS) ---

def softmax(x):
    """Numerically stable softmax function."""
    e_x = np.exp(x - np.max(x))
    return e_x / e_x.sum(axis=0)

def run_dqas_approach():
    """
    Represents the DQAS philosophy: learn both the structure and the parameters.
    """
    print("\n>>> Running Differentiable Quantum Architecture Search (DQAS)...")
    
    n_layers = 2 # Reduced layers for a smaller problem
    op_pool = [qml.RX, qml.RY, qml.RZ, qml.CNOT, qml.CZ]
    
    @qml.qnode(dev)
    def cost_function(weights):
        alpha = weights['alpha']
        theta = weights['theta']
        
        hf_state = qml.qchem.hf_state(2, n_qubits)
        qml.BasisState(hf_state, wires=range(n_qubits))
        
        for i in range(n_layers):
            for q in range(n_qubits):
                # Use the manually defined softmax function
                op_probs = softmax(alpha[i, q, :len(op_pool)-2])
                # FIX: Changed qml.ops.dot to qml.dot
                qml.dot(op_probs, [op(theta[i, q], wires=q) for op in op_pool if op.num_params > 0])
            
            for q in range(n_qubits - 1):
                qml.CNOT(wires=[q, q+1])

        return qml.expval(hamiltonian)
    
    # Mark the parameters as trainable for the optimizer
    weights = {
        'alpha': np.array(np.random.uniform(0, 0.1, (n_layers, n_qubits, len(op_pool)-2)), requires_grad=True),
        'theta': np.array(np.random.uniform(0, 2*np.pi, (n_layers, n_qubits)), requires_grad=True)
    }
    
    optimizer = qml.AdamOptimizer(stepsize=0.1)
    
    for i in range(100):
        weights, energy = optimizer.step_and_cost(cost_function, weights)
        if (i + 1) % 20 == 0:
            print(f"  DQAS Iteration {i+1}/100: Energy = {energy:.4f} Ha")
            
    final_alpha = weights['alpha']
    final_circuit_ops = []
    for i in range(n_layers):
        layer_ops = []
        for q in range(n_qubits):
            best_op_idx = np.argmax(final_alpha[i, q])
            layer_ops.append(op_pool[best_op_idx].__name__)
        final_circuit_ops.append(layer_ops)

    print(f"DQAS Complete. Final Energy: {energy:.4f} Ha")
    print("Discovered Architecture (Single-qubit gates per layer):")
    for i, layer in enumerate(final_circuit_ops):
        print(f"  Layer {i+1}: {layer}")

    return energy, 100

# --- Main Execution and Visualization ---
if __name__ == '__main__':
    orchestrator_energy, orchestrator_circuit_drawing, orchestrator_evals = run_orchestrator_approach()
    dqas_energy, dqas_evals = run_dqas_approach()

    fig = plt.figure(figsize=(12, 6))
    plt.suptitle("Conceptual Comparison: Orchestrator vs. DQAS", fontsize=16)

    labels = ['Our Orchestrator-based Approach', 'DQAS Approach']
    energies = [orchestrator_energy, dqas_energy]
    
    bars = plt.bar(labels, energies, color=['blue', 'purple'], alpha=0.8)
    plt.axhline(y=true_ground_energy, color='red', linestyle='--', label=f'True Ground Energy ({true_ground_energy:.2f} Ha)')
    
    plt.ylabel("Final Ground State Energy (Hartree)")
    plt.title("VQE Performance on H₂ Molecule")
    plt.legend()
    
    for i, bar in enumerate(bars):
        yval = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2.0, yval + 0.05, f"{yval:.3f} Ha", ha='center', va='bottom', color='black', fontsize=12)
        
    print("\n--- Circuit Diagram from Your Orchestrator's Fixed Ansatz ---")
    print(orchestrator_circuit_drawing)

    plt.show()
