import pennylane as qml
from pennylane import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import time
import warnings

# Suppress PennyLane warnings for cleaner output
warnings.filterwarnings("ignore", category=UserWarning)

# --- Step 1: Define the Quantum Problem (VQE for H₂) ---

# Define the H₂ molecule's properties
symbols = ["H", "H"]
# Equilibrium bond length for H₂
coordinates = np.array([0.0, 0.0, -0.6614, 0.0, 0.0, 0.6614])
# Define Hamiltonian, number of qubits, and number of electrons
H, qubits = qml.qchem.molecular_hamiltonian(symbols, coordinates)
electrons = 2
# Known ground state energy for H₂
TRUE_GROUND_STATE_ENERGY = -1.13618945

# Define the quantum circuit ansatz (a standard choice for chemistry)
def circuit_ansatz(params, wires):
    """A simple variational circuit for VQE."""
    # CORRECTION: Use qml.qchem.hf_state for robust state preparation
    hf_state = qml.qchem.hf_state(electrons, qubits)
    qml.BasisState(hf_state, wires=wires)
    for i in wires:
        qml.RY(params[i], wires=i)
    qml.CNOT(wires=[2, 3])
    qml.CNOT(wires=[2, 0])
    qml.CNOT(wires=[3, 1])

# --- Step 2: Implement the Optimizers ---

class GeneticAlgorithmOptimizer:
    """A simple Genetic Algorithm for VQE."""
    def __init__(self, population_size=20, generations=100, mutation_rate=0.1, crossover_rate=0.8):
        self.population_size = population_size
        self.generations = generations
        self.mutation_rate = mutation_rate
        self.crossover_rate = crossover_rate
        self.history = []

    def optimize(self, cost_fn, num_params):
        population = [np.random.uniform(0, 2 * np.pi, num_params) for _ in range(self.population_size)]
        
        for gen in range(self.generations):
            # Evaluate fitness (lower energy is better)
            fitness = [cost_fn(p) for p in population]
            
            # Find the best solution in the current generation
            best_fitness_idx = np.argmin(fitness)
            best_params = population[best_fitness_idx]
            best_energy = fitness[best_fitness_idx]
            self.history.append(best_energy)
            
            print(f"GA Gen {gen+1}/{self.generations}, Best Energy: {best_energy:.6f}")

            # Create the next generation
            new_population = [best_params] # Elitism

            while len(new_population) < self.population_size:
                # Selection (tournament)
                p1_idx, p2_idx = np.random.choice(range(self.population_size), 2, replace=False)
                parent1 = population[p1_idx] if fitness[p1_idx] < fitness[p2_idx] else population[p2_idx]
                
                p3_idx, p4_idx = np.random.choice(range(self.population_size), 2, replace=False)
                parent2 = population[p3_idx] if fitness[p3_idx] < fitness[p4_idx] else population[p4_idx]

                # Crossover
                if np.random.rand() < self.crossover_rate:
                    crossover_point = np.random.randint(1, num_params)
                    child = np.concatenate([parent1[:crossover_point], parent2[crossover_point:]])
                else:
                    child = parent1.copy()

                # Mutation
                if np.random.rand() < self.mutation_rate:
                    mutation_point = np.random.randint(0, num_params)
                    child[mutation_point] = np.random.uniform(0, 2 * np.pi)
                
                new_population.append(child)
            
            population = new_population
            
        return best_params, best_energy, self.history

class ParticleSwarmOptimizer:
    """A simple Particle Swarm Optimizer for VQE."""
    def __init__(self, n_particles=20, iterations=100, w=0.5, c1=0.8, c2=0.9):
        self.n_particles = n_particles
        self.iterations = iterations
        self.w = w    # Inertia
        self.c1 = c1  # Cognitive coefficient
        self.c2 = c2  # Social coefficient
        self.history = []

    def optimize(self, cost_fn, num_params):
        # Initialize particles
        particles_pos = [np.random.uniform(0, 2 * np.pi, num_params) for _ in range(self.n_particles)]
        particles_vel = [np.random.uniform(-1, 1, num_params) for _ in range(self.n_particles)]
        
        personal_best_pos = list(particles_pos)
        personal_best_fitness = [cost_fn(p) for p in particles_pos]
        
        global_best_idx = np.argmin(personal_best_fitness)
        global_best_pos = personal_best_pos[global_best_idx]
        global_best_fitness = personal_best_fitness[global_best_idx]
        
        for i in range(self.iterations):
            self.history.append(global_best_fitness)
            print(f"PSO Iteration {i+1}/{self.iterations}, Best Energy: {global_best_fitness:.6f}")
            
            for j in range(self.n_particles):
                # Update velocity
                r1, r2 = np.random.rand(2)
                cognitive_vel = self.c1 * r1 * (personal_best_pos[j] - particles_pos[j])
                social_vel = self.c2 * r2 * (global_best_pos - particles_pos[j])
                particles_vel[j] = self.w * particles_vel[j] + cognitive_vel + social_vel
                
                # Update position
                particles_pos[j] += particles_vel[j]
                
                # Evaluate new fitness
                current_fitness = cost_fn(particles_pos[j])
                
                # Update personal best
                if current_fitness < personal_best_fitness[j]:
                    personal_best_fitness[j] = current_fitness
                    personal_best_pos[j] = particles_pos[j]
            
            # Update global best
            current_best_idx = np.argmin(personal_best_fitness)
            if personal_best_fitness[current_best_idx] < global_best_fitness:
                global_best_fitness = personal_best_fitness[current_best_idx]
                global_best_pos = personal_best_pos[current_best_idx]

        return global_best_pos, global_best_fitness, self.history


class ProposedOrchestrator:
    """A representative implementation of the paper's hybrid orchestrator."""
    def __init__(self, population_size=20, iterations=100):
        self.population_size = population_size
        self.iterations = iterations
        self.history = []

    def optimize(self, cost_fn, num_params):
        # Simplified hybrid of GA and PSO for demonstration
        
        # PSO components
        particles_pos = [np.random.uniform(0, 2 * np.pi, num_params) for _ in range(self.population_size)]
        particles_vel = [np.random.uniform(-1, 1, num_params) for _ in range(self.population_size)]
        personal_best_pos = list(particles_pos)
        personal_best_fitness = [cost_fn(p) for p in particles_pos]
        
        global_best_idx = np.argmin(personal_best_fitness)
        global_best_pos = personal_best_pos[global_best_idx]
        global_best_fitness = personal_best_fitness[global_best_idx]

        for i in range(self.iterations):
            self.history.append(global_best_fitness)
            print(f"Orchestrator Iteration {i+1}/{self.iterations}, Best Energy: {global_best_fitness:.6f}")
            
            # --- PSO Step ---
            w, c1, c2 = 0.5, 0.8, 0.9
            for j in range(self.population_size):
                r1, r2 = np.random.rand(2)
                cognitive_vel = c1 * r1 * (personal_best_pos[j] - particles_pos[j])
                social_vel = c2 * r2 * (global_best_pos - particles_pos[j])
                particles_vel[j] = w * particles_vel[j] + cognitive_vel + social_vel
                particles_pos[j] += particles_vel[j]

            # --- GA Step (Crossover and Mutation on a subset) ---
            mutation_rate, crossover_rate = 0.1, 0.8
            for j in range(self.population_size):
                # Crossover with global best
                if np.random.rand() < crossover_rate / 2: # Reduced rate
                    crossover_point = np.random.randint(1, num_params)
                    particles_pos[j] = np.concatenate([particles_pos[j][:crossover_point], global_best_pos[crossover_point:]])
                
                # Mutation
                if np.random.rand() < mutation_rate:
                    mutation_point = np.random.randint(0, num_params)
                    particles_pos[j][mutation_point] = np.random.uniform(0, 2 * np.pi)

            # Evaluate and update bests
            for j in range(self.population_size):
                current_fitness = cost_fn(particles_pos[j])
                if current_fitness < personal_best_fitness[j]:
                    personal_best_fitness[j] = current_fitness
                    personal_best_pos[j] = particles_pos[j]

            current_best_idx = np.argmin(personal_best_fitness)
            if personal_best_fitness[current_best_idx] < global_best_fitness:
                global_best_fitness = personal_best_fitness[current_best_idx]
                global_best_pos = personal_best_pos[current_best_idx]
                
        return global_best_pos, global_best_fitness, self.history


# --- Step 3: Create the Benchmarking Framework ---

def run_vqe_benchmark(optimizer, noise_level, max_iterations=100):
    """Runs a VQE experiment for a given optimizer and noise level."""
    print(f"\n--- Running VQE for: {optimizer.__class__.__name__} | Noise Level: {noise_level} ---")
    
    # Define the noisy device
    # Depolarizing probability 'p' will be our noise_level
    dev = qml.device("default.mixed", wires=qubits)
    
    # Define the cost function (expectation value of the Hamiltonian)
    @qml.qnode(dev)
    def cost_fn_noisy(params):
        circuit_ansatz(params, wires=range(qubits))
        # Apply noise after the ansatz
        for i in range(qubits):
            qml.DepolarizingChannel(noise_level, wires=i)
        return qml.expval(H)

    num_params = qubits
    history = []
    
    start_time = time.time()
    
    # Run the optimization
    if isinstance(optimizer, (qml.AdamOptimizer, qml.SPSAOptimizer)):
        params = np.random.uniform(0, 2 * np.pi, num_params, requires_grad=True)
        for i in range(max_iterations):
            params, cost = optimizer.step_and_cost(cost_fn_noisy, params)
            history.append(cost)
            print(f"{optimizer.__class__.__name__} Iteration {i+1}/{max_iterations}, Energy: {cost:.6f}")
        final_params, final_energy = params, cost
    else: # For our custom optimizers
        optimizer.iterations = max_iterations
        final_params, final_energy, history = optimizer.optimize(cost_fn_noisy, num_params)

    end_time = time.time()
    
    return {
        "final_energy": final_energy,
        "error": abs(final_energy - TRUE_GROUND_STATE_ENERGY),
        "history": history,
        "iterations": len(history),
        "runtime": end_time - start_time
    }

# --- Step 4 & 5: Run Experiments and Visualize Results ---

def run_all_experiments():
    """Main function to run all benchmarks and generate outputs."""
    
    # Define experimental parameters
    noise_levels = {"Low": 0.01, "Medium": 0.05, "High": 0.1}
    max_iterations = 100 # Keep this consistent for a fair comparison
    
    optimizers = {
        "Proposed Orchestrator": ProposedOrchestrator(population_size=20, iterations=max_iterations),
        "Adam (Baseline)": qml.AdamOptimizer(stepsize=0.1),
        "Genetic Algorithm": GeneticAlgorithmOptimizer(population_size=20, generations=max_iterations),
        "Particle Swarm": ParticleSwarmOptimizer(n_particles=20, iterations=max_iterations)
    }
    
    results = {}

    # Run all experiments
    for name, opt in optimizers.items():
        results[name] = {}
        for noise_name, noise_val in noise_levels.items():
            results[name][noise_name] = run_vqe_benchmark(opt, noise_val, max_iterations)

    # --- Generate Outputs ---
    
    # 1. Convergence Plot (for a specific noise level)
    plot_convergence(results, "Low")
    
    # 2. Noise Robustness Plot
    plot_noise_robustness(results, noise_levels)
    
    # 3. Results Table
    create_results_table(results, noise_levels)

def plot_convergence(results, noise_name_to_plot):
    """Plots the energy convergence for all optimizers at a given noise level."""
    plt.style.use('seaborn-v0_8-whitegrid')
    fig, ax = plt.subplots(figsize=(12, 7))
    
    for name, res_data in results.items():
        ax.plot(res_data[noise_name_to_plot]['history'], label=name, lw=2.5)
        
    ax.axhline(y=TRUE_GROUND_STATE_ENERGY, color='r', linestyle='--', label='True Ground State Energy', lw=2)
    
    ax.set_title(f'VQE Convergence for H₂ Molecule (Noise Level: {noise_name_to_plot})', fontsize=16)
    ax.set_xlabel('Iteration', fontsize=12)
    ax.set_ylabel('Energy (Hartree)', fontsize=12)
    ax.legend(fontsize=10)
    ax.grid(True)
    plt.tight_layout()
    plt.savefig("vqe_convergence_plot.png")
    plt.show()

def plot_noise_robustness(results, noise_levels):
    """Plots the final energy error for each optimizer across different noise levels."""
    plt.style.use('seaborn-v0_8-whitegrid')
    fig, ax = plt.subplots(figsize=(12, 7))
    
    n_optimizers = len(results)
    n_noise_levels = len(noise_levels)
    bar_width = 0.8 / n_optimizers
    
    noise_names = list(noise_levels.keys())
    indices = np.arange(n_noise_levels)
    
    for i, (name, res_data) in enumerate(results.items()):
        errors = [res_data[noise_name]['error'] for noise_name in noise_names]
        ax.bar(indices + i * bar_width, errors, bar_width, label=name)
        
    ax.set_title('Optimizer Robustness to Noise', fontsize=16)
    ax.set_xlabel('Noise Level', fontsize=12)
    ax.set_ylabel('Final Energy Error (Hartree)', fontsize=12)
    ax.set_xticks(indices + bar_width * (n_optimizers-1) / 2)
    ax.set_xticklabels(noise_names)
    ax.legend(fontsize=10)
    ax.grid(True, axis='y')
    plt.tight_layout()
    plt.savefig("vqe_noise_robustness_plot.png")
    plt.show()

def create_results_table(results, noise_levels):
    """Creates and exports a pandas DataFrame summarizing the results."""
    table_data = []
    for opt_name, res_data in results.items():
        for noise_name in noise_levels.keys():
            run_result = res_data[noise_name]
            table_data.append({
                "Optimizer": opt_name,
                "Noise Level": noise_name,
                "Final Energy (Ha)": f"{run_result['final_energy']:.4f}",
                "Error": f"{run_result['error']:.4f}",
                "Iterations to Converge": run_result['iterations'],
                "Runtime (s)": f"{run_result['runtime']:.2f}"
            })
            
    df = pd.DataFrame(table_data)
    print("\n--- Benchmark Results Summary ---")
    print(df.to_string())
    
    # Export to CSV (can be opened in Sheets/Excel)
    df.to_csv("vqe_benchmark_results.csv", index=False)
    print("\nResults table exported to 'vqe_benchmark_results.csv'")


if __name__ == '__main__':
    run_all_experiments()
