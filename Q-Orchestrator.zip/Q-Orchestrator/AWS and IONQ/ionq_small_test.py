# ionq_small_test.py
# Small hardware test: run the scaling benchmark on an IonQ QPU via AWS Braket.

from braket.aws import AwsDevice
from module_scalability_benchmark import ScalabilityBenchmark

# 1) Choose an IonQ device ARN (us-east-1 region)
IONQ_ARN = "arn:aws:braket:us-east-1::device/qpu/ionq/Forte-1"
# Other options (same region) include:
#   "arn:aws:braket:us-east-1::device/qpu/ionq/Aria-2"
#   "arn:aws:braket:us-east-1::device/qpu/ionq/Forte-1"
#   "arn:aws:braket:us-east-1::device/qpu/ionq/Forte-Enterprise-1"

def main():
    # 2) Start from your existing benchmark class (it expects some device, but
    #    we will immediately override it with the IonQ QPU).
    bench = ScalabilityBenchmark(out_csv="ionq_scaling_results.csv",
                                 device_name="dm1")   # dummy, will be replaced

    # 3) Override the device with the real IonQ hardware
    bench.device = AwsDevice(IONQ_ARN)

    # 4) Run a very small test to keep cost and queue time reasonable
    #    (you can add 4-qubit if you want: n_list=[2, 4])
    n_list = [2]
    shots = 2000    # typical compromise between cost and statistics

    bench.run(n_list=n_list, shots=shots, use_noise=False)

if __name__ == "__main__":
    main()
