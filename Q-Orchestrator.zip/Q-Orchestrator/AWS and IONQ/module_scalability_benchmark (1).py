# module_scalability_benchmark.py
import csv, os, time
from typing import List, Dict

from braket_common import get_device, circuit_summary, zz_expectation_result_type
from braket.circuits import Circuit

class ScalabilityBenchmark:
    """
    Runs structural and hardware benchmarks across n_qubits set to show scaling.
    Produces a CSV with: n_qubits, depth, 1q, 2q, total, value (⟨Z0Z1⟩), wall_sec.
    For >2 qubits, we still measure ⟨Z0Z1⟩ (qubits [0,1]) to keep the observable fixed.
    """

    def __init__(self, out_csv: str = "scaling_results.csv", device_name: str = "dm1"):
        self.out_csv = out_csv
        self.device = get_device(device_name)

    # --- Builders -------------------------------------------------------------
    def _baseline_fanout(self, n_qubits: int) -> Circuit:
        """
        Build an 'unoptimized' fan-out circuit of size n_qubits:
        - Prepare entanglement on qubits 0-1 (Bell-ish start).
        - Fan-out via CNOTs from 0 and 1 to remaining qubits.
        """
        if n_qubits < 2:
            raise ValueError("n_qubits must be >= 2")
        c = Circuit().h(0).cnot(0, 1)
        # Fan-out to aux
        for q in range(2, n_qubits):
            # alternate fan-out parents to spread
            parent = 0 if (q % 2 == 0) else 1
            c.cnot(parent, q)
        c.add_result_type(zz_expectation_result_type())
        return c

    def _optimized_minimal(self, n_qubits: int) -> Circuit:
        """
        Minimal circuit for measuring ⟨Z0Z1⟩: only entangle 0-1.
        Remaining qubits are idle (present but not operated on).
        """
        if n_qubits < 2:
            raise ValueError("n_qubits must be >= 2")
        c = Circuit().h(0).cnot(0, 1)
        # (No fan-out to other qubits; they remain unused in this toy benchmark)
        c.add_result_type(zz_expectation_result_type())
        return c

    # --- Runner ---------------------------------------------------------------
    def run(self, n_list: List[int], shots: int = 4000, use_noise: bool = False):
        """
        For each n in n_list:
          - build both circuits,
          - compute structural metrics,
          - run on device to get ⟨Z0Z1⟩ and wall time,
          - append to CSV.
        use_noise=False here (hardware-safe); the dm1 device’s runtime includes realistic infrastructure overhead.
        """
        rows: List[Dict] = []

        print(f"[Scaling] device={type(self.device).__name__}, shots={shots}, use_noise={use_noise}")
        for n in n_list:
            base = self._baseline_fanout(n)
            opt  = self._optimized_minimal(n)

            sb = circuit_summary(base)
            so = circuit_summary(opt)

            def run_once(label, circ):
                t0 = time.perf_counter()
                task = self.device.run(circ, shots=shots)
                res = task.result()
                wall = time.perf_counter() - t0
                val = float(res.values[0])  # ⟨Z0Z1⟩
                return val, wall

            print(f"n={n}  [Baseline] depth={sb['depth']}, 2q={sb['gates_2q']}  |  [Optimized] depth={so['depth']}, 2q={so['gates_2q']}")
            b_val, b_wall = run_once("Baseline", base)
            o_val, o_wall = run_once("Optimized", opt)

            rows.append({"n_qubits": n, "label": "Baseline",  "depth": sb["depth"], "g1q": sb["gates_1q"], "g2q": sb["gates_2q"], "total": sb["gates_total"], "value": b_val, "shots": shots, "wall_sec": b_wall})
            rows.append({"n_qubits": n, "label": "Optimized", "depth": so["depth"], "g1q": so["gates_1q"], "g2q": so["gates_2q"], "total": so["gates_total"], "value": o_val, "shots": shots, "wall_sec": o_wall})

        with open(self.out_csv, "w", newline="") as f:
            import csv
            w = csv.DictWriter(f, fieldnames=["n_qubits","label","depth","g1q","g2q","total","value","shots","wall_sec"])
            w.writeheader()
            w.writerows(rows)
        print(f"[Scaling] CSV saved → {os.path.abspath(self.out_csv)}")
