# braket_common.py
"""
Common utilities for Amazon Braket (AWS) + local development.

Defaults to AWS managed density-matrix simulator **dm1** and saves plots to PNGs.
Includes:
- Unified device selector (dm1 default, sv1, and QPU placeholders).
- Density-matrix local simulator for offline dev (local_dm).
- Result-type helpers and version-safe circuit-depth / gate-count summaries.
"""

from __future__ import annotations

import os
from typing import Dict

# Core Braket
from braket.circuits import Circuit, Observable
from braket.circuits.result_types import Probability, Expectation, DensityMatrix
from braket.devices import LocalSimulator

# AWS device access
from braket.aws import AwsDevice

# ---- Default device selection ----
# You can override via environment variable BRAKET_DEVICE_NAME
#   values: "dm1", "sv1", "local_dm", or one of the QPU aliases below.
DEFAULT_DEVICE_NAME = os.getenv("BRAKET_DEVICE_NAME", "dm1")

# Map simple names to ARNs where needed
AWS_DEVICE_MAP: Dict[str, str] = {
    # Managed simulators
    "sv1": "arn:aws:braket:::device/quantum-simulator/amazon/sv1",
    "dm1": "arn:aws:braket:::device/quantum-simulator/amazon/dm1",
    # Example QPUs (update if you plan to run on real hardware)
    "ionq":    "arn:aws:braket:us-east-1::device/qpu/ionq/ionQAria-1",
    "oqc":     "arn:aws:braket:eu-west-2::device/qpu/oqc/Lucy",
    "rigetti": "arn:aws:braket:us-west-1::device/qpu/rigetti/Ankaa-2",
}

def get_local_dm() -> LocalSimulator:
    """Return the local density-matrix simulator (supports explicit noise)."""
    try:
        return LocalSimulator(backend="braket_dm")
    except TypeError:
        return LocalSimulator("braket_dm")

def get_device(name: str = DEFAULT_DEVICE_NAME):
    """
    Return a Braket device handle.
    name: "dm1" (default), "sv1", "local_dm", "ionq", "oqc", "rigetti", or a full ARN.
    """
    if name == "local_dm":
        return get_local_dm()
    if name in AWS_DEVICE_MAP:
        return AwsDevice(AWS_DEVICE_MAP[name])
    # Allow passing a full ARN directly
    if name.startswith("arn:aws:braket"):
        return AwsDevice(name)
    raise ValueError(f"Unknown device name '{name}'. Use one of: {list(AWS_DEVICE_MAP.keys()) + ['local_dm']}")

# Singleton for modules that just need "the default device"
dev = get_device(DEFAULT_DEVICE_NAME)

# ---- Result-type helpers ----
def zz_expectation_result_type():
    """Expectation ⟨Z0 Z1⟩ on qubits [0,1]."""
    return Expectation(observable=Observable.Z() @ Observable.Z(), target=[0, 1])

def prob_result_type(target=None):
    """Probability result type; defaults to [0,1] if target unspecified."""
    if target is None:
        target = [0, 1]
    return Probability(target=target)

def density_matrix_result_type(target=None):
    """Density matrix result type; defaults to [0,1] if target unspecified."""
    if target is None:
        target = [0, 1]
    return DensityMatrix(target=target)

# ---- Version-safe circuit analysis helpers (depth / gate counts) ----
def circuit_summary(circ: Circuit):
    """
    Version-safe circuit summary.
    - Counts ops by iterating 'instructions' (works on older SDKs).
    - Depth: uses circ.depth if present; else len(circ.moments) if present; else #instructions (upper bound).
    - Qubit count: uses circ.qubit_count if present; else inferred from instruction targets.
    """
    # --- collect ops from instructions (robust across versions)
    ops = {}
    try:
        instrs = list(circ.instructions)
    except AttributeError:
        instrs = []

    for ins in instrs:
        # Try to extract a clean, lowercase operator name
        try:
            name = ins.operator.name
        except AttributeError:
            name = str(getattr(getattr(ins, "operator", None), "__class__", type("Op", (), {})).__name__)
        key = str(name).lower()
        ops[key] = ops.get(key, 0) + 1

    # --- depth (robust fallback chain)
    depth = None
    if hasattr(circ, "depth"):
        try:
            depth = circ.depth
        except Exception:
            depth = None
    if depth is None and hasattr(circ, "moments"):
        try:
            depth = len(circ.moments)
        except Exception:
            depth = None
    if depth is None:
        depth = len(instrs)  # safe upper bound if nothing else is available

    # --- qubit count (robust)
    qubit_count = None
    if hasattr(circ, "qubit_count"):
        try:
            qubit_count = circ.qubit_count
        except Exception:
            qubit_count = None
    if qubit_count is None:
        touched = set()
        for ins in instrs:
            try:
                for q in ins.target:
                    touched.add(int(q))
            except Exception:
                pass
        qubit_count = len(touched)

    # --- aggregate 1q / 2q buckets (extend as needed)
    one_q_set = {"x", "y", "z", "h", "s", "t", "rx", "ry", "rz", "v", "u"}
    two_q_set = {"cnot", "cz", "xx", "xy", "yy", "zz", "iswap", "ecr"}

    gates_1q = sum(cnt for name, cnt in ops.items() if name in one_q_set)
    gates_2q = sum(cnt for name, cnt in ops.items() if name in two_q_set)

    return {
        "qubits": qubit_count,
        "depth": depth,
        "gates_total": sum(ops.values()),
        "gates_1q": gates_1q,
        "gates_2q": gates_2q,
        "ops": ops,
    }
