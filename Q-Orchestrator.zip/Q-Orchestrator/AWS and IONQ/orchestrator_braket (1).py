# orchestrator_braket.py
# High-level runner for the faithful Algorithm-3 hybrid optimizer on Amazon Braket.
# - Provides an OrchestratorBraket class with convenience methods.
# - Clean CLI for running the hybrid optimization (default) and optional utilities.
# - CSV preview helper for the run logs produced by the hybrid module.

import os
import sys
import argparse
import json
from typing import Optional, Dict, Any

# Core hybrid optimizer (faithful Algorithm-3 with CSV logging)
from module_hybrid_opt_braket import (
    FaithfulHybridOptimizer,
    NoiseAwareObjective,
    Feasibility,
)

# Optional: these modules may or may not be present; we import lazily in methods.
# from module_noise_simulation_braket import ...
# from module_scalability_benchmark import ...
# from module_baseline_comparisons import ...
# from module_four_way_helper import ...
# from run_trials import ...

DEFAULT_LOG = "hybrid_log.csv"


class OrchestratorBraket:
    """
    High-level façade to run the faithful hybrid optimization and (optionally)
    invoke other study modules if they are present in the repo.
    """

    def __init__(self):
        pass

    # ----------------------------
    # Hybrid (Algorithm-3) runner
    # ----------------------------
    def run_full_hybrid_optimization(
        self,
        iters: int = 6,
        shots: int = 0,
        use_zne: bool = True,
        lam0: float = 0.01,
        gam1: float = 0.10,
        F_threshold: float = 0.95,
        tau: float = 0.90,
        eps: float = 0.02,
        log: str = DEFAULT_LOG,
        seed: Optional[int] = None,
        # ACO
        aco_ants: int = 20,
        aco_step: float = 0.12,
        aco_evap: float = 0.2,
        aco_strength: float = 1.0,
        # PSO
        pso_swarm: int = 20,
        pso_iters: int = 6,
        # GA
        ga_pop: int = 30,
        ga_iters: int = 6,
        ga_cx: float = 0.85,
        ga_mut: float = 0.12,
        # BA
        ba_bees: int = 24,
        ba_elite: int = 5,
        ba_recruits: int = 3,
        ba_radius: float = 0.06,
        ba_iters: int = 6,
        ba_stagn: int = 3,
        # Early stop
        patience: int = 4,
        tol: float = 1e-3,
    ) -> Dict[str, Any]:
        """
        Execute one full Algorithm-3 orchestration run and return the JSON result.
        Also appends per-stage rows to the CSV log (created if absent).
        """
        obj = NoiseAwareObjective(
            shots=shots,
            use_zne=use_zne,
            lam0=lam0,
            gam1=gam1,
        )
        feas = Feasibility(
            objective=obj,
            F_threshold=F_threshold,
            tau=tau,
            eps=eps,
            rng=seed,
        )

        opt = FaithfulHybridOptimizer(
            objective=obj,
            feasibility=feas,
            log_path=log,
            rng=seed,
        )

        # ACO knob wiring
        opt.ph_evap = aco_evap
        opt.ph_strength = aco_strength

        result = opt.orchestrate(
            outer_iters=iters,
            aco_cfg={"ants": aco_ants, "step": aco_step},
            pso_cfg={"swarm": pso_swarm, "iters": pso_iters},
            ga_cfg={"pop_size": ga_pop, "iters": ga_iters, "cx_prob": ga_cx, "mut_prob": ga_mut},
            ba_cfg={
                "bees": ba_bees,
                "elite": ba_elite,
                "recruits": ba_recruits,
                "radius": ba_radius,
                "iters": ba_iters,
                "stagn_limit": ba_stagn,
            },
            stop_patience=patience,
            stop_tol=tol,
        )

        # Print to console as JSON (matches your desired behavior)
        print(json.dumps(result, indent=2))
        return result

    # ------------------------------------
    # CSV preview (handy while iterating)
    # ------------------------------------
    def preview_csv(self, path: str = DEFAULT_LOG, tail: int = 20) -> None:
        """
        Print the last N lines of the CSV log for a quick look inside the notebook/terminal.
        """
        if not os.path.exists(path):
            print(f"[preview_csv] No CSV found at: {path}")
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                lines = f.readlines()
            lines_to_show = lines[-tail:] if tail > 0 else lines[:]
            print(f"--- tail({tail}) of {path} ---")
            for ln in lines_to_show:
                print(ln.rstrip("\n"))
            print("--- end ---")
        except Exception as e:
            print(f"[preview_csv] Error reading {path}: {e}")

    # --------------------------------------------------------
    # Optional helpers that call other study modules if present
    # --------------------------------------------------------
    def run_noise_simulation(self) -> None:
        """
        If module_noise_simulation_braket.py exposes a `main()` or `run()` we try to call it.
        """
        try:
            import module_noise_simulation_braket as m
            if hasattr(m, "main"):
                m.main()
            elif hasattr(m, "run"):
                m.run()
            else:
                print("[run_noise_simulation] Found module but no main()/run() entrypoint.")
        except Exception as e:
            print(f"[run_noise_simulation] Skipped (module missing or error): {e}")

    def run_scaling_study(self, **kwargs) -> None:
        """
        If module_scalability_benchmark.py exposes a `main()` we try to call it,
        or fall back to a function-like entrypoint if present.
        """
        try:
            import module_scalability_benchmark as m
            if hasattr(m, "main"):
                m.main()
            elif hasattr(m, "run_scaling_study"):
                m.run_scaling_study(**kwargs)
            else:
                print("[run_scaling_study] Found module but no main()/run_scaling_study() entrypoint.")
        except Exception as e:
            print(f"[run_scaling_study] Skipped (module missing or error): {e}")

    def compare_against_qiskit(self, **kwargs) -> None:
        """
        If module_baseline_comparisons.py or module_four_way_helper.py expose a `main()` or `compare()` we try to call it.
        """
        try:
            import module_baseline_comparisons as b
            if hasattr(b, "main"):
                b.main()
            elif hasattr(b, "compare_against_qiskit"):
                b.compare_against_qiskit(**kwargs)
            else:
                print("[compare_against_qiskit] Baseline module has no entrypoint; trying four-way helper...")
                raise ImportError("no entrypoint in module_baseline_comparisons")
        except Exception as e1:
            try:
                import module_four_way_helper as h
                if hasattr(h, "main"):
                    h.main()
                elif hasattr(h, "run_four_way"):
                    h.run_four_way(**kwargs)
                else:
                    print("[compare_against_qiskit] Four-way helper has no entrypoint either.")
            except Exception as e2:
                print(f"[compare_against_qiskit] Skipped (modules missing or error): {e1} | {e2}")


# -----------------------
# Command-line interface
# -----------------------
def parse_args():
    p = argparse.ArgumentParser(
        description="Orchestrator for faithful Algorithm-3 hybrid optimization on Amazon Braket."
    )
    sub = p.add_subparsers(dest="cmd", required=False)

    # hybrid (default) ---------------------------------------------------------
    ph = sub.add_parser("hybrid", help="Run the faithful hybrid optimization (Algorithm-3)")
    ph.add_argument("--iters", type=int, default=6, help="Outer iterations (ACO->PSO->GA->BA cycles)")
    ph.add_argument("--shots", type=int, default=0, help="0 for analytic dm1; 4000 to match paper tables")
    ph.add_argument("--no-zne", action="store_true", help="Disable ZNE")
    ph.add_argument("--lam0", type=float, default=0.01)
    ph.add_argument("--gam1", type=float, default=0.10)
    ph.add_argument("--F_threshold", type=float, default=0.95)
    ph.add_argument("--tau", type=float, default=0.90)
    ph.add_argument("--eps", type=float, default=0.02)
    ph.add_argument("--seed", type=int, default=None)
    ph.add_argument("--log", type=str, default=DEFAULT_LOG)

    # ACO
    ph.add_argument("--aco-ants", type=int, default=20)
    ph.add_argument("--aco-step", type=float, default=0.12)
    ph.add_argument("--aco-evap", type=float, default=0.2)
    ph.add_argument("--aco-strength", type=float, default=1.0)

    # PSO
    ph.add_argument("--pso-swarm", type=int, default=20)
    ph.add_argument("--pso-iters", type=int, default=6)

    # GA
    ph.add_argument("--ga-pop", type=int, default=30)
    ph.add_argument("--ga-iters", type=int, default=6)
    ph.add_argument("--ga-cx", type=float, default=0.85)
    ph.add_argument("--ga-mut", type=float, default=0.12)

    # BA
    ph.add_argument("--ba-bees", type=int, default=24)
    ph.add_argument("--ba-elite", type=int, default=5)
    ph.add_argument("--ba-recruits", type=int, default=3)
    ph.add_argument("--ba-radius", type=float, default=0.06)
    ph.add_argument("--ba-iters", type=int, default=6)
    ph.add_argument("--ba-stagn", type=int, default=3)

    # early stop
    ph.add_argument("--patience", type=int, default=4)
    ph.add_argument("--tol", type=float, default=1e-3)

    # csv preview --------------------------------------------------------------
    pv = sub.add_parser("preview", help="Preview the tail of the hybrid CSV log")
    pv.add_argument("--log", type=str, default=DEFAULT_LOG)
    pv.add_argument("--tail", type=int, default=20)

    # noise sim (optional) -----------------------------------------------------
    sub.add_parser("noise-sim", help="Run the noise simulation module if present")

    # scaling (optional) -------------------------------------------------------
    sub.add_parser("scaling", help="Run the scalability study module if present")

    # qiskit compare (optional) -----------------------------------------------
    sub.add_parser("qiskit", help="Run the Qiskit comparison module if present")

    p.set_defaults(cmd="hybrid")
    return p.parse_args()


def main():
    args = parse_args()
    orch = OrchestratorBraket()

    if args.cmd == "preview":
        orch.preview_csv(path=args.log, tail=args.tail)
        return

    if args.cmd == "noise-sim":
        orch.run_noise_simulation()
        return

    if args.cmd == "scaling":
        orch.run_scaling_study()
        return

    if args.cmd == "qiskit":
        orch.compare_against_qiskit()
        return

    # default: hybrid
    orch.run_full_hybrid_optimization(
        iters=args.iters,
        shots=args.shots,
        use_zne=(not args.no_zne),
        lam0=args.lam0,
        gam1=args.gam1,
        F_threshold=args.F_threshold,
        tau=args.tau,
        eps=args.eps,
        log=args.log,
        seed=args.seed,
        aco_ants=args.aco_ants,
        aco_step=args.aco_step,
        aco_evap=args.aco_evap,
        aco_strength=args.aco_strength,
        pso_swarm=args.pso_swarm,
        pso_iters=args.pso_iters,
        ga_pop=args.ga_pop,
        ga_iters=args.ga_iters,
        ga_cx=args.ga_cx,
        ga_mut=args.ga_mut,
        ba_bees=args.ba_bees,
        ba_elite=args.ba_elite,
        ba_recruits=args.ba_recruits,
        ba_radius=args.ba_radius,
        ba_iters=args.ba_iters,
        ba_stagn=args.ba_stagn,
        patience=args.patience,
        tol=args.tol,
    )


if __name__ == "__main__":
    main()
