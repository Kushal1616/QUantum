from module_scalability_benchmark import ScalabilityBenchmark

# choose your qubit sizes; feel free to change this list
n_list = [2, 4, 6, 8, 10]

bench = ScalabilityBenchmark(out_csv="scaling_results.csv", device_name="dm1")
bench.run(n_list=n_list, shots=4000, use_noise=False)
