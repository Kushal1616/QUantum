# module_noise_simulation_braket.py
# Module 1 — Ideal vs Noisy probabilities on Amazon Braket (defaults to AWS dm1; saves PNGs).

import os
import matplotlib.pyplot as plt
from braket_common import Circuit, dev, prob_result_type

class NoiseSimulatorBraket:
    def __init__(self, outdir: str = "."):
        # Default Option-B noise params
        self.lam0 = 0.01   # depolarizing on qubit 0
        self.gamma1 = 0.10 # amplitude damping on qubit 1
        self.lam2 = 0.10   # depolarizing on aux qubit 2 (readout)
        self.lam3 = 0.20   # depolarizing on aux qubit 3 (readout)
        self.outdir = outdir

    def _ideal_circuit(self):
        c = Circuit().h(0).cnot(0, 1)
        c.add_result_type(prob_result_type(target=[0, 1]))
        return c

    def _noisy_circuit(self):
        c = Circuit().h(0).cnot(0, 1)
        # Local noise channels (channel ops)
        c.depolarizing(0, probability=self.lam0)         # qubit 0
        c.amplitude_damping(1, gamma=self.gamma1)        # qubit 1
        # Attach auxiliaries + readout depolarizing on aux
        c.cnot(0, 2).cnot(1, 3)
        c.depolarizing(2, probability=self.lam2)         # aux 2
        c.depolarizing(3, probability=self.lam3)         # aux 3
        c.add_result_type(prob_result_type(target=[0, 1]))
        return c

    def run_and_visualize(self, shots: int = 0):
        # Run both on the selected device (default: AWS dm1). shots=0 is supported on managed sims.
        ideal_task = dev.run(self._ideal_circuit(), shots=shots)
        noisy_task = dev.run(self._noisy_circuit(), shots=shots)

        ideal_probs = ideal_task.result().values[0]
        noisy_probs = noisy_task.result().values[0]

        labels = ["00", "01", "10", "11"]
        fig, ax = plt.subplots(1, 2, figsize=(12, 5))

        ax[0].bar(labels, ideal_probs)
        ax[0].set_title("Ideal")
        ax[0].set_ylim(0, 1)
        ax[0].set_xlabel("Measured state")
        ax[0].set_ylabel("Probability")

        ax[1].bar(labels, noisy_probs)
        ax[1].set_title("Noisy (λ0=%.2f, γ1=%.2f, λ2=%.2f, λ3=%.2f)"
                        % (self.lam0, self.gamma1, self.lam2, self.lam3))
        ax[1].set_ylim(0, 1)
        ax[1].set_xlabel("Measured state")

        fig.suptitle("Module 1 (Braket/AWS dm1): Impact of Noise on Circuit")
        plt.tight_layout()

        os.makedirs(self.outdir, exist_ok=True)
        outfile = os.path.join(self.outdir, "module1_noise_vs_ideal.png")
        plt.savefig(outfile, dpi=200, bbox_inches="tight")
        plt.close(fig)

        print(f"[Module 1] Saved plot → {outfile}")
