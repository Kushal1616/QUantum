# run_trials.py
import csv, os, statistics, time
from typing import Iterable, Tuple

from braket_common import get_device
from module_noise_aware_opt_braket import NoiseAwareOptimizerBraket

def _build_optimized_scaled(mod: NoiseAwareOptimizerBraket, scale: float):
    """
    Build the 'depth-optimized' circuit with readout depolarizing scaled by `scale`.
    Mirrors mod._depth_optimized() but applies scale to lam2_base, lam3_base for fairness.
    """
    from braket.circuits import Circuit
    c = Circuit().h(0).cnot(0, 1).cnot(0, 2).cnot(1, 3)
    c.depolarizing(2, probability=mod.lam2_base * scale)
    c.depolarizing(3, probability=mod.lam3_base * scale)
    c.add_result_type(mod.zz_expectation_result_type() if hasattr(mod, "zz_expectation_result_type")
                      else __import__("braket_common").zz_expectation_result_type())
    return c

def _run_once(device, circ, label, shots, trial_idx, scale, rows):
    t0 = time.perf_counter()
    task = device.run(circ, shots=shots)
    res = task.result()
    wall = time.perf_counter() - t0
    val = float(res.values[0])  # ⟨Z0Z1⟩
    rows.append({"trial": trial_idx, "label": label, "scale": scale,
                 "value": val, "shots": shots, "wall_sec": wall})
    print(f"[{label} s={scale:.2f} #{trial_idx}] <Z0Z1>={val:.4f}, wall={wall:.2f}s")

def _summarize(rows, label, scale) -> Tuple[Tuple[float,float], Tuple[float,float]]:
    vals = [r["value"] for r in rows if r["label"] == label and abs(r["scale"]-scale) < 1e-12]
    wals = [r["wall_sec"] for r in rows if r["label"] == label and abs(r["scale"]-scale) < 1e-12]
    if len(vals) == 0:
        return ((float("nan"), float("nan")), (float("nan"), float("nan")))
    vmean = statistics.mean(vals); vstd = statistics.pstdev(vals) if len(vals) > 1 else 0.0
    tmean = statistics.mean(wals); tstd = statistics.pstdev(wals) if len(wals) > 1 else 0.0
    return ( (vmean, vstd), (tmean, tstd) )

def run_trials(device_name="dm1", shots=4000, trials=5, use_noise=True,
               scale=1.0, out_csv="trials_dm1_results.csv"):
    """
    Single-scale trial runner (backward-compatible).
    - device_name: "dm1" (default), "sv1", or a QPU alias you’ve added in braket_common.py
    - shots: >= 1 for managed devices
    - trials: repetitions per circuit
    - use_noise: True -> Baseline circuit includes depolarizing/amplitude-damping;
                 Optimized includes readout depolarizing
    - scale: noise scaling factor for λ, γ (and readout λ2, λ3 for optimized)
    - out_csv: output CSV
    """
    return run_trials_scales(device_name=device_name, shots=shots, trials=trials,
                             use_noise=use_noise, scales=(scale,), out_csv=out_csv)

def run_trials_scales(device_name="dm1", shots=4000, trials=5, use_noise=True,
                      scales: Iterable[float]=(1.0, 0.5, 0.1),
                      out_csv="trials_dm1_results_scales.csv"):
    """
    Multi-scale trial runner. Sweeps s ∈ scales and writes a single CSV.
    Rows: trial,label,scale,value,shots,wall_sec
    """
    device = get_device(device_name)
    mod = NoiseAwareOptimizerBraket(outdir=".")

    scales = tuple(scales)
    rows = []

    print(f"[Trials] device={device_name}, use_noise={use_noise}, shots={shots}, trials={trials}, scales={scales}")

    for s in scales:
        # Build circuits for this scale
        base_circ = mod._circuit_with_scaled_noise(scale=s, use_noise=use_noise)
        opt_circ  = _build_optimized_scaled(mod, scale=s)

        for i in range(1, trials+1):
            _run_once(device, base_circ, "Baseline",  shots, i, s, rows)
            _run_once(device, opt_circ,  "Optimized", shots, i, s, rows)

    # Save CSV
    with open(out_csv, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["trial","label","scale","value","shots","wall_sec"])
        writer.writeheader()
        writer.writerows(rows)

    # Print summary
    print("\n[Summary over trials × scales]")
    for s in scales:
        (m_b, s_b), (t_b, ts_b) = _summarize(rows, "Baseline", s)
        (m_o, s_o), (t_o, ts_o) = _summarize(rows, "Optimized", s)
        print(f"Scale s={s:.2f}")
        print(f"  Baseline : <Z0Z1> mean={m_b:.4f}±{s_b:.4f}, time mean={t_b:.2f}±{ts_b:.2f}s")
        print(f"  Optimized: <Z0Z1> mean={m_o:.4f}±{s_o:.4f}, time mean={t_o:.2f}±{ts_o:.2f}s")

    print(f"\nCSV saved → {os.path.abspath(out_csv)}")

if __name__ == "__main__":
    # Default: dm1, 4000 shots, 5 trials, with noise, scales (1.0, 0.5, 0.1)
    run_trials_scales(device_name="dm1", shots=4000, trials=5, use_noise=True,
                      scales=(1.0, 0.5, 0.1),
                      out_csv="trials_dm1_results_scales.csv")
