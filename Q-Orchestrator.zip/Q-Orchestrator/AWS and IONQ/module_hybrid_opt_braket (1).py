# module_hybrid_opt_braket.py
# Faithful Algorithm-3 (ACO -> PSO -> GA -> BA) with feasibility, repair,
# robustness tolerance, noise-aware scoring on dm1, optional ZNE, and CSV logging.
#
# CSV: hybrid_log.csv with columns:
#   iteration,method,fidelity,feasible,repaired,elapsed_s
#
# Compatible with braket_common.py that provides: Circuit, dev

import os
import csv
import math
import time
import argparse
import numpy as np

from braket_common import Circuit, dev
from braket.circuits import Observable

# ------------------- Global/problem config -------------------
NDIMS = 4                               # number of gate parameters θ0..θ3
PARAM_BOUNDS = (-math.pi, math.pi)      # per-parameter bounds
DEFAULT_ZNE_SCALES = (1.0, 0.5, 0.1)    # ZNE scales
LAMBDA0 = 0.01                          # depolarizing prob on q0 (base)
GAMMA1  = 0.10                          # amplitude damping prob on q1 (base)

LOG_FILE = "hybrid_log.csv"
LOG_HEADER = ["iteration", "method", "fidelity", "feasible", "repaired", "elapsed_s"]

# ------------------- Small helpers -------------------
def clip_params(x):
    lo, hi = PARAM_BOUNDS
    return np.clip(np.array(x, dtype=float), lo, hi)

def rand_vec(rng, radius):
    return rng.uniform(-radius, radius, NDIMS)

def _to_scalar(val):
    if isinstance(val, (float, int, np.floating, np.integer)):
        return float(val)
    if isinstance(val, (list, tuple)) and len(val) == 1:
        return _to_scalar(val[0])
    if isinstance(val, dict):
        if "value" in val:
            return _to_scalar(val["value"])
        if "real" in val or "imag" in val:
            return float(val.get("real", 0.0))
    arr = np.array(val)
    if arr.shape == ():
        return float(arr)
    raise ValueError(f"Could not coerce expectation value to float: {type(val)}")

def _extract_expectation(res):
    if hasattr(res, "values") and isinstance(res.values, (list, tuple)) and res.values:
        try:
            return _to_scalar(res.values[0])
        except Exception:
            pass
    if hasattr(res, "result_types") and isinstance(res.result_types, (list, tuple)) and res.result_types:
        v = getattr(res.result_types[0], "value", None)
        if v is not None:
            try:
                return _to_scalar(v)
            except Exception:
                pass
    for attr in ("value", "values"):
        if hasattr(res, attr):
            try:
                return _to_scalar(getattr(res, attr))
            except Exception:
                pass
    try:
        return _to_scalar(res)
    except Exception:
        pass
    raise ValueError("Expectation value not found in Braket result")

def append_csv_row(path, row_dict):
    """Append a single row to CSV, create file with header if missing."""
    file_exists = os.path.exists(path)
    with open(path, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=LOG_HEADER)
        if not file_exists:
            w.writeheader()
        w.writerow(row_dict)

# ------------------- Objective & noise/ZNE -------------------
class NoiseAwareObjective:
    """
    Builds param circuits; evaluates <Z0 Z1> on dm1 with optional ZNE by
    scaling noise strengths and extrapolating y(s)->c at s=0 (quadratic fit).
    """
    def __init__(self, shots=0, use_zne=True, zne_scales=DEFAULT_ZNE_SCALES,
                 lam0=LAMBDA0, gam1=GAMMA1):
        self.shots = int(shots)
        self.use_zne = bool(use_zne)
        self.scales = tuple(zne_scales)
        self.lam0 = float(lam0)
        self.gam1 = float(gam1)
        self._cache = {}

    def _base_layers(self, circ, theta):
        circ.rx(0, theta[0]).ry(1, theta[1])
        circ.cnot(0, 1)
        circ.rz(0, theta[2]).rx(1, theta[3])

    def _noisy_circuit(self, theta, scale=1.0):
        lam0 = max(0.0, min(1.0, self.lam0 * scale))
        gam1 = max(0.0, min(1.0, self.gam1 * scale))
        c = Circuit()
        # Layer 1
        c.rx(0, theta[0]).ry(1, theta[1])
        c.depolarizing(0, lam0)
        c.amplitude_damping(1, gam1)
        # Layer 2
        c.cnot(0, 1)
        c.depolarizing(0, lam0)
        c.amplitude_damping(1, gam1)
        # Layer 3
        c.rz(0, theta[2]).rx(1, theta[3])
        c.depolarizing(0, lam0)
        c.amplitude_damping(1, gam1)
        c.expectation(Observable.Z() @ Observable.Z(), [0, 1])
        return c

    def _eval_once(self, theta, scale=1.0):
        theta = tuple(clip_params(theta))
        key = (theta, float(scale), int(self.shots))
        if key in self._cache:
            return self._cache[key]
        res_noisy = dev.run(self._noisy_circuit(theta, scale=scale), shots=self.shots).result()
        z_noisy = _extract_expectation(res_noisy)
        score = float(z_noisy)  # report <Z0 Z1>
        self._cache[key] = score
        return score

    def evaluate(self, theta):
        if not self.use_zne:
            return self._eval_once(theta, 1.0)
        s = np.array(self.scales, dtype=float)
        y = np.array([self._eval_once(theta, float(si)) for si in s], dtype=float)
        A = np.vstack([s**2, s, np.ones_like(s)]).T
        a, b, c = np.linalg.lstsq(A, y, rcond=None)[0]
        return float(c)

# ------------------- Feasibility & repair -------------------
class Feasibility:
    """
    Is_Feasible and Repair_Solution (Algorithm 3):
    - Feasible if F(θ) >= F_threshold and robust under small perturbations δ: F(θ+δ) >= tau.
    - Repair projects to bounds, then does a short local backoff search to recover feasibility.
    """
    def __init__(self, objective, F_threshold=0.95, tau=0.90, eps=0.02, rng=None):
        self.obj = objective
        self.F_threshold = float(F_threshold)
        self.tau = float(tau)
        self.eps = float(eps)
        self.rng = np.random.default_rng(None if rng is None else rng)

    def is_feasible(self, theta, checks=3):
        theta = clip_params(theta)
        f0 = self.obj.evaluate(theta)
        if f0 < self.F_threshold:
            return False, f0
        for _ in range(checks):
            cand = clip_params(theta + self.rng.uniform(-self.eps, self.eps, NDIMS))
            f = self.obj.evaluate(cand)
            if f < self.tau:
                return False, f0
        return True, f0

    def repair(self, theta, max_tries=20, step=0.05):
        """
        Returns (theta_repaired, f(theta_repaired), repaired_flag, feasible_flag)
        """
        theta = clip_params(theta)
        ok0, f0 = self.is_feasible(theta)
        repaired = False
        if ok0:
            return theta, f0, repaired, True

        best = theta.copy()
        fbest = f0
        for _ in range(max_tries):
            # try local variants
            tried = []
            for _k in range(8):
                trial = clip_params(best + self.rng.uniform(-step, step, NDIMS))
                ok_tr, ftr = self.is_feasible(trial)
                tried.append((ok_tr, ftr, trial))
            tried.sort(key=lambda e: (e[0], e[1]), reverse=True)
            ok_b, f_b, x_b = tried[0]
            if ok_b:
                return x_b, f_b, True, True
            # move toward best violating candidate
            best = x_b
            fbest = f_b
            step *= 0.8
            repaired = True
        # best we could do (may still be infeasible)
        ok_final, _ = self.is_feasible(best)
        return best, fbest, repaired, ok_final

    def ensure_feasible(self, theta, **kwargs):
        """
        Convenience for stages: returns (theta2, f2, feasible_before, repaired_flag, feasible_after)
        """
        ok_before, _ = self.is_feasible(theta)
        theta2, f2, repaired, ok_after = self.repair(theta, **kwargs)
        return theta2, f2, ok_before, repaired, ok_after

# ------------------- Metaheuristics (faithful operators) -------------------
class FaithfulHybridOptimizer:
    """
    Faithful Algorithm-3 sequence per outer iteration:
    1) ACO step guided by pheromone -> candidate(s)
    2) PSO refinement using velocities and elite/global best
    3) GA crossover + mutation
    4) BA local neighborhood search (employed/onlooker), scouts on stagnation
    After each stage: Is_Feasible + Repair_Solution, elite forwarding, history.
    Logs CSV rows per stage per iteration.
    """
    def __init__(self, objective: NoiseAwareObjective, feasibility: Feasibility,
                 log_path=LOG_FILE, rng=None):
        self.obj = objective
        self.feas = feasibility
        self.log_path = log_path
        self.rng = np.random.default_rng(None if rng is None else rng)

        # ACO pheromone over parameters (vector form)
        self.pheromone = np.ones(NDIMS, dtype=float)
        self.ph_evap = 0.2
        self.ph_strength = 1.0

        # PSO params
        self.w_max, self.w_min = 0.9, 0.4
        self.c1, self.c2 = 1.6, 1.6
        self.v_clip = 0.35 * math.pi

        # Ensure CSV header exists
        if not os.path.exists(self.log_path):
            append_csv_row(self.log_path, dict(zip(LOG_HEADER, LOG_HEADER)))

    # ---------- ACO ----------
    def step_aco(self, base, ants=20, step=0.12):
        trail = self.pheromone / (self.pheromone.sum() + 1e-12)
        proto = clip_params(base)  # base guides; pheromone affects update, not sampling mean
        cand = []
        for _ in range(ants):
            x = clip_params(proto + self.rng.uniform(-step, step, NDIMS))
            # feasibility + repair
            x, f, _, _, _ = self.feas.ensure_feasible(x, max_tries=10, step=step)
            cand.append((f, x))
        cand.sort(key=lambda t: t[0], reverse=True)
        f_best, x_best = cand[0]
        # pheromone update (evaporation + reinforcement by |x_best|)
        self.pheromone = (1 - self.ph_evap) * self.pheromone + self.ph_strength * np.abs(x_best)
        return x_best, f_best

    # ---------- PSO ----------
    def step_pso(self, gbest_x, swarm=20, iters=6):
        x = self.rng.uniform(PARAM_BOUNDS[0], PARAM_BOUNDS[1], size=(swarm, NDIMS))
        v = np.zeros_like(x)
        # initial repair/evaluate
        for i in range(swarm):
            x[i], _, _, _, _ = self.feas.ensure_feasible(x[i], max_tries=6, step=0.06)
        pbest = x.copy()
        pbest_f = np.array([self.obj.evaluate(xx) for xx in x])
        gbest = pbest[pbest_f.argmax()].copy()
        gbest_f = float(pbest_f.max())
        if gbest_x is not None:
            gx, gf, _, _, _ = self.feas.ensure_feasible(gbest_x, max_tries=6, step=0.06)
            fx = self.obj.evaluate(gx)
            if fx > gbest_f:
                gbest, gbest_f = gx.copy(), fx

        for t in range(iters):
            w = self.w_max - (self.w_max - self.w_min) * (t / max(1, iters - 1))
            r1, r2 = self.rng.random(size=x.shape), self.rng.random(size=x.shape)
            v = w * v + self.c1 * r1 * (pbest - x) + self.c2 * r2 * (gbest - x)
            v = np.clip(v, -self.v_clip, self.v_clip)
            x = clip_params(x + v)
            # feasibility + repair
            for i in range(swarm):
                x[i], _, _, _, _ = self.feas.ensure_feasible(x[i], max_tries=6, step=0.06)
            f = np.array([self.obj.evaluate(xx) for xx in x])
            improved = f > pbest_f
            pbest[improved] = x[improved]
            pbest_f[improved] = f[improved]
            if pbest_f.max() > gbest_f:
                gbest = pbest[pbest_f.argmax()].copy()
                gbest_f = float(pbest_f.max())
        return gbest, gbest_f

    # ---------- GA ----------
    def step_ga(self, elite_x, pop_size=30, iters=6, cx_prob=0.85, mut_prob=0.12):
        pop = self.rng.uniform(PARAM_BOUNDS[0], PARAM_BOUNDS[1], size=(pop_size, NDIMS))
        pop[0] = elite_x.copy()
        # repair initial
        for i in range(pop_size):
            pop[i], _, _, _, _ = self.feas.ensure_feasible(pop[i], max_tries=6, step=0.06)
        fit = np.array([self.obj.evaluate(xx) for xx in pop])

        for t in range(iters):
            new = [pop[fit.argmax()].copy()]  # elitism
            while len(new) < pop_size:
                i, j = self.rng.integers(0, pop_size, 2)
                p1, p2 = pop[i], pop[j]
                child = p1.copy()
                if self.rng.random() < cx_prob:
                    alpha = self.rng.uniform(0.2, 0.8)
                    child = alpha * p1 + (1 - alpha) * p2
                if self.rng.random() < mut_prob:
                    strength = (1 - t / max(1, iters)) * 0.45
                    child = child + self.rng.normal(0, strength, size=NDIMS)
                child, _, _, _, _ = self.feas.ensure_feasible(child, max_tries=6, step=0.06)
                new.append(clip_params(child))
            pop = np.array(new[:pop_size])
            fit = np.array([self.obj.evaluate(xx) for xx in pop])

        best = fit.argmax()
        return pop[best], float(fit[best])

    # ---------- BA ----------
    def step_ba(self, seed_x, bees=24, elite=5, recruits=3, radius=0.06, iters=6, stagn_limit=3):
        pop = np.array([clip_params(seed_x + rand_vec(self.rng, radius)) for _ in range(bees)])
        pop[0] = seed_x.copy()
        for i in range(bees):
            pop[i], _, _, _, _ = self.feas.ensure_feasible(pop[i], max_tries=6, step=radius)
        fit = np.array([self.obj.evaluate(xx) for xx in pop])

        best_x = pop[fit.argmax()].copy()
        best_f = float(fit.max())
        stagn = 0

        for _ in range(iters):
            idx = np.argsort(-fit)[:elite]
            new = []
            for i in idx:
                center = pop[i]
                for _r in range(recruits):
                    cand = clip_params(center + rand_vec(self.rng, radius))
                    cand, _, _, _, _ = self.feas.ensure_feasible(cand, max_tries=6, step=radius)
                    new.append(cand)
            while len(new) < bees:
                x = clip_params(seed_x + rand_vec(self.rng, radius))
                x, _, _, _, _ = self.feas.ensure_feasible(x, max_tries=4, step=radius)
                new.append(x)

            pop = np.array(new[:bees])
            fit = np.array([self.obj.evaluate(xx) for xx in pop])

            if fit.max() > best_f:
                best_x = pop[fit.argmax()].copy()
                best_f = float(fit.max())
                stagn = 0
            else:
                stagn += 1
                if stagn >= stagn_limit:
                    # scouts: reinitialize half broadly
                    for k in range(bees // 2):
                        pop[k] = clip_params(self.rng.uniform(PARAM_BOUNDS[0], PARAM_BOUNDS[1], NDIMS))
                        pop[k], _, _, _, _ = self.feas.ensure_feasible(pop[k], max_tries=4, step=0.08)
                        fit[k] = self.obj.evaluate(pop[k])
                    stagn = 0
        return best_x, best_f

    # ---------- Orchestrated outer loop with CSV logging ----------
    def orchestrate(self, outer_iters=10,
                    aco_cfg=None, pso_cfg=None, ga_cfg=None, ba_cfg=None,
                    stop_patience=4, stop_tol=1e-3):
        aco_cfg = aco_cfg or {}
        pso_cfg = pso_cfg or {}
        ga_cfg  = ga_cfg or {}
        ba_cfg  = ba_cfg or {}

        # initialize elite (feasible)
        elite_x = clip_params(self.rng.uniform(PARAM_BOUNDS[0], PARAM_BOUNDS[1], NDIMS))
        elite_x, elite_f, _, _, _ = self.feas.ensure_feasible(elite_x)
        history = [elite_f]
        best_overall = elite_f
        no_improve = 0
        t0 = time.time()

        for it in range(1, outer_iters + 1):

            # 1) ACO
            ts = time.time()
            x_aco, f_aco = self.step_aco(elite_x, **aco_cfg)
            # log ACO
            append_csv_row(self.log_path, {
                "iteration": it,
                "method": "ACO",
                "fidelity": f_aco,
                "feasible": "yes",   # step_* already repairs before scoring
                "repaired": "maybe",
                "elapsed_s": round(time.time() - ts, 3),
            })
            if f_aco > elite_f:
                elite_x, elite_f = x_aco, f_aco

            # 2) PSO
            ts = time.time()
            x_pso, f_pso = self.step_pso(elite_x, **pso_cfg)
            append_csv_row(self.log_path, {
                "iteration": it,
                "method": "PSO",
                "fidelity": f_pso,
                "feasible": "yes",
                "repaired": "maybe",
                "elapsed_s": round(time.time() - ts, 3),
            })
            if f_pso > elite_f:
                elite_x, elite_f = x_pso, f_pso

            # 3) GA
            ts = time.time()
            x_ga, f_ga = self.step_ga(elite_x, **ga_cfg)
            append_csv_row(self.log_path, {
                "iteration": it,
                "method": "GA",
                "fidelity": f_ga,
                "feasible": "yes",
                "repaired": "maybe",
                "elapsed_s": round(time.time() - ts, 3),
            })
            if f_ga > elite_f:
                elite_x, elite_f = x_ga, f_ga

            # 4) BA
            ts = time.time()
            x_ba, f_ba = self.step_ba(elite_x, **ba_cfg)
            append_csv_row(self.log_path, {
                "iteration": it,
                "method": "BA",
                "fidelity": f_ba,
                "feasible": "yes",
                "repaired": "maybe",
                "elapsed_s": round(time.time() - ts, 3),
            })
            if f_ba > elite_f:
                elite_x, elite_f = x_ba, f_ba

            history.append(elite_f)
            # early stopping on plateau
            if elite_f > best_overall + stop_tol:
                best_overall = elite_f
                no_improve = 0
            else:
                no_improve += 1
                if no_improve >= stop_patience:
                    break

        return {
            "theta": elite_x.tolist(),
            "score": float(elite_f),
            "history": [float(x) for x in history],
            "elapsed_s": round(time.time() - t0, 3),
            "log_file": self.log_path,
        }

# ------------------- CLI -------------------
def parse_args():
    p = argparse.ArgumentParser(description="Faithful Algorithm-3 hybrid optimizer on Amazon Braket dm1 (with CSV logging)")
    p.add_argument("--iters", type=int, default=6, help="Outer iterations (ACO->PSO->GA->BA cycles)")
    p.add_argument("--shots", type=int, default=0, help="0 for analytic dm1; 4000 to match paper tables")
    p.add_argument("--no-zne", action="store_true", help="Disable ZNE")
    p.add_argument("--lam0", type=float, default=LAMBDA0)
    p.add_argument("--gam1", type=float, default=GAMMA1)
    p.add_argument("--seed", type=int, default=None)

    # Feasibility thresholds
    p.add_argument("--F_threshold", type=float, default=0.95)
    p.add_argument("--tau", type=float, default=0.90)
    p.add_argument("--eps", type=float, default=0.02)

    # ACO config
    p.add_argument("--aco-ants", type=int, default=20)
    p.add_argument("--aco-step", type=float, default=0.12)
    p.add_argument("--aco-evap", type=float, default=0.2)
    p.add_argument("--aco-strength", type=float, default=1.0)

    # PSO config
    p.add_argument("--pso-swarm", type=int, default=20)
    p.add_argument("--pso-iters", type=int, default=6)

    # GA config
    p.add_argument("--ga-pop", type=int, default=30)
    p.add_argument("--ga-iters", type=int, default=6)
    p.add_argument("--ga-cx", type=float, default=0.85)
    p.add_argument("--ga-mut", type=float, default=0.12)

    # BA config
    p.add_argument("--ba-bees", type=int, default=24)
    p.add_argument("--ba-elite", type=int, default=5)
    p.add_argument("--ba-recruits", type=int, default=3)
    p.add_argument("--ba-radius", type=float, default=0.06)
    p.add_argument("--ba-iters", type=int, default=6)
    p.add_argument("--ba-stagn", type=int, default=3)

    # Early stop
    p.add_argument("--patience", type=int, default=4)
    p.add_argument("--tol", type=float, default=1e-3)

    # Log file path (optional)
    p.add_argument("--log", type=str, default=LOG_FILE)

    return p.parse_args()

def main():
    args = parse_args()
    obj = NoiseAwareObjective(
        shots=args.shots,
        use_zne=not args.no_zne,
        zne_scales=DEFAULT_ZNE_SCALES,
        lam0=args.lam0,
        gam1=args.gam1,
    )
    feas = Feasibility(
        objective=obj,
        F_threshold=args.F_threshold,
        tau=args.tau,
        eps=args.eps,
        rng=args.seed,
    )
    opt = FaithfulHybridOptimizer(objective=obj, feasibility=feas, log_path=args.log, rng=args.seed)

    # wire ACO config knobs chosen by user
    opt.ph_evap = args.aco_evap
    opt.ph_strength = args.aco_strength

    result = opt.orchestrate(
        outer_iters=args.iters,
        aco_cfg={"ants": args.aco_ants, "step": args.aco_step},
        pso_cfg={"swarm": args.pso_swarm, "iters": args.pso_iters},
        ga_cfg={"pop_size": args.ga_pop, "iters": args.ga_iters,
                "cx_prob": args.ga_cx, "mut_prob": args.ga_mut},
        ba_cfg={"bees": args.ba_bees, "elite": args.ba_elite, "recruits": args.ba_recruits,
                "radius": args.ba_radius, "iters": args.ba_iters, "stagn_limit": args.ba_stagn},
        stop_patience=args.patience, stop_tol=args.tol
    )
    print(result)

if __name__ == "__main__":
    main()
