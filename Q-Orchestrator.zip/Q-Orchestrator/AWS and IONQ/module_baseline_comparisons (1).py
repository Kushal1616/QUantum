# module_baseline_comparisons.py
# -------------------------------------------------------------
# Baseline comparison between a Braket circuit and a Qiskit-3
# transpiled version on AWS Braket (dm1). Runnable as a script.
#
# Output: baseline_log.csv
# Columns: method, fidelity, elapsed_s
#
# Usage:
#   python module_baseline_comparisons.py --shots 1500
#   python module_baseline_comparisons.py --shots 1500 --outfile my_baselines.csv
#   python module_baseline_comparisons.py --shots 1500 --no-qiskit  # skip Qiskit line
# -------------------------------------------------------------

import csv
import time
import math
import argparse
from typing import Callable, Optional

from braket.circuits import Circuit
from braket_common import circuit_summary, get_device, zz_expectation_result_type  # your helpers

# Optional Qiskit import (we degrade gracefully if missing)
try:
    from qiskit import QuantumCircuit, transpile
    _HAS_QISKIT = True
except Exception:
    QuantumCircuit = None  # type: ignore
    _HAS_QISKIT = False


# ------------------------------------------------------------------
# Default circuit builder (if caller doesn't provide one)
# Simple 2-qubit correlation test used in your Section 4.4 workflow
# ------------------------------------------------------------------
def default_build() -> Circuit:
    c = Circuit()
    # Example: prepare a correlated 2-qubit state and measure <Z0 Z1>
    c.h(0).cnot(0, 1)
    c.add_result_type(zz_expectation_result_type())  # ⟨Z0 Z1⟩
    return c


class BaselineComparisons:
    """
    Compare a Braket circuit vs a Qiskit-transpiled (optimization_level=3) variant.
    - Structural summaries: depth, 2Q gate count, total gate count.
    - Optional execution on dm1 to obtain ⟨Z0Z1⟩ and elapsed time.
    """

    def __init__(self, device_name: str = "dm1"):
        self.device = get_device(device_name)

    # --------------------- Conversion helpers ---------------------

    def _braket_to_qiskit(self, braket_circ: Circuit) -> "QuantumCircuit":
        """
        Convert a subset of Braket Circuit to Qiskit QuantumCircuit for transpilation.
        Non-unitary ops (noise, barriers, measurements) are skipped.
        """
        if not _HAS_QISKIT:
            raise RuntimeError("Qiskit not installed. `pip install qiskit`")

        # Determine the number of qubits actually addressed
        max_q = 0
        for ins in getattr(braket_circ, "instructions", []):
            for q in ins.target:
                max_q = max(max_q, int(q))
        n = (max_q + 1) if getattr(braket_circ, "instructions", None) else 1

        qc = QuantumCircuit(n)

        for ins in getattr(braket_circ, "instructions", []):
            name = ins.operator.name.lower()
            t = [int(x) for x in ins.target]

            # 1q gates
            if name == "h":
                qc.h(t[0])
            elif name == "x":
                qc.x(t[0])
            elif name == "y":
                qc.y(t[0])
            elif name == "z":
                qc.z(t[0])
            elif name == "rx":
                qc.rx(float(ins.operator.angle), t[0])
            elif name == "ry":
                qc.ry(float(ins.operator.angle), t[0])
            elif name == "rz":
                qc.rz(float(ins.operator.angle), t[0])

            # 2q gates
            elif name in ("cnot", "cx"):
                qc.cx(t[0], t[1])
            elif name == "cz":
                qc.cz(t[0], t[1])

            # Skip anything else (noise/result types/barriers etc.)
            else:
                pass

        return qc

    def _qiskit_to_braket(self, qc: "QuantumCircuit") -> Circuit:
        """
        Convert a Qiskit QuantumCircuit back to a Braket Circuit (unitary subset).
        Uses an explicit mapping from qiskit.Qubit objects to integer wires.
        """
        c = Circuit()
        qmap = {q: i for i, q in enumerate(qc.qubits)}

        for inst, qargs, _ in qc.data:
            name = inst.name.lower()
            qs = [qmap[q] for q in qargs]

            # Skip non-unitaries
            if name in ("measure", "barrier", "delay"):
                continue

            # 1q gates
            if name == "h":
                c.h(qs[0])
            elif name == "x":
                c.x(qs[0])
            elif name == "y":
                c.y(qs[0])
            elif name == "z":
                c.z(qs[0])
            elif name == "rx":
                c.rx(qs[0], float(inst.params[0]))
            elif name == "ry":
                c.ry(qs[0], float(inst.params[0]))
            elif name == "rz":
                c.rz(qs[0], float(inst.params[0]))

            # 2q gates
            elif name in ("cx", "cnot"):
                c.cnot(qs[0], qs[1])
            elif name == "cz":
                c.cz(qs[0], qs[1])

            # Common post-transpile gates: map to nearest Braket equivalents
            elif name in ("p", "u1"):  # phase rotation ~= RZ (global phase ignored)
                c.rz(qs[0], float(inst.params[0]))
            elif name == "sx":        # approx with Rx(pi/2) if needed
                c.rx(qs[0], math.pi / 2.0)
            else:
                # Rare after opt_level=3; ignore exotic single-qubit templates
                pass

        return c

    def qiskit_optimize(self, braket_circ: Circuit, optimization_level: int = 3) -> Circuit:
        if not _HAS_QISKIT:
            raise RuntimeError("Qiskit not installed. `pip install qiskit`")
        qc = self._braket_to_qiskit(braket_circ)
        qc_opt = transpile(qc, basis_gates=None, optimization_level=optimization_level)
        return self._qiskit_to_braket(qc_opt)

    # ------------------------ Public compare ----------------------

    def compare(
        self,
        build_fn: Callable[[], Circuit],
        shots: int = 1500,
        run_dm1: bool = True,
        include_qiskit: bool = True,
    ):
        """
        Compare Original circuit vs Qiskit-optimized:
        returns a list of rows suitable for CSV with (method, fidelity, elapsed_s).
        """
        rows = []

        # Original circuit (add result type for ⟨Z0Z1⟩ if not present)
        original = build_fn()
        has_rt = any(rt.observable == "zz" for rt in getattr(original, "result_types", []))
        if not has_rt:
            original = original.copy()
            original.add_result_type(zz_expectation_result_type())

        # Structural summary
        s_orig = circuit_summary(original)
        print(f"[Original] depth={s_orig['depth']}  2q={s_orig['gates_2q']}  total={s_orig['gates_total']}")

        # Execute Original
        if run_dm1:
            t0 = time.perf_counter()
            res = self.device.run(original, shots=shots).result()
            wall = time.perf_counter() - t0
            v = float(res.values[0])
            print(f"Original  <Z0Z1>={v:.6f}  wall={wall:.2f}s")
            rows.append({"method": "Original", "fidelity": v, "elapsed_s": round(wall, 3)})

        # Qiskit transpile + execute
        if include_qiskit and _HAS_QISKIT:
            optimized = self.qiskit_optimize(original)
            optimized.add_result_type(zz_expectation_result_type())
            s_opt = circuit_summary(optimized)
            print(f"[Qiskit-3] depth={s_opt['depth']}  2q={s_opt['gates_2q']}  total={s_opt['gates_total']}")

            if run_dm1:
                t0 = time.perf_counter()
                res = self.device.run(optimized, shots=shots).result()
                wall = time.perf_counter() - t0
                v = float(res.values[0])
                print(f"Qiskit-3 <Z0Z1>={v:.6f}  wall={wall:.2f}s")
                rows.append({"method": "Qiskit-3", "fidelity": v, "elapsed_s": round(wall, 3)})

        elif include_qiskit and not _HAS_QISKIT:
            print("[WARN] Qiskit not installed; skipping Qiskit-3 comparison.")

        return rows


# ----------------------------- CLI --------------------------------
def _write_rows_csv(rows, outfile: str):
    need_header = False
    try:
        with open(outfile, "r", newline="") as _:
            pass
    except FileNotFoundError:
        need_header = True

    with open(outfile, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["method", "fidelity", "elapsed_s"])
        if need_header:
            w.writeheader()
        for r in rows:
            w.writerow(r)


def main():
    ap = argparse.ArgumentParser(description="Compare Braket circuit vs Qiskit-3 baseline.")
    ap.add_argument("--shots", type=int, default=1500, help="Number of shots for dm1 execution.")
    ap.add_argument("--outfile", type=str, default="baseline_log.csv", help="CSV file to append results.")
    ap.add_argument("--no-qiskit", action="store_true", help="Skip Qiskit transpiler comparison.")
    args = ap.parse_args()

    comp = BaselineComparisons(device_name="dm1")

    # In your project, you can swap `default_build` with your own builder function.
    rows = comp.compare(
        build_fn=default_build,
        shots=args.shots,
        run_dm1=True,
        include_qiskit=not args.no_qiskit,
    )

    if rows:
        _write_rows_csv(rows, args.outfile)
        print(f"Wrote {len(rows)} row(s) to {args.outfile}")
    else:
        print("No rows produced (did not run?).")


if __name__ == "__main__":
    main()
