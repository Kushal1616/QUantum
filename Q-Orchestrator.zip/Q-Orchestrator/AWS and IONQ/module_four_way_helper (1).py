# module_four_way_helper.py
import time
from braket_common import get_device, circuit_summary, zz_expectation_result_type

def four_way_compare(build_fn, shots=4000, device_name="dm1"):
    from module_baseline_comparisons import BaselineComparisons
    bc = BaselineComparisons(device_name=device_name)
    dev = get_device(device_name)

    # 1) Original baseline
    c_orig = build_fn().copy(); c_orig.add_result_type(zz_expectation_result_type())

    # 2) Qiskit-3(original)
    c_qisk = bc.qiskit_optimize(c_orig).copy(); c_qisk.add_result_type(zz_expectation_result_type())

    # 3) Your optimized (observable-aware)
    from module_noise_aware_opt_braket import NoiseAwareOptimizerBraket
    mod = NoiseAwareOptimizerBraket(outdir=".")
    c_opt = mod._optimized_minimal() if hasattr(mod, "_optimized_minimal") else mod._depth_optimized()
    c_opt = c_opt.copy();  # already includes ZZ result type

    # 4) Qiskit-3(your optimized) – usually identical
    c_opt_qisk = bc.qiskit_optimize(c_opt).copy(); c_opt_qisk.add_result_type(zz_expectation_result_type())

    # ---- Structural summaries ----
    def S(c): return circuit_summary(c)
    so, sq, sop, soq = S(c_orig), S(c_qisk), S(c_opt), S(c_opt_qisk)

    print("\n[Four-way structural]")
    print(f"Original            : depth={so['depth']}, 2q={so['gates_2q']}, total={so['gates_total']}")
    print(f"Qiskit-3(original)  : depth={sq['depth']}, 2q={sq['gates_2q']}, total={sq['gates_total']}")
    print(f"Your optimized      : depth={sop['depth']}, 2q={sop['gates_2q']}, total={sop['gates_total']}")
    print(f"Qiskit-3(optimized) : depth={soq['depth']}, 2q={soq['gates_2q']}, total={soq['gates_total']}")

    # ---- Hardware (dm1) ----
    def run(c):
        t0 = time.perf_counter()
        r = dev.run(c, shots=shots).result()
        dt = time.perf_counter() - t0
        return float(r.values[0]), dt

    v1, t1 = run(c_orig)
    v2, t2 = run(c_qisk)
    v3, t3 = run(c_opt)
    v4, t4 = run(c_opt_qisk)

    print("\n[Four-way dm1 results]")
    print(f"Original            : <Z0Z1>={v1:.4f}, wall={t1:.2f}s")
    print(f"Qiskit-3(original)  : <Z0Z1>={v2:.4f}, wall={t2:.2f}s")
    print(f"Your optimized      : <Z0Z1>={v3:.4f}, wall={t3:.2f}s")
    print(f"Qiskit-3(optimized) : <Z0Z1>={v4:.4f}, wall={t4:.2f}s")
