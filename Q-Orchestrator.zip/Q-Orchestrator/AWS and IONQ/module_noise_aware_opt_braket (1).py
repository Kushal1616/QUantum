# module_noise_aware_opt_braket.py
# Module 2 — ZNE & depth-optimized comparison on Amazon Braket (defaults to AWS dm1; saves PNGs).

import os
import numpy as np
import matplotlib.pyplot as plt

from braket_common import (
    Circuit,
    dev,
    zz_expectation_result_type,
    circuit_summary,
)

class NoiseAwareOptimizerBraket:
    """
    - Builds a small Bell circuit with explicit depolarizing + amplitude-damping noise.
    - Performs linear ZNE by scaling (lambda, gamma) and extrapolating to zero noise.
    - Compares with a toy "depth-optimized" variant.
    Saves plots to PNGs.
    """

    def __init__(self, outdir: str = "."):
        self.outdir = outdir
        # Baseline noise parameters for scale = 1.0 (Option B parameterization).
        self.lam0_base  = 0.01   # depolarizing on qubit 0
        self.gamma1_base= 0.10   # amplitude damping on qubit 1
        self.lam2_base  = 0.10   # depolarizing on aux qubit 2
        self.lam3_base  = 0.20   # depolarizing on aux qubit 3

    # -------------------------------------------------------------------------
    # Circuit builders
    # -------------------------------------------------------------------------
    def _circuit_with_scaled_noise(self, scale: float = 1.0, use_noise: bool = True) -> Circuit:
        """
        Build the main circuit. If use_noise=False, no explicit noise ops (hardware-safe).
        """
        c = Circuit().h(0).cnot(0, 1)
        if use_noise:
            lam0  = self.lam0_base   * scale
            gamma = self.gamma1_base * scale
            lam2  = self.lam2_base   * scale
            lam3  = self.lam3_base   * scale

            c.depolarizing(0, probability=lam0)
            c.amplitude_damping(1, gamma=gamma)
            c.cnot(0, 2).cnot(1, 3)
            c.depolarizing(2, probability=lam2)
            c.depolarizing(3, probability=lam3)
        else:
            # hardware-safe variant: same entanglers but no explicit noise channels
            c.cnot(0, 2).cnot(1, 3)
        c.add_result_type(zz_expectation_result_type())
        return c

    def _depth_optimized(self) -> Circuit:
        """
        Depth-optimized toy variant (no primary-qubit noise; only readout-like deps).
        """
        c = Circuit().h(0).cnot(0, 1).cnot(0, 2).cnot(1, 3)
        # Readout depolarizing on auxiliaries
        c.depolarizing(2, probability=self.lam2_base)
        c.depolarizing(3, probability=self.lam3_base)
        c.add_result_type(zz_expectation_result_type())
        return c

    # -------------------------------------------------------------------------
    # ZNE (linear) utility
    # -------------------------------------------------------------------------
    def _zne_linear(self, scales=(1.0, 0.5, 0.1)):
        """
        Run ⟨Z0Z1⟩ at several scaled noise levels, fit a line vs. scale,
        and extrapolate to zero-noise (scale → 0). Returns (zne_est, vals).
        """
        vals = []
        for s in scales:
            task = dev.run(self._circuit_with_scaled_noise(scale=s, use_noise=True), shots=0)
            vals.append(task.result().values[0])

        # Linear fit y = a*x + b; evaluate at x=0 -> y0 = b
        coeffs = np.polyfit(scales, vals, deg=1)
        y0 = float(np.polyval(coeffs, 0.0))
        y0 = max(-1.0, min(1.0, y0))  # Clamp to physical range

        # Plot ZNE trend → save PNG
        xs = np.array(scales)
        ys = np.array(vals)
        fig, ax = plt.subplots(figsize=(8, 5))
        ax.plot(xs, ys, "o-")
        xline = np.linspace(0.0, max(xs), 200)
        yline = np.polyval(coeffs, xline)
        ax.plot(xline, yline, "--")
        ax.axvline(0.0, linestyle=":")
        ax.axhline(y0, linestyle=":")
        ax.set_xlabel("Noise scale")
        ax.set_ylabel("⟨Z₀ Z₁⟩")
        ax.set_title("ZNE (linear) — Extrapolation to Zero Noise")
        ax.grid(True)
        plt.tight_layout()
        os.makedirs(self.outdir, exist_ok=True)
        out_zne = os.path.join(self.outdir, "module2_zne_trend.png")
        plt.savefig(out_zne, dpi=200, bbox_inches="tight")
        plt.close(fig)
        print(f"[Module 2] Saved ZNE trend → {out_zne}")

        return y0, vals

    # -------------------------------------------------------------------------
    # Public entry point
    # -------------------------------------------------------------------------
    def run_and_visualize(self):
        """
        - Run original (scale=1) noisy circuit (managed dm1).
        - Run linear ZNE over a few scales.
        - Run the depth-optimized variant.
        - Save a bar chart comparing the three.
        """
        # Original noisy
        task = dev.run(self._circuit_with_scaled_noise(scale=1.0, use_noise=True), shots=0)
        original = float(task.result().values[0])

        # Linear ZNE
        zne_est, seq = self._zne_linear(scales=(1.0, 0.5, 0.1))

        # Depth-optimized variant
        task2 = dev.run(self._depth_optimized(), shots=0)
        depth_val = float(task2.result().values[0])

        # Comparison chart → save PNG
        labels = ["Original noisy", "ZNE estimated", "Depth-optimized"]
        vals = [original, zne_est, depth_val]

        fig, ax = plt.subplots(figsize=(8, 5))
        bars = ax.bar(labels, vals)
        for b in bars:
            h = b.get_height()
            ax.text(b.get_x() + b.get_width() / 2, h, f"{h:.4f}",
                    ha="center", va="bottom")
        ymin = min(vals) - 0.05
        ymax = max(1.05, max(vals) + 0.05)
        ax.set_ylim(ymin, ymax)
        ax.set_ylabel("⟨Z₀ Z₁⟩")
        ax.set_title("Noise-Aware Optimization — Braket (Module 2)")
        plt.tight_layout()
        os.makedirs(self.outdir, exist_ok=True)
        out_bar = os.path.join(self.outdir, "module2_comparison.png")
        plt.savefig(out_bar, dpi=200, bbox_inches="tight")
        plt.close(fig)
        print(f"[Module 2] Saved comparison → {out_bar}")

    # -------- Depth / gate benchmark — structural (addresses reviewer #2) --------
    def depth_benchmark(self):
        """
        Compare an unoptimized fan-out circuit (uses auxiliaries) vs a minimal circuit
        that yields the same observable ⟨Z0 Z1⟩ without auxiliaries.
        This demonstrates structural depth / 2Q gate reductions.
        """
        from braket.circuits import Circuit
        from braket_common import circuit_summary, zz_expectation_result_type

        # Unoptimized (fan-out) baseline: 3 two-qubit gates
        base = (Circuit()
                .h(0)
                .cnot(0, 1)      # entangle 0–1 (needed for ⟨Z0 Z1⟩)
                .cnot(0, 2)      # unnecessary fan-out to aux
                .cnot(1, 3)      # unnecessary fan-out to aux
                .add_result_type(zz_expectation_result_type()))

        # Optimized minimal: only what is needed for ⟨Z0 Z1⟩ → 1 two-qubit gate
        opt = (Circuit()
               .h(0)
               .cnot(0, 1)
               .add_result_type(zz_expectation_result_type()))

        sb = circuit_summary(base)
        so = circuit_summary(opt)

        def pct(a, b):
            return 0.0 if a == 0 else 100.0 * (a - b) / a

        print("\n[Depth / gate benchmark — structural]")
        print(f"Baseline (fan-out): depth={sb['depth']}, 1q={sb['gates_1q']}, 2q={sb['gates_2q']}, total={sb['gates_total']}")
        print(f"Optimized (minimal): depth={so['depth']}, 1q={so['gates_1q']}, 2q={so['gates_2q']}, total={so['gates_total']}")
        print(f"Depth reduction:   {pct(sb['depth'], so['depth']):.1f}%")
        print(f"2Q gate reduction: {pct(sb['gates_2q'], so['gates_2q']):.1f}%")
