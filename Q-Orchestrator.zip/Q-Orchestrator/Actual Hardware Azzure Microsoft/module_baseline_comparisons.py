# module_baseline_comparisons.py  (Azure Quantum edition)
# ------------------------------------------------------------
# Baseline comparisons for your 2-qubit param circuit on Azure Quantum backends.
#
# Baselines:
#   1) RANDOM (hardware): random samples within bounds, keep best
#   2) SPSA   (hardware): stochastic gradient, low query cost per iter
#   3) IDEAL  (analytic): noiseless upper bound via Statevector + SciPy minimize
#
# Output:
#   - CSV with per-iteration metrics (method, iter, zz, score, theta..., elapsed_s)
#   - A small JSON summary printed to stdout at the end
#
# Depends on braket_common.py (Azure edition):
#   from braket_common import qc_create, qc_measure_all, run, Q, ezz
# ------------------------------------------------------------

from __future__ import annotations

import os
import csv
import math
import json
import time
import argparse
from dataclasses import dataclass
from typing import Optional, Tuple, Dict, List

import numpy as np

from braket_common import (
    qc_create, qc_measure_all, run, Q, ezz
)

# For the IDEAL baseline (noiseless, analytic)
from qiskit.quantum_info import Statevector, SparsePauliOp
from qiskit import QuantumCircuit

# Optional SciPy for the IDEAL local optimizer (recommended)
try:
    from scipy.optimize import minimize
    _HAS_SCIPY = True
except Exception:
    _HAS_SCIPY = False


# ----------------------------
# Shared config and helpers
# ----------------------------

NDIMS = 4
PARAM_BOUNDS = (-math.pi, math.pi)

CSV_HEADER = [
    "method", "iter", "zz", "score",
    "theta0", "theta1", "theta2", "theta3", "elapsed_s"
]


@dataclass
class EvalConfig:
    backend_name: str = os.getenv("AZURE_QUANTUM_BACKEND", "ionq.simulator")
    shots: int = 4000
    reverse_bits: bool = False
    opt_level: int = 1
    seed_transpiler: Optional[int] = None


def clip_params(x):
    lo, hi = PARAM_BOUNDS
    return np.clip(np.array(x, dtype=float), lo, hi)


def score_from_zz(zz: float) -> float:
    """Map ⟨Z0Z1⟩ in [-1,1] to a simple 0..1 'fidelity-like' score."""
    return 0.5 * (1.0 + float(zz))


def append_row(path: str, row: Dict):
    new = not os.path.exists(path)
    with open(path, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=CSV_HEADER)
        if new:
            w.writeheader()
        w.writerow(row)


# ----------------------------
# Circuit builders (shared)
# ----------------------------

def build_param_circuit(theta: np.ndarray, measure: bool = True) -> QuantumCircuit:
    """
    Your standard 2-qubit param pattern:
        RX(0,θ0) · RY(1,θ1) · CX(0,1) · RZ(0,θ2) · RX(1,θ3)
    """
    th = clip_params(theta)
    qc = qc_create(2, with_classical=measure, name="baseline_param")
    Q.rx(qc, float(th[0]), 0)
    Q.ry(qc, float(th[1]), 1)
    Q.cx(qc, 0, 1)
    Q.rz(qc, float(th[2]), 0)
    Q.rx(qc, float(th[3]), 1)
    if measure:
        qc_measure_all(qc)
    return qc


def hardware_zz(theta: np.ndarray, cfg: EvalConfig) -> float:
    """
    Evaluate ⟨Z0Z1⟩ on the chosen Azure backend with finite shots.
    """
    qc = build_param_circuit(theta, measure=True)
    rr = run(
        qc,
        backend_name=cfg.backend_name,
        shots=cfg.shots,
        reverse_bits=cfg.reverse_bits,
        transpile_optimization_level=cfg.opt_level,
        seed_transpiler=cfg.seed_transpiler,
    )
    return float(ezz(rr.counts, 0, 1))


def ideal_zz(theta: np.ndarray) -> float:
    """
    Noiseless, measurement-free analytic ⟨Z0Z1⟩ using Statevector.
    Gives an upper bound of what hardware could achieve.
    """
    qc = build_param_circuit(theta, measure=False)
    sv = Statevector.from_instruction(qc)
    ZZ = SparsePauliOp.from_list([("ZZ", 1.0)])  # ⟨ZZ⟩
    val = np.real(sv.expectation_value(ZZ))
    # clamp numeric noise
    return float(max(-1.0, min(1.0, val)))


# ----------------------------
# Baseline 1: Random Search (hardware)
# ----------------------------

def baseline_random(cfg: EvalConfig,
                    iters: int = 80,
                    seed: Optional[int] = None,
                    csv_path: str = "baseline_random.csv") -> Dict:
    rng = np.random.default_rng(seed)
    t0 = time.time()

    best_theta = clip_params(rng.uniform(PARAM_BOUNDS[0], PARAM_BOUNDS[1], NDIMS))
    best_zz = hardware_zz(best_theta, cfg)
    best_score = score_from_zz(best_zz)

    append_row(csv_path, {
        "method": "RANDOM", "iter": 0,
        "zz": round(best_zz, 6), "score": round(best_score, 6),
        "theta0": round(float(best_theta[0]), 6),
        "theta1": round(float(best_theta[1]), 6),
        "theta2": round(float(best_theta[2]), 6),
        "theta3": round(float(best_theta[3]), 6),
        "elapsed_s": round(time.time() - t0, 3),
    })

    for k in range(1, iters + 1):
        cand = clip_params(rng.uniform(PARAM_BOUNDS[0], PARAM_BOUNDS[1], NDIMS))
        zz = hardware_zz(cand, cfg)
        sc = score_from_zz(zz)
        if sc > best_score:
            best_theta, best_zz, best_score = cand, zz, sc

        append_row(csv_path, {
            "method": "RANDOM", "iter": k,
            "zz": round(zz, 6), "score": round(sc, 6),
            "theta0": round(float(cand[0]), 6),
            "theta1": round(float(cand[1]), 6),
            "theta2": round(float(cand[2]), 6),
            "theta3": round(float(cand[3]), 6),
            "elapsed_s": round(time.time() - t0, 3),
        })

    return {
        "method": "RANDOM",
        "best_theta": best_theta.tolist(),
        "best_score": float(best_score),
        "elapsed_s": round(time.time() - t0, 3),
        "csv": csv_path,
    }


# ----------------------------
# Baseline 2: SPSA (hardware)
# ----------------------------

@dataclass
class SPSAConfig:
    iters: int = 60
    a: float = 0.2
    c: float = 0.1
    alpha: float = 0.602
    gamma: float = 0.101
    a_min: float = 0.02
    c_min: float = 0.01
    seed: Optional[int] = None


def baseline_spsa(cfg: EvalConfig,
                  spsa: SPSAConfig = SPSAConfig(),
                  theta0: Optional[np.ndarray] = None,
                  csv_path: str = "baseline_spsa.csv") -> Dict:
    rng = np.random.default_rng(spsa.seed)
    t0 = time.time()

    theta = clip_params(theta0 if theta0 is not None
                        else rng.uniform(PARAM_BOUNDS[0], PARAM_BOUNDS[1], NDIMS))

    a0, c0 = float(spsa.a), float(spsa.c)
    alpha, gamma = float(spsa.alpha), float(spsa.gamma)

    # initial eval
    zz0 = hardware_zz(theta, cfg)
    sc0 = score_from_zz(zz0)
    best_theta, best_score = theta.copy(), sc0

    append_row(csv_path, {
        "method": "SPSA", "iter": 0,
        "zz": round(zz0, 6), "score": round(sc0, 6),
        "theta0": round(float(theta[0]), 6),
        "theta1": round(float(theta[1]), 6),
        "theta2": round(float(theta[2]), 6),
        "theta3": round(float(theta[3]), 6),
        "elapsed_s": round(time.time() - t0, 3),
    })

    for k in range(1, spsa.iters + 1):
        a_k = max(spsa.a_min, a0 / (k ** alpha))
        c_k = max(spsa.c_min, c0 / (k ** gamma))
        delta = rng.choice([-1.0, 1.0], size=NDIMS)

        th_plus  = clip_params(theta + c_k * delta)
        th_minus = clip_params(theta - c_k * delta)

        # stochastic gradient via two hardware calls
        zz_p = hardware_zz(th_plus, cfg)
        zz_m = hardware_zz(th_minus, cfg)
        g_hat = (zz_p - zz_m) / (2.0 * c_k * delta + 1e-15)

        theta = clip_params(theta + a_k * g_hat)

        zz_now = hardware_zz(theta, cfg)
        sc_now = score_from_zz(zz_now)
        if sc_now > best_score:
            best_theta, best_score = theta.copy(), sc_now

        append_row(csv_path, {
            "method": "SPSA", "iter": k,
            "zz": round(zz_now, 6), "score": round(sc_now, 6),
            "theta0": round(float(theta[0]), 6),
            "theta1": round(float(theta[1]), 6),
            "theta2": round(float(theta[2]), 6),
            "theta3": round(float(theta[3]), 6),
            "elapsed_s": round(time.time() - t0, 3),
        })

    return {
        "method": "SPSA",
        "best_theta": best_theta.tolist(),
        "best_score": float(best_score),
        "elapsed_s": round(time.time() - t0, 3),
        "csv": csv_path,
    }


# ----------------------------
# Baseline 3: IDEAL local optimizer (analytic upper bound)
# ----------------------------

def _ideal_objective_for_scipy(theta_1d: np.ndarray) -> float:
    """
    SciPy minimize() expects a scalar to MINIMIZE.
    We want to MAXIMIZE score, so we return the NEGATIVE of score.
    """
    th = clip_params(theta_1d)
    zz = ideal_zz(th)
    score = score_from_zz(zz)
    return -float(score)


def baseline_ideal_local(iters: int = 200,
                         seed: Optional[int] = None,
                         csv_path: str = "baseline_ideal.csv") -> Dict:
    """
    Noiseless, measurement-free upper bound using Statevector + SciPy COBYLA/Nelder-Mead.
    If SciPy is not available, falls back to random local search in the analytic model.
    """
    rng = np.random.default_rng(seed)
    t0 = time.time()

    # Initial point
    theta0 = clip_params(rng.uniform(PARAM_BOUNDS[0], PARAM_BOUNDS[1], NDIMS))

    best_theta = theta0.copy()
    best_zz = ideal_zz(best_theta)
    best_score = score_from_zz(best_zz)

    append_row(csv_path, {
        "method": "IDEAL", "iter": 0,
        "zz": round(best_zz, 6), "score": round(best_score, 6),
        "theta0": round(float(best_theta[0]), 6),
        "theta1": round(float(best_theta[1]), 6),
        "theta2": round(float(best_theta[2]), 6),
        "theta3": round(float(best_theta[3]), 6),
        "elapsed_s": round(time.time() - t0, 3),
    })

    if _HAS_SCIPY:
        # Try COBYLA; if it fails, fallback to Nelder-Mead
        res = minimize(
            _ideal_objective_for_scipy,
            x0=theta0,
            method="COBYLA",
            options={"maxiter": iters, "rhobeg": 0.2, "catol": 1e-6},
        )
        if not res.success:
            res = minimize(
                _ideal_objective_for_scipy,
                x0=theta0,
                method="Nelder-Mead",
                options={"maxiter": iters, "initial_simplex": None, "xatol": 1e-4, "fatol": 1e-4},
            )
        theta_star = clip_params(res.x)
        zz_star = ideal_zz(theta_star)
        sc_star = score_from_zz(zz_star)

        append_row(csv_path, {
            "method": "IDEAL", "iter": iters,
            "zz": round(zz_star, 6), "score": round(sc_star, 6),
            "theta0": round(float(theta_star[0]), 6),
            "theta1": round(float(theta_star[1]), 6),
            "theta2": round(float(theta_star[2]), 6),
            "theta3": round(float(theta_star[3]), 6),
            "elapsed_s": round(time.time() - t0, 3),
        })

        if sc_star > best_score:
            best_theta, best_score = theta_star, sc_star
    else:
        # Fallback: simple random local perturbations in the analytic model
        step = 0.25
        for k in range(1, iters + 1):
            cand = clip_params(best_theta + rng.uniform(-step, step, NDIMS))
            zz = ideal_zz(cand)
            sc = score_from_zz(zz)
            if sc > best_score:
                best_theta, best_score = cand, sc
            step *= 0.995  # anneal
            append_row(csv_path, {
                "method": "IDEAL", "iter": k,
                "zz": round(zz, 6), "score": round(sc, 6),
                "theta0": round(float(cand[0]), 6),
                "theta1": round(float(cand[1]), 6),
                "theta2": round(float(cand[2]), 6),
                "theta3": round(float(cand[3]), 6),
                "elapsed_s": round(time.time() - t0, 3),
            })

    return {
        "method": "IDEAL",
        "best_theta": best_theta.tolist(),
        "best_score": float(best_score),
        "elapsed_s": round(time.time() - t0, 3),
        "csv": csv_path,
    }


# ----------------------------
# CLI
# ----------------------------

def parse_args():
    p = argparse.ArgumentParser(description="Baseline comparisons on Azure Quantum (Random, SPSA, Ideal)")
    # Shared hardware config
    p.add_argument("--backend", type=str, default=os.getenv("AZURE_QUANTUM_BACKEND", "ionq.simulator"),
                   help="Azure backend, e.g., ionq.simulator, ionq.qpu, quantinuum.h1-1e")
    p.add_argument("--shots", type=int, default=4000)
    p.add_argument("--opt-level", type=int, default=1)
    p.add_argument("--seed-transpiler", type=int, default=None)

    # Methods to run
    p.add_argument("--run", type=str, nargs="+", default=["random", "spsa", "ideal"],
                   choices=["random", "spsa", "ideal"],
                   help="Which baselines to run")

    # Iterations
    p.add_argument("--random-iters", type=int, default=80)
    p.add_argument("--spsa-iters", type=int, default=60)
    p.add_argument("--ideal-iters", type=int, default=200)

    # Seeds and logs
    p.add_argument("--seed", type=int, default=None)
    p.add_argument("--random-log", type=str, default="baseline_random.csv")
    p.add_argument("--spsa-log", type=str, default="baseline_spsa.csv")
    p.add_argument("--ideal-log", type=str, default="baseline_ideal.csv")

    # Optional SPSA hyperparams
    p.add_argument("--spsa-a", type=float, default=0.2)
    p.add_argument("--spsa-c", type=float, default=0.1)
    p.add_argument("--spsa-alpha", type=float, default=0.602)
    p.add_argument("--spsa-gamma", type=float, default=0.101)
    p.add_argument("--spsa-a-min", type=float, default=0.02)
    p.add_argument("--spsa-c-min", type=float, default=0.01)

    return p.parse_args()


def main():
    args = parse_args()

    cfg = EvalConfig(
        backend_name=args.backend,
        shots=args.shots,
        reverse_bits=False,
        opt_level=args.opt_level,
        seed_transpiler=args.seed_transpiler,
    )

    results: List[Dict] = []

    if "random" in args.run:
        res = baseline_random(
            cfg=cfg,
            iters=args.random_iters,
            seed=args.seed,
            csv_path=args.random_log
        )
        results.append(res)

    if "spsa" in args.run:
        spsa_cfg = SPSAConfig(
            iters=args.spsa_iters,
            a=args.spsa_a,
            c=args.spsa_c,
            alpha=args.spsa_alpha,
            gamma=args.spsa_gamma,
            a_min=args.spsa_a_min,
            c_min=args.spsa_c_min,
            seed=args.seed
        )
        res = baseline_spsa(
            cfg=cfg,
            spsa=spsa_cfg,
            theta0=None,
            csv_path=args.spsa_log
        )
        results.append(res)

    if "ideal" in args.run:
        res = baseline_ideal_local(
            iters=args.ideal_iters,
            seed=args.seed,
            csv_path=args.ideal_log
        )
        results.append(res)

    # Print a compact JSON summary (one object per method)
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
