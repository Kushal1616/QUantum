# orchestrator_braket.py  (Azure Quantum edition)
# ------------------------------------------------------------
# High-level runner for the faithful Algorithm-3 hybrid optimizer on Azure Quantum.
# - Orchestrates the Azure/Qiskit port of your Braket modules
# - Clean CLI for: hybrid run (default), CSV preview, noise simulation fig, scalability benchmarks
# ------------------------------------------------------------

import os
import sys
import argparse
import json
from typing import Optional, Dict, Any

# Core hybrid optimizer (Azure edition you already have)
# From: module_hybrid_opt_braket.py (Azure version I provided)
from module_hybrid_opt_braket import (
    EvalConfig,
    NoiseAwareObjective,
    Feasibility,
    FaithfulHybridOptimizer,
)

DEFAULT_LOG = "hybrid_log.csv"


# ============================================================
# Orchestrator
# ============================================================
class OrchestratorAzure:
    """
    High-level façade around the Azure/Qiskit modules so your scripts/CLI
    don't need to wire every detail each time.
    """

    def __init__(self):
        pass

    # ----------------------------
    # Hybrid (Algorithm-3) runner
    # ----------------------------
    def run_full_hybrid_optimization(
        self,
        *,
        # Outer loop
        iters: int = 6,
        # Backend & shots
        backend: str = None,
        shots: int = 4000,
        opt_level: int = 1,
        seed_transpiler: Optional[int] = None,
        # ZNE toggle (NoiseAwareObjective uses gate-folding ZNE internally)
        use_zne: bool = True,
        # Feasibility (Algorithm-3)
        F_threshold: float = 0.95,
        tau: float = 0.90,
        eps: float = 0.02,
        # ACO
        aco_ants: int = 20,
        aco_step: float = 0.12,
        aco_evap: float = 0.2,
        aco_strength: float = 1.0,
        # PSO
        pso_swarm: int = 20,
        pso_iters: int = 6,
        # GA
        ga_pop: int = 30,
        ga_iters: int = 6,
        ga_cx: float = 0.85,
        ga_mut: float = 0.12,
        # BA
        ba_bees: int = 24,
        ba_elite: int = 5,
        ba_recruits: int = 3,
        ba_radius: float = 0.06,
        ba_iters: int = 6,
        ba_stagn: int = 3,
        # Early stop
        patience: int = 4,
        tol: float = 1e-3,
        # Log
        log_file: str = DEFAULT_LOG,
    ) -> Dict[str, Any]:
        """
        Run the full ACO→PSO→GA→BA cycle for a number of outer iterations, with feasibility/repair and CSV logging.
        Returns a JSON-able dict with 'theta', 'score', 'history', 'elapsed_s', and 'log_file'.
        """

        backend_name = backend or os.getenv("AZURE_QUANTUM_BACKEND", "ionq.simulator")

        # 1) Execution config for Azure/Qiskit
        eval_cfg = EvalConfig(
            backend_name=backend_name,
            shots=shots,
            reverse_bits=False,
            opt_level=opt_level,
            seed_transpiler=seed_transpiler,
        )

        # 2) Objective (noise-aware; ZNE inside)
        objective = NoiseAwareObjective(eval_cfg=eval_cfg, use_zne=bool(use_zne))

        # 3) Feasibility/Repair per Algorithm-3
        feas = Feasibility(
            objective=objective,
            F_threshold=F_threshold,
            tau=tau,
            eps=eps,
            rng=None,
        )

        # 4) Hybrid optimizer orchestrating ACO→PSO→GA→BA
        opt = FaithfulHybridOptimizer(
            objective=objective,
            feasibility=feas,
            log_path=log_file,
            rng=None,
        )

        # ACO pheromone knobs
        opt.ph_evap = aco_evap
        opt.ph_strength = aco_strength

        # 5) Run cycles
        result = opt.orchestrate(
            outer_iters=iters,
            aco_cfg={"ants": aco_ants, "step": aco_step},
            pso_cfg={"swarm": pso_swarm, "iters": pso_iters},
            ga_cfg={
                "pop_size": ga_pop,
                "iters": ga_iters,
                "cx_prob": ga_cx,
                "mut_prob": ga_mut,
            },
            ba_cfg={
                "bees": ba_bees,
                "elite": ba_elite,
                "recruits": ba_recruits,
                "radius": ba_radius,
                "iters": ba_iters,
                "stagn_limit": ba_stagn,
            },
            stop_patience=patience,
            stop_tol=tol,
        )

        # Print to console as JSON for convenience
        print(json.dumps(result, indent=2))
        return result

    # ------------------------------------
    # CSV preview (handy while iterating)
    # ------------------------------------
    def preview_csv(self, path: str = DEFAULT_LOG, tail: int = 20) -> None:
        """Print the last N lines of the CSV log for a quick look."""
        if not os.path.exists(path):
            print(f"[preview_csv] No CSV found at: {path}")
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                lines = f.readlines()
            tail = max(1, int(tail))
            for line in lines[-tail:]:
                print(line.rstrip("\n"))
        except Exception as e:
            print(f"[preview_csv] Error reading {path}: {e}")

    # ------------------------------------
    # Noise simulation figure (Module 1)
    # ------------------------------------
    def run_noise_demo(
        self,
        *,
        outdir: str = ".",
        shots: int = 20000,
        backend_mode: str = "aer",
        azure_backend: Optional[str] = None,
        lam0: float = 0.01,
        gamma1: float = 0.10,
        lam2: float = 0.10,
        lam3: float = 0.20,
    ) -> Optional[str]:
        """
        Call the Azure version of module_noise_simulation_braket.py if present.
        Returns path to saved PNG or None if module unavailable.
        """
        try:
            import module_noise_simulation_braket as m
        except Exception as e:
            print(f"[noise_demo] module_noise_simulation_braket not available: {e}")
            return None

        sim = m.NoiseSimulatorAzure(outdir=outdir)
        sim.lam0 = lam0
        sim.gamma1 = gamma1
        sim.lam2 = lam2
        sim.lam3 = lam3
        return sim.run(shots=shots, backend_mode=backend_mode, azure_backend=azure_backend)

    # ------------------------------------
    # Scalability benchmark (Module 2)
    # ------------------------------------
    def run_scalability(
        self,
        *,
        backend: str = None,
        shots: int = 2000,
        ns: Optional[list] = None,
        out_csv: str = "scaling_results.csv",
    ) -> Optional[str]:
        """
        Call the Azure version of module_scalability_benchmark.py if present.
        """
        try:
            import module_scalability_benchmark as m
        except Exception as e:
            print(f"[scaling] module_scalability_benchmark not available: {e}")
            return None

        backend_name = backend or os.getenv("AZURE_QUANTUM_BACKEND", "ionq.simulator")
        n_list = ns or [2, 3, 4, 5, 6, 8, 10]
        return m.run_scaling(n_list=n_list, backend_name=backend_name, shots=shots, out_csv=out_csv)

    # ------------------------------------
    # Optional: Qiskit/4-way comparisons
    # ------------------------------------
    def compare_against_qiskit(self, **kwargs) -> None:
        """
        If your repo includes baseline/4-way comparison helpers, try to run them.
        Safe no-op if modules are absent.
        """
        # module_baseline_comparisons
        try:
            import module_baseline_comparisons as base
            if hasattr(base, "main"):
                base.main()
            else:
                print("[compare] module_baseline_comparisons has no main(). Skipped.")
        except Exception as e1:
            print(f"[compare] baseline module unavailable: {e1}")

        # module_four_way_helper
        try:
            import module_four_way_helper as four
            if hasattr(four, "main"):
                four.main()
            elif hasattr(four, "run_four_way"):
                four.run_four_way(**kwargs)
            else:
                print("[compare] four-way helper has no entrypoint. Skipped.")
        except Exception as e2:
            print(f"[compare] four-way module unavailable: {e2}")


# ============================================================
# CLI
# ============================================================
def parse_args():
    p = argparse.ArgumentParser(
        description="Orchestrator for faithful Algorithm-3 hybrid optimization on Azure Quantum."
    )
    sub = p.add_subparsers(dest="cmd", required=False)

    # ---- hybrid (default) ----
    ph = sub.add_parser("hybrid", help="Run the full Algorithm-3 hybrid optimizer on Azure Quantum")
    ph.add_argument("--iters", type=int, default=6)
    ph.add_argument("--backend", type=str, default=os.getenv("AZURE_QUANTUM_BACKEND", "ionq.simulator"))
    ph.add_argument("--shots", type=int, default=4000)
    ph.add_argument("--opt-level", type=int, default=1)
    ph.add_argument("--seed-transpiler", type=int, default=None)
    ph.add_argument("--no-zne", action="store_true", help="Disable ZNE in objective")
    # feasibility
    ph.add_argument("--F-threshold", type=float, default=0.95)
    ph.add_argument("--tau", type=float, default=0.90)
    ph.add_argument("--eps", type=float, default=0.02)
    # ACO
    ph.add_argument("--aco-ants", type=int, default=20)
    ph.add_argument("--aco-step", type=float, default=0.12)
    ph.add_argument("--aco-evap", type=float, default=0.2)
    ph.add_argument("--aco-strength", type=float, default=1.0)
    # PSO
    ph.add_argument("--pso-swarm", type=int, default=20)
    ph.add_argument("--pso-iters", type=int, default=6)
    # GA
    ph.add_argument("--ga-pop", type=int, default=30)
    ph.add_argument("--ga-iters", type=int, default=6)
    ph.add_argument("--ga-cx", type=float, default=0.85)
    ph.add_argument("--ga-mut", type=float, default=0.12)
    # BA
    ph.add_argument("--ba-bees", type=int, default=24)
    ph.add_argument("--ba-elite", type=int, default=5)
    ph.add_argument("--ba-recruits", type=int, default=3)
    ph.add_argument("--ba-radius", type=float, default=0.06)
    ph.add_argument("--ba-iters", type=int, default=6)
    ph.add_argument("--ba-stagn", type=int, default=3)
    # early stop and log
    ph.add_argument("--patience", type=int, default=4)
    ph.add_argument("--tol", type=float, default=1e-3)
    ph.add_argument("--log", type=str, default=DEFAULT_LOG)

    # ---- preview ----
    pp = sub.add_parser("preview", help="Tail the hybrid CSV log")
    pp.add_argument("--path", type=str, default=DEFAULT_LOG)
    pp.add_argument("--tail", type=int, default=20)

    # ---- noise (Module 1 figure) ----
    pn = sub.add_parser("noise", help="Generate ideal vs noisy probability figure (local Aer or Azure for 'ideal')")
    pn.add_argument("--outdir", type=str, default=".")
    pn.add_argument("--shots", type=int, default=20000)
    pn.add_argument("--backend-mode", type=str, choices=["aer", "azure"], default="aer")
    pn.add_argument("--azure-backend", type=str, default=None)
    pn.add_argument("--lam0", type=float, default=0.01)
    pn.add_argument("--gamma1", type=float, default=0.10)
    pn.add_argument("--lam2", type=float, default=0.10)
    pn.add_argument("--lam3", type=float, default=0.20)

    # ---- scaling (Module 2 CSV) ----
    ps = sub.add_parser("scaling", help="Run scalability benchmarks and write CSV")
    ps.add_argument("--backend", type=str, default=os.getenv("AZURE_QUANTUM_BACKEND", "ionq.simulator"))
    ps.add_argument("--shots", type=int, default=2000)
    ps.add_argument("--out", type=str, default="scaling_results.csv")
    ps.add_argument("--ns", type=int, nargs="+", default=[2, 3, 4, 5, 6, 8, 10])

    # ---- compare (optional helper if modules exist) ----
    pc = sub.add_parser("compare", help="Run optional Qiskit/baseline comparison helpers (if present)")

    return p.parse_args()


def main():
    args = parse_args()
    orch = OrchestratorAzure()

    # default command: hybrid
    cmd = args.cmd or "hybrid"

    if cmd == "hybrid":
        orch.run_full_hybrid_optimization(
            iters=args.iters,
            backend=args.backend,
            shots=args.shots,
            opt_level=args.opt_level,
            seed_transpiler=args.seed_transpiler,
            use_zne=(not args.no_zne),
            F_threshold=args.F_threshold,
            tau=args.tau,
            eps=args.eps,
            aco_ants=args.aco_ants,
            aco_step=args.aco_step,
            aco_evap=args.aco_evap,
            aco_strength=args.aco_strength,
            pso_swarm=args.pso_swarm,
            pso_iters=args.pso_iters,
            ga_pop=args.ga_pop,
            ga_iters=args.ga_iters,
            ga_cx=args.ga_cx,
            ga_mut=args.ga_mut,
            ba_bees=args.ba_bees,
            ba_elite=args.ba_elite,
            ba_recruits=args.ba_recruits,
            ba_radius=args.ba_radius,
            ba_iters=args.ba_iters,
            ba_stagn=args.ba_stagn,
            patience=args.patience,
            tol=args.tol,
            log_file=args.log,
        )

    elif cmd == "preview":
        orch.preview_csv(path=args.path, tail=args.tail)

    elif cmd == "noise":
        out = orch.run_noise_demo(
            outdir=args.outdir,
            shots=args.shots,
            backend_mode=args.backend_mode,
            azure_backend=args.azure_backend,
            lam0=args.lam0,
            gamma1=args.gamma1,
            lam2=args.lam2,
            lam3=args.lam3,
        )
        if out:
            print(f"[noise] Saved → {out}")

    elif cmd == "scaling":
        out_csv = orch.run_scalability(
            backend=args.backend,
            shots=args.shots,
            ns=args.ns,
            out_csv=args.out,
        )
        if out_csv:
            print(f"[scaling] CSV → {out_csv}")

    elif cmd == "compare":
        orch.compare_against_qiskit()

    else:
        print(f"Unknown command: {cmd}")
        sys.exit(2)


if __name__ == "__main__":
    main()
