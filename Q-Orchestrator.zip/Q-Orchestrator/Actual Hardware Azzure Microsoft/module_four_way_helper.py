# module_four_way_helper.py  (Azure Quantum edition)
# ------------------------------------------------------------
# Four-way helper to compare:
#   - RANDOM (hardware)
#   - SPSA   (hardware)
#   - HYBRID (Algorithm-3: ACO->PSO->GA->BA, hardware)
#   - IDEAL  (noiseless analytic upper bound)
#
# Produces:
#   - baseline_random.csv
#   - baseline_spsa.csv
#   - hybrid_log.csv
#   - baseline_ideal.csv
#   - four_way_results.csv (merged)
#
# You can import run_four_way(...) from orchestrators or run via CLI.
# ------------------------------------------------------------

from __future__ import annotations

import os
import csv
import json
import argparse
from typing import Dict, Any, List, Optional

# --- Underlying modules (Azure-ready) ---
# Baselines: RANDOM, SPSA, IDEAL
import module_baseline_comparisons as base
# Hybrid: Algorithm-3
from module_hybrid_opt_braket import (
    EvalConfig as HybridEvalConfig,
    NoiseAwareObjective,
    Feasibility,
    FaithfulHybridOptimizer,
)

# ----------------------------
# Defaults and filenames
# ----------------------------
DEFAULT_BACKEND = os.getenv("AZURE_QUANTUM_BACKEND", "ionq.simulator")
CSV_RANDOM = "baseline_random.csv"
CSV_SPSA = "baseline_spsa.csv"
CSV_IDEAL = "baseline_ideal.csv"
CSV_HYBRID = "hybrid_log.csv"
CSV_MERGED = "four_way_results.csv"

# The unified merged CSV header
MERGED_HEADER = [
    "method", "iter", "score",
    "theta0", "theta1", "theta2", "theta3",
    "elapsed_s"
]

# ----------------------------
# Utilities
# ----------------------------
def _exists(path: str) -> bool:
    try:
        return os.path.exists(path)
    except Exception:
        return False


def _score_from_zz(zz: float) -> float:
    return 0.5 * (1.0 + float(zz))


def _append_csv(path: str, fieldnames: List[str], rows: List[Dict[str, Any]]) -> None:
    new = not _exists(path)
    with open(path, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        if new:
            w.writeheader()
        w.writerows(rows)


def _merge_baseline_csv(src_path: str, method: str) -> List[Dict[str, Any]]:
    """Normalize rows from a baseline CSV (random/spsa/ideal) to MERGED_HEADER."""
    rows_out: List[Dict[str, Any]] = []
    if not _exists(src_path):
        return rows_out
    with open(src_path, "r", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            # Baseline CSV header: method, iter, zz, score, theta0..3, elapsed_s
            rows_out.append({
                "method": method,
                "iter": int(float(row.get("iter", 0))),
                "score": float(row.get("score", 0.0)),
                "theta0": float(row.get("theta0", 0.0)),
                "theta1": float(row.get("theta1", 0.0)),
                "theta2": float(row.get("theta2", 0.0)),
                "theta3": float(row.get("theta3", 0.0)),
                "elapsed_s": float(row.get("elapsed_s", 0.0)),
            })
    return rows_out


def _merge_hybrid_csv(src_path: str) -> List[Dict[str, Any]]:
    """
    Normalize rows from hybrid CSV to MERGED_HEADER.

    HYBRID CSV header (from module_hybrid_opt_braket.py):
      iteration, method, fidelity, feasible, repaired, elapsed_s

    We'll convert 'fidelity' to 'score' and leave θ unknown (NaN),
    since hybrid CSV doesn't store θ per step (only the final JSON has it).
    """
    out: List[Dict[str, Any]] = []
    if not _exists(src_path):
        return out
    with open(src_path, "r", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            # Ignore header echo line if present
            if row.get("iteration", "").lower() == "iteration":
                continue
            try:
                it = int(float(row.get("iteration", 0)))
                score = float(row.get("fidelity", 0.0))
                elapsed = float(row.get("elapsed_s", 0.0))
            except Exception:
                continue
            out.append({
                "method": "HYBRID",
                "iter": it,
                "score": score,
                "theta0": float("nan"),
                "theta1": float("nan"),
                "theta2": float("nan"),
                "theta3": float("nan"),
                "elapsed_s": elapsed
            })
    return out


# ----------------------------
# Runner
# ----------------------------
def run_four_way(
    *,
    backend: str = DEFAULT_BACKEND,
    shots_random: int = 4000,
    shots_spsa: int = 4000,
    shots_hybrid: int = 4000,
    random_iters: int = 80,
    spsa_iters: int = 60,
    ideal_iters: int = 200,
    hybrid_iters: int = 6,
    seed: Optional[int] = None,
    out_random_csv: str = CSV_RANDOM,
    out_spsa_csv: str = CSV_SPSA,
    out_ideal_csv: str = CSV_IDEAL,
    out_hybrid_csv: str = CSV_HYBRID,
    out_merged_csv: str = CSV_MERGED,
    # Hybrid knobs (aligned with module_hybrid_opt_braket.py)
    opt_level: int = 1,
    seed_transpiler: Optional[int] = None,
    use_zne: bool = True,
    F_threshold: float = 0.95,
    tau: float = 0.90,
    eps: float = 0.02,
    aco_ants: int = 20,
    aco_step: float = 0.12,
    aco_evap: float = 0.2,
    aco_strength: float = 1.0,
    pso_swarm: int = 20,
    pso_iters: int = 6,
    ga_pop: int = 30,
    ga_iters: int = 6,
    ga_cx: float = 0.85,
    ga_mut: float = 0.12,
    ba_bees: int = 24,
    ba_elite: int = 5,
    ba_recruits: int = 3,
    ba_radius: float = 0.06,
    ba_iters: int = 6,
    ba_stagn: int = 3,
    patience: int = 4,
    tol: float = 1e-3,
) -> Dict[str, Any]:
    """
    Run RANDOM, SPSA, HYBRID, IDEAL, merge CSVs, and return a JSON-able summary.
    """

    # ---- 1) RANDOM (hardware) ----
    rand_res = base.baseline_random(
        cfg=base.EvalConfig(
            backend_name=backend, shots=shots_random, reverse_bits=False, opt_level=1
        ),
        iters=random_iters,
        seed=seed,
        csv_path=out_random_csv,
    )

    # ---- 2) SPSA (hardware) ----
    spsa_cfg = base.SPSAConfig(
        iters=spsa_iters, a=0.2, c=0.1, alpha=0.602, gamma=0.101, a_min=0.02, c_min=0.01, seed=seed
    )
    spsa_res = base.baseline_spsa(
        cfg=base.EvalConfig(
            backend_name=backend, shots=shots_spsa, reverse_bits=False, opt_level=1
        ),
        spsa=spsa_cfg,
        theta0=None,
        csv_path=out_spsa_csv,
    )

    # ---- 3) HYBRID (Algorithm-3, hardware) ----
    # Wire Azure execution config
    h_eval = HybridEvalConfig(
        backend_name=backend,
        shots=shots_hybrid,
        reverse_bits=False,
        opt_level=opt_level,
        seed_transpiler=seed_transpiler,
    )
    objective = NoiseAwareObjective(eval_cfg=h_eval, use_zne=bool(use_zne))
    feas = Feasibility(objective=objective, F_threshold=F_threshold, tau=tau, eps=eps, rng=None)
    hybrid = FaithfulHybridOptimizer(objective=objective, feasibility=feas, log_path=out_hybrid_csv, rng=None)
    hybrid.ph_evap = aco_evap
    hybrid.ph_strength = aco_strength

    hyb_res = hybrid.orchestrate(
        outer_iters=hybrid_iters,
        aco_cfg={"ants": aco_ants, "step": aco_step},
        pso_cfg={"swarm": pso_swarm, "iters": pso_iters},
        ga_cfg={"pop_size": ga_pop, "iters": ga_iters, "cx_prob": ga_cx, "mut_prob": ga_mut},
        ba_cfg={"bees": ba_bees, "elite": ba_elite, "recruits": ba_recruits,
                "radius": ba_radius, "iters": ba_iters, "stagn_limit": ba_stagn},
        stop_patience=patience, stop_tol=tol
    )

    # ---- 4) IDEAL (analytic, noiseless) ----
    ideal_res = base.baseline_ideal_local(
        iters=ideal_iters,
        seed=seed,
        csv_path=out_ideal_csv
    )

    # ---- Merge all into a single CSV ----
    merged_rows: List[Dict[str, Any]] = []
    merged_rows.extend(_merge_baseline_csv(out_random_csv, "RANDOM"))
    merged_rows.extend(_merge_baseline_csv(out_spsa_csv, "SPSA"))
    merged_rows.extend(_merge_hybrid_csv(out_hybrid_csv))
    merged_rows.extend(_merge_baseline_csv(out_ideal_csv, "IDEAL"))

    # Sort by method then iter for neatness
    merged_rows.sort(key=lambda r: (r["method"], r["iter"]))
    # Write merged
    with open(out_merged_csv, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=MERGED_HEADER)
        w.writeheader()
        w.writerows(merged_rows)

    # ---- Compact JSON summary ----
    summary = {
        "backend": backend,
        "random": {k: rand_res[k] for k in ("best_theta", "best_score", "elapsed_s", "csv")},
        "spsa":   {k: spsa_res[k] for k in ("best_theta", "best_score", "elapsed_s", "csv")},
        "hybrid": {
            "theta": hyb_res.get("theta"),
            "score": hyb_res.get("score"),
            "elapsed_s": hyb_res.get("elapsed_s"),
            "log_file": hyb_res.get("log_file"),
        },
        "ideal":  {k: ideal_res[k] for k in ("best_theta", "best_score", "elapsed_s", "csv")},
        "merged_csv": out_merged_csv,
    }

    print(json.dumps(summary, indent=2))
    return summary


# ----------------------------
# CLI
# ----------------------------
def parse_args():
    p = argparse.ArgumentParser(description="Four-way helper (RANDOM, SPSA, HYBRID, IDEAL) on Azure Quantum")
    p.add_argument("--backend", type=str, default=DEFAULT_BACKEND,
                   help="Azure backend, e.g., ionq.simulator, ionq.qpu, quantinuum.h1-1e")
    # Shots per method
    p.add_argument("--shots-random", type=int, default=4000)
    p.add_argument("--shots-spsa", type=int, default=4000)
    p.add_argument("--shots-hybrid", type=int, default=4000)
    # Iterations per method
    p.add_argument("--random-iters", type=int, default=80)
    p.add_argument("--spsa-iters", type=int, default=60)
    p.add_argument("--ideal-iters", type=int, default=200)
    p.add_argument("--hybrid-iters", type=int, default=6)
    # Seeds and outputs
    p.add_argument("--seed", type=int, default=None)
    p.add_argument("--random-csv", type=str, default=CSV_RANDOM)
    p.add_argument("--spsa-csv", type=str, default=CSV_SPSA)
    p.add_argument("--ideal-csv", type=str, default=CSV_IDEAL)
    p.add_argument("--hybrid-csv", type=str, default=CSV_HYBRID)
    p.add_argument("--merged-csv", type=str, default=CSV_MERGED)
    # Hybrid knobs
    p.add_argument("--opt-level", type=int, default=1)
    p.add_argument("--seed-transpiler", type=int, default=None)
    p.add_argument("--no-zne", action="store_true", help="Disable ZNE in hybrid objective")
    p.add_argument("--F-threshold", type=float, default=0.95)
    p.add_argument("--tau", type=float, default=0.90)
    p.add_argument("--eps", type=float, default=0.02)
    p.add_argument("--aco-ants", type=int, default=20)
    p.add_argument("--aco-step", type=float, default=0.12)
    p.add_argument("--aco-evap", type=float, default=0.2)
    p.add_argument("--aco-strength", type=float, default=1.0)
    p.add_argument("--pso-swarm", type=int, default=20)
    p.add_argument("--pso-iters", type=int, default=6)
    p.add_argument("--ga-pop", type=int, default=30)
    p.add_argument("--ga-iters", type=int, default=6)
    p.add_argument("--ga-cx", type=float, default=0.85)
    p.add_argument("--ga-mut", type=float, default=0.12)
    p.add_argument("--ba-bees", type=int, default=24)
    p.add_argument("--ba-elite", type=int, default=5)
    p.add_argument("--ba-recruits", type=int, default=3)
    p.add_argument("--ba-radius", type=float, default=0.06)
    p.add_argument("--ba-iters", type=int, default=6)
    p.add_argument("--ba-stagn", type=int, default=3)
    p.add_argument("--patience", type=int, default=4)
    p.add_argument("--tol", type=float, default=1e-3)
    return p.parse_args()


def main():
    args = parse_args()
    run_four_way(
        backend=args.backend,
        shots_random=args.shots_random,
        shots_spsa=args.shots_spsa,
        shots_hybrid=args.shots_hybrid,
        random_iters=args.random_iters,
        spsa_iters=args.spsa_iters,
        ideal_iters=args.ideal_iters,
        hybrid_iters=args.hybrid_iters,
        seed=args.seed,
        out_random_csv=args.random_csv,
        out_spsa_csv=args.spsa_csv,
        out_ideal_csv=args.ideal_csv,
        out_hybrid_csv=args.hybrid_csv,
        out_merged_csv=args.merged_csv,
        opt_level=args.opt_level,
        seed_transpiler=args.seed_transpiler,
        use_zne=(not args.no_zne),
        F_threshold=args.F_threshold,
        tau=args.tau,
        eps=args.eps,
        aco_ants=args.aco_ants,
        aco_step=args.aco_step,
        aco_evap=args.aco_evap,
        aco_strength=args.aco_strength,
        pso_swarm=args.pso_swarm,
        pso_iters=args.pso_iters,
        ga_pop=args.ga_pop,
        ga_iters=args.ga_iters,
        ga_cx=args.ga_cx,
        ga_mut=args.ga_mut,
        ba_bees=args.ba_bees,
        ba_elite=args.ba_elite,
        ba_recruits=args.ba_recruits,
        ba_radius=args.ba_radius,
        ba_iters=args.ba_iters,
        ba_stagn=args.ba_stagn,
        patience=args.patience,
        tol=args.tol,
    )


if __name__ == "__main__":
    main()
