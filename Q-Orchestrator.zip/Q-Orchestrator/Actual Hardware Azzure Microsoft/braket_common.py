# braket_common.py  (Azure Quantum edition)
# ------------------------------------------------------------
# Drop-in style helper utilities for moving Braket-oriented code
# to Microsoft Azure Quantum via Qiskit backends.
#
# What you get:
#   - AzureQuantumConfig: manages workspace connection
#   - get_backend(name): fetch an Azure Quantum backend
#   - list_backends(): quick listing helper
#   - qc_create(n), qc_measure_all(qc): circuit helpers
#   - run(qc, backend_name, shots=1000, **opts): submit & fetch counts
#   - Expectation helpers: ez(), ezz() from counts
#   - Bitstring order controls for compatibility with Braket-style postproc
#
# Notes:
#   • Replace your Braket device factory with get_backend("<provider.target>")
#     e.g., "ionq.qpu", "quantinuum.h1-1e", "rigetti.qpu.ankaa-3", "pasqal.qpu"
#   • If your old code assumed Braket’s bit ordering, set reverse_bits=True
#     in run(...) (or convert in your downstream code).
#   • Noise channels: real QPUs ignore noise models; for simulations use
#     Qiskit Aer locally. This module focuses on hardware execution.
# ------------------------------------------------------------

from __future__ import annotations
import os
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Tuple

from qiskit import QuantumCircuit, ClassicalRegister, QuantumRegister, transpile
from qiskit.providers.backend import Backend
from azure.quantum.qiskit import AzureQuantumProvider


# -------------------------
# Workspace / provider setup
# -------------------------
@dataclass
class AzureQuantumConfig:
    """
    Connection config for Azure Quantum.

    You can pass values explicitly, or set environment variables:
      AZURE_QUANTUM_RESOURCE_ID = /subscriptions/<sub>/resourceGroups/<rg>/providers/Microsoft.Quantum/Workspaces/<ws>
      AZURE_QUANTUM_LOCATION   = e.g., "westus", "westus2", "westeurope", etc.
    """
    resource_id: Optional[str] = None
    location: Optional[str] = None

    def __post_init__(self):
        if not self.resource_id:
            self.resource_id = os.getenv("AZURE_QUANTUM_RESOURCE_ID", "").strip() or None
        if not self.location:
            self.location = os.getenv("AZURE_QUANTUM_LOCATION", "").strip() or None
        if not self.resource_id or not self.location:
            raise ValueError(
                "AzureQuantumConfig requires resource_id and location. "
                "Set AZURE_QUANTUM_RESOURCE_ID and AZURE_QUANTUM_LOCATION or pass explicitly."
            )

    def provider(self) -> AzureQuantumProvider:
        return AzureQuantumProvider(resource_id=self.resource_id, location=self.location)


# -------------------------
# Backend helpers
# -------------------------
def get_backend(name: str,
                config: Optional[AzureQuantumConfig] = None) -> Backend:
    """
    Get an Azure Quantum backend by "<provider>.<target>" name.

    Examples:
      "ionq.qpu", "ionq.simulator",
      "quantinuum.h1-1e", "quantinuum.h2-1e",
      "rigetti.qpu.ankaa-3", "rigetti.sim.qvm",
      "pasqal.qpu", "pasqal.sim"
    """
    cfg = config or AzureQuantumConfig()  # raises clearly if env vars missing
    prov = cfg.provider()
    return prov.get_backend(name)


def list_backends(config: Optional[AzureQuantumConfig] = None) -> List[str]:
    """Return available backend names (strings) visible to your workspace."""
    cfg = config or AzureQuantumConfig()
    prov = cfg.provider()
    return [b.name() for b in prov.backends()]


# -------------------------
# Circuit helpers
# -------------------------
def qc_create(n_qubits: int,
              with_classical: bool = True,
              name: str = "qc") -> QuantumCircuit:
    """
    Create a QuantumCircuit with n_qubits and (optionally) same-size classical bits.
    """
    qr = QuantumRegister(n_qubits, "q")
    if with_classical:
        cr = ClassicalRegister(n_qubits, "c")
        qc = QuantumCircuit(qr, cr, name=name)
    else:
        qc = QuantumCircuit(qr, name=name)
    return qc


def qc_measure_all(qc: QuantumCircuit) -> None:
    """
    Ensure all qubits are measured into same-index classical bits.
    Creates classical bits if needed.
    """
    n = qc.num_qubits
    if qc.num_clbits < n:
        # Extend with missing classical bits
        add = ClassicalRegister(n - qc.num_clbits, "c_extra")
        qc.add_register(add)
    # Map qubit i -> classical bit i (best for stable indexing)
    q_indices = list(range(n))
    c_indices = list(range(n))
    qc.measure(q_indices, c_indices)


# -------------------------
# Running jobs
# -------------------------
class RunResult:
    """Lightweight holder to mimic the Braket ‘task’ + result ergonomics."""
    def __init__(self, job, counts: Dict[str, int], shots: int, backend_name: str):
        self.job = job
        self.counts = counts
        self.shots = shots
        self.backend_name = backend_name

    def status(self) -> str:
        try:
            return str(self.job.status())
        except Exception:
            return "UNKNOWN"

    def get_counts(self) -> Dict[str, int]:
        return dict(self.counts)


def _normalize_counts_bitorder(counts: Dict[str, int],
                               reverse_bits: bool) -> Dict[str, int]:
    if not reverse_bits:
        return counts
    out = {}
    for bitstring, v in counts.items():
        out[bitstring[::-1]] = v  # reverse the bit-string
    return out


def run(qc: QuantumCircuit,
        backend_name: str,
        shots: int = 1000,
        *,
        config: Optional[AzureQuantumConfig] = None,
        transpile_optimization_level: int = 1,
        seed_transpiler: Optional[int] = None,
        reverse_bits: bool = False,
        **backend_run_kwargs) -> RunResult:
    """
    Submit a circuit to Azure Quantum and return counts.

    Parameters
    ----------
    qc : QuantumCircuit
        Your circuit. If it has no measurements, they will be added (measure-all).
    backend_name : str
        "<provider>.<target>" (e.g., "ionq.qpu", "quantinuum.h1-1e").
    shots : int
        Number of repetitions.
    reverse_bits : bool
        If True, reverse bitstrings in counts to match Braket-like expectations.
        (Braket and Qiskit often differ in bit/endianness conventions.)
    backend_run_kwargs : dict
        Extra kwargs forwarded to backend.run (provider-dependent).

    Returns
    -------
    RunResult
    """
    if qc.num_clbits == 0:
        qc_measure_all(qc)

    backend = get_backend(backend_name, config=config)

    # Transpile to target basis; providers will map as needed
    tqc = transpile(
        qc,
        backend=backend,
        optimization_level=transpile_optimization_level,
        seed_transpiler=seed_transpiler,
    )

    job = backend.run(tqc, shots=shots, **backend_run_kwargs)
    result = job.result()  # blocks until completion on Azure Quantum
    counts = result.get_counts()

    counts = _normalize_counts_bitorder(counts, reverse_bits=reverse_bits)
    return RunResult(job=job, counts=counts, shots=shots, backend_name=backend_name)


# -------------------------
# Expectation utilities
# -------------------------
def counts_to_probs(counts: Dict[str, int]) -> Dict[str, float]:
    total = sum(counts.values()) or 1
    return {k: v / total for k, v in counts.items()}


def ez(counts: Dict[str, int],
       qubit: int,
       *,
       reverse_bits_interpretation: bool = False) -> float:
    """
    Compute ⟨Z_qubit⟩ from counts.
    For a bit b in {0,1}, Z eigenvalue is (+1 for 0, -1 for 1).
      ⟨Z⟩ = Σ_s p(s) * (-1)^(s[qubit])

    reverse_bits_interpretation toggles which end of the bitstring is qubit 0.
    """
    probs = counts_to_probs(counts)
    exp = 0.0
    for bitstring, p in probs.items():
        idx = (len(bitstring) - 1 - qubit) if reverse_bits_interpretation else qubit
        b = int(bitstring[idx])
        z = 1.0 if b == 0 else -1.0
        exp += z * p
    return exp


def ezz(counts: Dict[str, int],
        q0: int, q1: int,
        *,
        reverse_bits_interpretation: bool = False) -> float:
    """
    Compute ⟨Z_q0 ⊗ Z_q1⟩ from counts.
      ⟨ZZ⟩ = Σ_s p(s) * z(q0) * z(q1),  where z(i)=+1 if bit i=0, else -1.
    """
    probs = counts_to_probs(counts)
    exp = 0.0
    for bitstring, p in probs.items():
        i0 = (len(bitstring) - 1 - q0) if reverse_bits_interpretation else q0
        i1 = (len(bitstring) - 1 - q1) if reverse_bits_interpretation else q1
        z0 = 1.0 if int(bitstring[i0]) == 0 else -1.0
        z1 = 1.0 if int(bitstring[i1]) == 0 else -1.0
        exp += (z0 * z1) * p
    return exp


# -------------------------
# Convenience: tiny gate DSL (optional)
# -------------------------
class Q:
    """
    Minimal gate helpers to make mechanical ports from Braket-style builder code
    a bit cleaner. Usage:
        qc = qc_create(2)
        Q.h(qc, 0); Q.cx(qc, 0, 1); qc_measure_all(qc)
    """
    @staticmethod
    def h(qc: QuantumCircuit, q: int) -> None:
        qc.h(q)

    @staticmethod
    def x(qc: QuantumCircuit, q: int) -> None:
        qc.x(q)

    @staticmethod
    def y(qc: QuantumCircuit, q: int) -> None:
        qc.y(q)

    @staticmethod
    def z(qc: QuantumCircuit, q: int) -> None:
        qc.z(q)

    @staticmethod
    def rx(qc: QuantumCircuit, theta: float, q: int) -> None:
        qc.rx(theta, q)

    @staticmethod
    def ry(qc: QuantumCircuit, theta: float, q: int) -> None:
        qc.ry(theta, q)

    @staticmethod
    def rz(qc: QuantumCircuit, theta: float, q: int) -> None:
        qc.rz(theta, q)

    @staticmethod
    def s(qc: QuantumCircuit, q: int) -> None:
        qc.s(q)

    @staticmethod
    def t(qc: QuantumCircuit, q: int) -> None:
        qc.t(q)

    @staticmethod
    def sx(qc: QuantumCircuit, q: int) -> None:
        qc.sx(q)

    @staticmethod
    def cx(qc: QuantumCircuit, c: int, t: int) -> None:
        qc.cx(c, t)

    @staticmethod
    def cz(qc: QuantumCircuit, c: int, t: int) -> None:
        qc.cz(c, t)

    @staticmethod
    def measure_all(qc: QuantumCircuit) -> None:
        qc.measure_all()


# -------------------------
# Example (remove in prod)
# -------------------------
if __name__ == "__main__":
    # Quick smoketest (will run if your workspace + backend are set)
    # Set env:
    #   AZURE_QUANTUM_RESOURCE_ID=/subscriptions/..../resourceGroups/..../providers/Microsoft.Quantum/Workspaces/...
    #   AZURE_QUANTUM_LOCATION=westus
    #
    # Then choose a backend you have access to (e.g., "ionq.simulator" or a QPU):
    backend_name = os.getenv("AZURE_QUANTUM_BACKEND", "ionq.simulator")

    qc = qc_create(2)
    Q.h(qc, 0)
    Q.cx(qc, 0, 1)
    qc_measure_all(qc)

    rr = run(qc, backend_name, shots=2000, reverse_bits=False)
    print("Backend:", rr.backend_name, "Status:", rr.status())
    print("Counts:", rr.get_counts())
    print("<Z0>:", ez(rr.counts, 0))
    print("<Z1>:", ez(rr.counts, 1))
    print("<Z0Z1>:", ezz(rr.counts, 0, 1))
