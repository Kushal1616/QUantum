# module_noise_simulation_braket.py  (Azure/Qiskit edition)
# ------------------------------------------------------------
# Module 1 — Ideal vs Noisy probabilities (saves a PNG).
# - Replaces Braket dm1 noise ops with Qiskit Aer noise models:
#     * Depolarizing on qubit 0       → λ0
#     * Amplitude damping on qubit 1  → γ1
#     * Readout error on q0, q1       → λ2, λ3  (bit-flip prob at measure)
#
# - By default, both "ideal" and "noisy" runs use Qiskit Aer simulators.
#   If you *optionally* want the "ideal" probabilities from an Azure backend,
#   set AZURE_QUANTUM_RESOURCE_ID, AZURE_QUANTUM_LOCATION, and AZURE_QUANTUM_BACKEND,
#   then pass backend_mode="azure" to run().
#
# Saves: <outdir>/module1_noise_vs_ideal.png
# ------------------------------------------------------------

import os
import argparse
import numpy as np
import matplotlib.pyplot as plt

from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, transpile
from qiskit_aer import AerSimulator
from qiskit_aer.noise import (
    NoiseModel,
    depolarizing_error,
    amplitude_damping_error,
    ReadoutError,
)
from qiskit.result import Counts

# Optional Azure Quantum provider (used only if backend_mode="azure")
try:
    from azure.quantum.qiskit import AzureQuantumProvider
    _HAS_AZURE = True
except Exception:
    _HAS_AZURE = False


# ----------------------------
# Helpers
# ----------------------------
def counts_to_probs(counts: Counts, num_qubits: int) -> np.ndarray:
    """Return probabilities [p00, p01, p10, p11] for a 2-qubit experiment."""
    # Generalize to 2 qubits; extend easily if you need more later
    outcome_labels = [format(i, f"0{num_qubits}b") for i in range(2 ** num_qubits)]
    total = sum(counts.values()) or 1
    return np.array([counts.get(lbl, 0) / total for lbl in outcome_labels], dtype=float)


def bell_circuit_2q() -> QuantumCircuit:
    """Standard 2-qubit Bell-state circuit with measurements on both qubits."""
    qr = QuantumRegister(2, "q")
    cr = ClassicalRegister(2, "c")
    qc = QuantumCircuit(qr, cr, name="bell")
    qc.h(qr[0])
    qc.cx(qr[0], qr[1])
    qc.measure(qr, cr)
    return qc


def build_noise_model(lam0: float, gamma1: float, lam2: float, lam3: float) -> NoiseModel:
    """
    Construct a Qiskit Aer noise model:
      - Single-qubit depolarizing on q0 for 1Q gates with prob λ0
      - Single-qubit amplitude damping on q1 for 1Q gates with prob γ1 (via Kraus)
      - Readout error (bit flip) on q0 with prob λ2, on q1 with prob λ3
    """
    nm = NoiseModel()

    # One-qubit errors
    err_dep_q0 = depolarizing_error(lam0, 1) if lam0 > 0 else None
    err_amp_q1 = amplitude_damping_error(gamma1) if gamma1 > 0 else None

    # Attach to common 1Q basis gates you use (h, x, y, z, rx, ry, rz, sx, id)
    oneq_basis = ["h", "x", "y", "z", "rx", "ry", "rz", "sx", "id"]

    if err_dep_q0 is not None:
        for g in oneq_basis:
            nm.add_quantum_error(err_dep_q0, g, [0])  # target qubit 0

    if err_amp_q1 is not None:
        for g in oneq_basis:
            nm.add_quantum_error(err_amp_q1, g, [1])  # target qubit 1

    # Readout errors: simple symmetric flip models
    if lam2 > 0:
        ro_q0 = ReadoutError([[1 - lam2, lam2], [lam2, 1 - lam2]])
        nm.add_readout_error(ro_q0, [0])

    if lam3 > 0:
        ro_q1 = ReadoutError([[1 - lam3, lam3], [lam3, 1 - lam3]])
        nm.add_readout_error(ro_q1, [1])

    return nm


def run_ideal_aer(qc: QuantumCircuit, shots: int = 20000) -> Counts:
    sim = AerSimulator()
    tqc = transpile(qc, sim, optimization_level=1)
    result = sim.run(tqc, shots=shots).result()
    return result.get_counts()


def run_noisy_aer(qc: QuantumCircuit, noise_model: NoiseModel, shots: int = 20000) -> Counts:
    sim = AerSimulator(noise_model=noise_model)
    tqc = transpile(qc, sim, optimization_level=1)
    result = sim.run(tqc, shots=shots).result()
    return result.get_counts()


def run_ideal_azure(qc: QuantumCircuit, backend_name: str, shots: int = 20000) -> Counts:
    if not _HAS_AZURE:
        raise RuntimeError("azure-quantum not available. Install azure-quantum[qiskit].")
    rid = os.getenv("AZURE_QUANTUM_RESOURCE_ID")
    loc = os.getenv("AZURE_QUANTUM_LOCATION")
    if not rid or not loc:
        raise RuntimeError("Set AZURE_QUANTUM_RESOURCE_ID and AZURE_QUANTUM_LOCATION to use Azure backends.")
    provider = AzureQuantumProvider(resource_id=rid, location=loc)
    backend = provider.get_backend(backend_name)
    tqc = transpile(qc, backend, optimization_level=1)
    job = backend.run(tqc, shots=shots)
    res = job.result()
    return res.get_counts()


def plot_side_by_side(ideal_probs: np.ndarray,
                      noisy_probs: np.ndarray,
                      lam0: float, gamma1: float, lam2: float, lam3: float,
                      outpath: str):
    labels = ["00", "01", "10", "11"]
    fig, ax = plt.subplots(1, 2, figsize=(12, 5))

    ax[0].bar(labels, ideal_probs)
    ax[0].set_title("Ideal")
    ax[0].set_ylim(0, 1)
    ax[0].set_xlabel("Measured state")
    ax[0].set_ylabel("Probability")

    ax[1].bar(labels, noisy_probs)
    ax[1].set_title(f"Noisy (λ0={lam0:.2f}, γ1={gamma1:.2f}, λ2={lam2:.2f}, λ3={lam3:.2f})")
    ax[1].set_ylim(0, 1)
    ax[1].set_xlabel("Measured state")

    fig.suptitle("Module 1 (Azure/Qiskit): Impact of Noise on Circuit")
    plt.tight_layout()
    os.makedirs(os.path.dirname(outpath) or ".", exist_ok=True)
    plt.savefig
