# module_scalability_benchmark.py  (Azure Quantum edition)
# ------------------------------------------------------------
# Benchmarks how circuit structure and runtime behavior scale with qubit count.
# Produces a CSV with columns:
#   n_qubits, label, depth, g1q, g2q, total, value, shots, wall_sec
#
# Dependencies (local module):
#   braket_common.py (Azure edition) providing: qc_create, qc_measure_all, run, Q, ezz
# ------------------------------------------------------------

from __future__ import annotations

import os
import time
import argparse
from typing import List, Dict, Tuple

from qiskit import transpile
from qiskit.circuit import QuantumCircuit

from braket_common import (
    qc_create, qc_measure_all, run, Q, ezz
)

# ----------------------------
# Helpers for circuit metrics
# ----------------------------

def circuit_summary(qc: QuantumCircuit) -> Dict[str, int]:
    """
    Compute simple structural metrics:
      - depth (after a light transpile with no specific backend)
      - number of 1-qubit and 2-qubit gates (measures excluded)
      - total gate count
    """
    # A quick, backend-agnostic transpile to normalize depth calculation a bit
    tqc = transpile(qc, optimization_level=0)
    depth = int(tqc.depth() or 0)

    g1, g2, total = 0, 0, 0
    for inst, qargs, _ in tqc.data:
        name = inst.name
        if name == "measure":
            continue
        arity = len(qargs)
        if arity == 1:
            g1 += 1
            total += 1
        elif arity == 2:
            g2 += 1
            total += 1
        else:
            # If ever present (e.g., 3q gates), count toward total only
            total += 1

    return {"depth": depth, "gates_1q": g1, "gates_2q": g2, "gates_total": total}


# ----------------------------
# Circuit builders
# ----------------------------

def _baseline_fanout(n_qubits: int) -> QuantumCircuit:
    """
    Baseline: H on q0, then fan-out CX(q0 -> qi) for i=1..n-1.
    This keeps depth small but grows 2q count linearly with n.
    """
    if n_qubits < 2:
        raise ValueError("n_qubits must be >= 2")
    qc = qc_create(n_qubits, with_classical=True, name=f"baseline_fanout_{n_qubits}")
    Q.h(qc, 0)
    for i in range(1, n_qubits):
        Q.cx(qc, 0, i)
    qc_measure_all(qc)
    return qc


def _optimized_minimal(n_qubits: int) -> QuantumCircuit:
    """
    Optimized/minimal: Only entangle q0–q1 so we can still measure ⟨Z0Z1⟩,
    leaving other qubits idle. 2q gate count is constant.
    """
    if n_qubits < 2:
        raise ValueError("n_qubits must be >= 2")
    qc = qc_create(n_qubits, with_classical=True, name=f"optimized_minimal_{n_qubits}")
    Q.h(qc, 0)
    Q.cx(qc, 0, 1)
    qc_measure_all(qc)
    return qc


# ----------------------------
# Runner
# ----------------------------

def _run_once(label: str, qc: QuantumCircuit, backend_name: str, shots: int) -> Tuple[float, float]:
    """
    Execute a circuit on Azure backend and return (⟨Z0Z1⟩, wall_seconds).
    """
    t0 = time.time()
    rr = run(
        qc,
        backend_name=backend_name,
        shots=shots,
        reverse_bits=False,             # flip here if your downstream assumes reversed bitstrings
        transpile_optimization_level=1
    )
    val = float(ezz(rr.counts, 0, 1))   # ⟨Z0 Z1⟩ from counts
    wall = time.time() - t0
    return val, wall


def run_scaling(n_list: List[int],
                backend_name: str,
                shots: int = 2000,
                out_csv: str = "scaling_results.csv") -> str:
    """
    For each n in n_list, build baseline & optimized circuits,
    compute structural metrics, run on backend, and write CSV.
    """
    rows = []
    for n in n_list:
        base = _baseline_fanout(n)
        opt  = _optimized_minimal(n)

        sb = circuit_summary(base)
        so = circuit_summary(opt)

        print(f"[n={n:>3}]  Baseline: depth={sb['depth']}, 1q={sb['gates_1q']}, 2q={sb['gates_2q']}, total={sb['gates_total']}")
        print(f"         Optimized: depth={so['depth']}, 1q={so['gates_1q']}, 2q={so['gates_2q']}, total={so['gates_total']}")

        b_val, b_wall = _run_once("Baseline", base, backend_name, shots)
        o_val, o_wall = _run_once("Optimized", opt, backend_name, shots)

        rows.append({
            "n_qubits": n, "label": "Baseline",
            "depth": sb["depth"], "g1q": sb["gates_1q"], "g2q": sb["gates_2q"], "total": sb["gates_total"],
            "value": b_val, "shots": shots, "wall_sec": round(b_wall, 3)
        })
        rows.append({
            "n_qubits": n, "label": "Optimized",
            "depth": so["depth"], "g1q": so["gates_1q"], "g2q": so["gates_2q"], "total": so["gates_total"],
            "value": o_val, "shots": shots, "wall_sec": round(o_wall, 3)
        })

    # Write CSV
    import csv
    with open(out_csv, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["n_qubits","label","depth","g1q","g2q","total","value","shots","wall_sec"])
        w.writeheader()
        w.writerows(rows)

    print(f"[Scaling] CSV saved → {os.path.abspath(out_csv)}")
    return out_csv


# ----------------------------
# CLI
# ----------------------------

def parse_args():
    p = argparse.ArgumentParser(description="Scalability benchmark (Azure Quantum Edition)")
    p.add_argument("--backend", type=str, default=os.getenv("AZURE_QUANTUM_BACKEND", "ionq.simulator"),
                   help="Azure backend, e.g., ionq.simulator, ionq.qpu, quantinuum.h1-1e")
    p.add_argument("--shots", type=int, default=2000, help="Shots per circuit")
    p.add_argument("--out", type=str, default="scaling_results.csv", help="Output CSV path")
    p.add_argument("--ns", type=int, nargs="+", default=[2, 3, 4, 5, 6, 8, 10],
                   help="List of qubit sizes to benchmark")
    return p.parse_args()


def main():
    args = parse_args()
    run_scaling(n_list=args.ns, backend_name=args.backend, shots=args.shots, out_csv=args.out)


if __name__ == "__main__":
    main()
