# run_trials.py  (Azure Quantum edition)
# ------------------------------------------------------------
# Multi-trial launcher to run HYBRID (Algorithm-3), baselines (RANDOM, SPSA, IDEAL),
# and optionally SCALING and NOISE demo per trial.
#
# Produces a single summary CSV with columns:
#   trial, method, backend, shots, iters, best_score, elapsed_s, artifact
#
# Notes:
# - HYBRID/BASELINES call into your Azure-ready modules.
# - SCALING/NOISE are optional "side" artifacts per trial (no score aggregation).
# - Use --dry-run to print the plan without executing jobs.
# ------------------------------------------------------------

from __future__ import annotations

import os
import csv
import json
import time
import argparse
from typing import Dict, Any, List, Optional

# Baselines (RANDOM, SPSA, IDEAL)
import module_baseline_comparisons as base

# Hybrid Algorithm-3
from module_hybrid_opt_braket import (
    EvalConfig as HybridEvalConfig,
    NoiseAwareObjective,
    Feasibility,
    FaithfulHybridOptimizer,
)

# Optional helpers (imported lazily in functions)
#   module_scalability_benchmark
#   module_noise_simulation_braket


# ----------------------------
# CSV utilities
# ----------------------------

SUMMARY_HEADER = [
    "trial", "method", "backend", "shots", "iters",
    "best_score", "elapsed_s", "artifact"
]

def append_summary_row(path: str, row: Dict[str, Any]) -> None:
    new = not os.path.exists(path)
    with open(path, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=SUMMARY_HEADER)
        if new:
            w.writeheader()
        w.writerow(row)


# ----------------------------
# Runners
# ----------------------------

def run_hybrid_once(
    *,
    backend: str,
    shots: int,
    iters: int,
    opt_level: int,
    seed_transpiler: Optional[int],
    use_zne: bool,
    F_threshold: float,
    tau: float,
    eps: float,
    aco_ants: int,
    aco_step: float,
    aco_evap: float,
    aco_strength: float,
    pso_swarm: int,
    pso_iters: int,
    ga_pop: int,
    ga_iters: int,
    ga_cx: float,
    ga_mut: float,
    ba_bees: int,
    ba_elite: int,
    ba_recruits: int,
    ba_radius: float,
    ba_iters: int,
    ba_stagn: int,
    patience: int,
    tol: float,
    log_file: str,
) -> Dict[str, Any]:
    """Run a single HYBRID optimization and return a compact result dict."""
    t0 = time.time()
    eval_cfg = HybridEvalConfig(
        backend_name=backend,
        shots=shots,
        reverse_bits=False,
        opt_level=opt_level,
        seed_transpiler=seed_transpiler,
    )
    obj = NoiseAwareObjective(eval_cfg=eval_cfg, use_zne=bool(use_zne))
    feas = Feasibility(objective=obj, F_threshold=F_threshold, tau=tau, eps=eps, rng=None)
    opt = FaithfulHybridOptimizer(objective=obj, feasibility=feas, log_path=log_file, rng=None)
    opt.ph_evap = aco_evap
    opt.ph_strength = aco_strength

    res = opt.orchestrate(
        outer_iters=iters,
        aco_cfg={"ants": aco_ants, "step": aco_step},
        pso_cfg={"swarm": pso_swarm, "iters": pso_iters},
        ga_cfg={"pop_size": ga_pop, "iters": ga_iters, "cx_prob": ga_cx, "mut_prob": ga_mut},
        ba_cfg={"bees": ba_bees, "elite": ba_elite, "recruits": ba_recruits,
                "radius": ba_radius, "iters": ba_iters, "stagn_limit": ba_stagn},
        stop_patience=patience, stop_tol=tol
    )
    res["elapsed_wall_s"] = round(time.time() - t0, 3)
    return res


def run_baselines_once(
    *,
    backend: str,
    shots_random: int,
    shots_spsa: int,
    random_iters: int,
    spsa_iters: int,
    ideal_iters: int,
    seed: Optional[int],
    random_csv: str,
    spsa_csv: str,
    ideal_csv: str,
) -> Dict[str, Any]:
    """Run RANDOM, SPSA, IDEAL once; return compact dict of best scores + CSV artifact paths."""
    results: Dict[str, Any] = {}

    # Random
    rand = base.baseline_random(
        cfg=base.EvalConfig(backend_name=backend, shots=shots_random, reverse_bits=False, opt_level=1),
        iters=random_iters,
        seed=seed,
        csv_path=random_csv,
    )
    results["random"] = {"score": rand["best_score"], "elapsed_s": rand["elapsed_s"], "csv": rand["csv"]}

    # SPSA
    spsa_cfg = base.SPSAConfig(
        iters=spsa_iters, a=0.2, c=0.1, alpha=0.602, gamma=0.101, a_min=0.02, c_min=0.01, seed=seed
    )
    spsa = base.baseline_spsa(
        cfg=base.EvalConfig(backend_name=backend, shots=shots_spsa, reverse_bits=False, opt_level=1),
        spsa=spsa_cfg,
        theta0=None,
        csv_path=spsa_csv,
    )
    results["spsa"] = {"score": spsa["best_score"], "elapsed_s": spsa["elapsed_s"], "csv": spsa["csv"]}

    # IDEAL
    ideal = base.baseline_ideal_local(
        iters=ideal_iters,
        seed=seed,
        csv_path=ideal_csv,
    )
    results["ideal"] = {"score": ideal["best_score"], "elapsed_s": ideal["elapsed_s"], "csv": ideal["csv"]}

    return results


def maybe_run_scaling(
    *,
    do_scaling: bool,
    backend: str,
    shots: int,
    ns: List[int],
    out_csv: str,
) -> Optional[str]:
    """Optionally run scalability benchmark for this trial."""
    if not do_scaling:
        return None
    try:
        import module_scalability_benchmark as m
    except Exception as e:
        print(f"[scaling] Skipped (module not available): {e}")
        return None
    return m.run_scaling(n_list=ns, backend_name=backend, shots=shots, out_csv=out_csv)


def maybe_run_noise_demo(
    *,
    do_noise: bool,
    backend_mode: str,
    azure_backend: Optional[str],
    outdir: str,
    shots: int,
    lam0: float,
    gamma1: float,
    lam2: float,
    lam3: float,
) -> Optional[str]:
    """Optionally run noise demo for this trial."""
    if not do_noise:
        return None
    try:
        import module_noise_simulation_braket as m
    except Exception as e:
        print(f"[noise] Skipped (module not available): {e}")
        return None

    sim = m.NoiseSimulatorAzure(outdir=outdir)
    sim.lam0 = lam0
    sim.gamma1 = gamma1
    sim.lam2 = lam2
    sim.lam3 = lam3
    return sim.run(shots=shots, backend_mode=backend_mode, azure_backend=azure_backend)


# ----------------------------
# Trial runner
# ----------------------------

def run_trials(
    *,
    trials: int,
    methods: List[str],
    backend: str,
    summary_csv: str,
    # HYBRID knobs
    hybrid_iters: int,
    hybrid_shots: int,
    opt_level: int,
    seed_transpiler: Optional[int],
    use_zne: bool,
    F_threshold: float,
    tau: float,
    eps: float,
    aco_ants: int,
    aco_step: float,
    aco_evap: float,
    aco_strength: float,
    pso_swarm: int,
    pso_iters: int,
    ga_pop: int,
    ga_iters: int,
    ga_cx: float,
    ga_mut: float,
    ba_bees: int,
    ba_elite: int,
    ba_recruits: int,
    ba_radius: float,
    ba_iters: int,
    ba_stagn: int,
    patience: int,
    tol: float,
    # BASELINES knobs
    random_iters: int,
    spsa_iters: int,
    ideal_iters: int,
    random_shots: int,
    spsa_shots: int,
    # Optional extras
    do_scaling: bool,
    scaling_ns: List[int],
    scaling_shots: int,
    do_noise: bool,
    noise_backend_mode: str,
    noise_backend: Optional[str],
    noise_outdir: str,
    noise_shots: int,
    lam0: float,
    gamma1: float,
    lam2: float,
    lam3: float,
    dry_run: bool,
) -> None:
    """
    Execute multiple trials and append rows to the summary CSV.
    """
    print("[run_trials] Plan:")
    print(json.dumps({
        "trials": trials,
        "methods": methods,
        "backend": backend,
        "summary_csv": summary_csv,
        "extras": {"scaling": do_scaling, "noise": do_noise}
    }, indent=2))

    if dry_run:
        print("[run_trials] Dry-run mode: exiting without execution.")
        return

    for t in range(1, trials + 1):
        print(f"\n=== Trial {t}/{trials} ===")
        seed = int(time.time() * 1e6) % (2**31 - 1) + t  # simple varying seed

        # Per-trial artifacts (to avoid clashes)
        random_csv = f"baseline_random_trial{t}.csv"
        spsa_csv   = f"baseline_spsa_trial{t}.csv"
        ideal_csv  = f"baseline_ideal_trial{t}.csv"
        hybrid_csv = f"hybrid_log_trial{t}.csv"
        scaling_csv = f"scaling_results_trial{t}.csv"

        # ---- HYBRID ----
        if "hybrid" in methods:
            print("[HYBRID] running…")
            hres = run_hybrid_once(
                backend=backend,
                shots=hybrid_shots,
                iters=hybrid_iters,
                opt_level=opt_level,
                seed_transpiler=seed_transpiler,
                use_zne=use_zne,
                F_threshold=F_threshold, tau=tau, eps=eps,
                aco_ants=aco_ants, aco_step=aco_step, aco_evap=aco_evap, aco_strength=aco_strength,
                pso_swarm=pso_swarm, pso_iters=pso_iters,
                ga_pop=ga_pop, ga_iters=ga_iters, ga_cx=ga_cx, ga_mut=ga_mut,
                ba_bees=ba_bees, ba_elite=ba_elite, ba_recruits=ba_recruits,
                ba_radius=ba_radius, ba_iters=ba_iters, ba_stagn=ba_stagn,
                patience=patience, tol=tol,
                log_file=hybrid_csv,
            )
            append_summary_row(summary_csv, {
                "trial": t,
                "method": "HYBRID",
                "backend": backend,
                "shots": hybrid_shots,
                "iters": hybrid_iters,
                "best_score": round(float(hres["score"]), 6),
                "elapsed_s": round(float(hres["elapsed_s"]), 3),
                "artifact": hybrid_csv,
            })
            print(f"[HYBRID] best_score={hres['score']:.4f} elapsed_s={hres['elapsed_s']:.2f}")

        # ---- BASELINES ----
        if {"random", "spsa", "ideal"} & set(methods):
            print("[BASELINES] running…")
            bres = run_baselines_once(
                backend=backend,
                shots_random=random_shots,
                shots_spsa=spsa_shots,
                random_iters=random_iters,
                spsa_iters=spsa_iters,
                ideal_iters=ideal_iters,
                seed=seed,
                random_csv=random_csv,
                spsa_csv=spsa_csv,
                ideal_csv=ideal_csv,
            )
            if "random" in methods:
                append_summary_row(summary_csv, {
                    "trial": t,
                    "method": "RANDOM",
                    "backend": backend,
                    "shots": random_shots,
                    "iters": random_iters,
                    "best_score": round(float(bres["random"]["score"]), 6),
                    "elapsed_s": round(float(bres["random"]["elapsed_s"]), 3),
                    "artifact": random_csv,
                })
                print(f"[RANDOM] best_score={bres['random']['score']:.4f} elapsed_s={bres['random']['elapsed_s']:.2f}")

            if "spsa" in methods:
                append_summary_row(summary_csv, {
                    "trial": t,
                    "method": "SPSA",
                    "backend": backend,
                    "shots": spsa_shots,
                    "iters": spsa_iters,
                    "best_score": round(float(bres["spsa"]["score"]), 6),
                    "elapsed_s": round(float(bres["spsa"]["elapsed_s"]), 3),
                    "artifact": spsa_csv,
                })
                print(f"[SPSA] best_score={bres['spsa']['score']:.4f} elapsed_s={bres['spsa']['elapsed_s']:.2f}")

            if "ideal" in methods:
                append_summary_row(summary_csv, {
                    "trial": t,
                    "method": "IDEAL",
                    "backend": "local_statevector",
                    "shots": 0,
                    "iters": ideal_iters,
                    "best_score": round(float(bres["ideal"]["score"]), 6),
                    "elapsed_s": round(float(bres["ideal"]["elapsed_s"]), 3),
                    "artifact": ideal_csv,
                })
                print(f"[IDEAL] best_score={bres['ideal']['score']:.4f} elapsed_s={bres['ideal']['elapsed_s']:.2f}")

        # ---- Optional SCALING ----
        sc_path = maybe_run_scaling(
            do_scaling=do_scaling,
            backend=backend,
            shots=scaling_shots,
            ns=scaling_ns,
            out_csv=scaling_csv
        )
        if sc_path:
            print(f"[SCALING] CSV → {sc_path}")

        # ---- Optional NOISE demo ----
        png = maybe_run_noise_demo(
            do_noise=do_noise,
            backend_mode=noise_backend_mode,
            azure_backend=noise_backend,
            outdir=noise_outdir,
            shots=noise_shots,
            lam0=lam0, gamma1=gamma1, lam2=lam2, lam3=lam3,
        )
        if png:
            print(f"[NOISE] PNG → {png}")

    print(f"\n[run_trials] Summary CSV → {os.path.abspath(summary_csv)}")


# ----------------------------
# CLI
# ----------------------------

def parse_args():
    p = argparse.ArgumentParser(description="Multi-trial runner for Azure Quantum experiments")

    # What to run
    p.add_argument("--methods", nargs="+",
                   default=["hybrid", "random", "spsa", "ideal"],
                   choices=["hybrid", "random", "spsa", "ideal"],
                   help="Which methods to run per trial")

    p.add_argument("--trials", type=int, default=3, help="Number of trials (seeds)")

    # Backend + summary
    p.add_argument("--backend", type=str, default=os.getenv("AZURE_QUANTUM_BACKEND", "ionq.simulator"),
                   help="Azure backend, e.g., ionq.simulator, ionq.qpu, quantinuum.h1-1e")
    p.add_argument("--summary", type=str, default="trials_summary.csv", help="Summary CSV output path")

    # HYBRID knobs
    p.add_argument("--hybrid-iters", type=int, default=6)
    p.add_argument("--hybrid-shots", type=int, default=4000)
    p.add_argument("--opt-level", type=int, default=1)
    p.add_argument("--seed-transpiler", type=int, default=None)
    p.add_argument("--no-zne", action="store_true", help="Disable ZNE in HYBRID")
    p.add_argument("--F-threshold", type=float, default=0.95)
    p.add_argument("--tau", type=float, default=0.90)
    p.add_argument("--eps", type=float, default=0.02)
    p.add_argument("--aco-ants", type=int, default=20)
    p.add_argument("--aco-step", type=float, default=0.12)
    p.add_argument("--aco-evap", type=float, default=0.2)
    p.add_argument("--aco-strength", type=float, default=1.0)
    p.add_argument("--pso-swarm", type=int, default=20)
    p.add_argument("--pso-iters", type=int, default=6)
    p.add_argument("--ga-pop", type=int, default=30)
    p.add_argument("--ga-iters", type=int, default=6)
    p.add_argument("--ga-cx", type=float, default=0.85)
    p.add_argument("--ga-mut", type=float, default=0.12)
    p.add_argument("--ba-bees", type=int, default=24)
    p.add_argument("--ba-elite", type=int, default=5)
    p.add_argument("--ba-recruits", type=int, default=3)
    p.add_argument("--ba-radius", type=float, default=0.06)
    p.add_argument("--ba-iters", type=int, default=6)
    p.add_argument("--ba-stagn", type=int, default=3)
    p.add_argument("--patience", type=int, default=4)
    p.add_argument("--tol", type=float, default=1e-3)

    # BASELINES knobs
    p.add_argument("--random-iters", type=int, default=80)
    p.add_argument("--spsa-iters", type=int, default=60)
    p.add_argument("--ideal-iters", type=int, default=200)
    p.add_argument("--random-shots", type=int, default=4000)
    p.add_argument("--spsa-shots", type=int, default=4000)

    # Optional: SCALING benchmark for each trial
    p.add_argument("--with-scaling", action="store_true", help="Also run scaling benchmark per trial")
    p.add_argument("--scaling-ns", type=int, nargs="+", default=[2, 3, 4, 5, 6, 8, 10])
    p.add_argument("--scaling-shots", type=int, default=2000)

    # Optional: NOISE demo for each trial
    p.add_argument("--with-noise", action="store_true", help="Also generate ideal vs noisy PNG per trial")
    p.add_argument("--noise-backend-mode", type=str, choices=["aer", "azure"], default="aer",
                   help="Where to run 'ideal' circuit for noise demo")
    p.add_argument("--noise-backend", type=str, default=None, help="Azure backend for noise demo when mode='azure'")
    p.add_argument("--noise-outdir", type=str, default=".", help="Directory for noise PNGs")
    p.add_argument("--noise-shots", type=int, default=20000)
    p.add_argument("--lam0", type=float, default=0.01)  # depolarizing q0
    p.add_argument("--gamma1", type=float, default=0.10)  # amp-damp q1
    p.add_argument("--lam2", type=float, default=0.10)  # readout q0
    p.add_argument("--lam3", type=float, default=0.20)  # readout q1

    # Utility
    p.add_argument("--dry-run", action="store_true", help="Print plan and exit without executing")

    return p.parse_args()


def main():
    args = parse_args()

    run_trials(
        trials=args.trials,
        methods=args.methods,
        backend=args.backend,
        summary_csv=args.summary,
        # HYBRID
        hybrid_iters=args.hybrid_iters,
        hybrid_shots=args.hybrid_shots,
        opt_level=args.opt_level,
        seed_transpiler=args.seed_transpiler,
        use_zne=(not args.no_zne),
        F_threshold=args.F_threshold,
        tau=args.tau,
        eps=args.eps,
        aco_ants=args.aco_ants,
        aco_step=args.aco_step,
        aco_evap=args.aco_evap,
        aco_strength=args.aco_strength,
        pso_swarm=args.pso_swarm,
        pso_iters=args.pso_iters,
        ga_pop=args.ga_pop,
        ga_iters=args.ga_iters,
        ga_cx=args.ga_cx,
        ga_mut=args.ga_mut,
        ba_bees=args.ba_bees,
        ba_elite=args.ba_elite,
        ba_recruits=args.ba_recruits,
        ba_radius=args.ba_radius,
        ba_iters=args.ba_iters,
        ba_stagn=args.ba_stagn,
        patience=args.patience,
        tol=args.tol,
        # BASELINES
        random_iters=args.random_iters,
        spsa_iters=args.spsa_iters,
        ideal_iters=args.ideal_iters,
        random_shots=args.random_shots,
        spsa_shots=args.spsa_shots,
        # Extras
        do_scaling=args.with_scaling,
        scaling_ns=args.scaling_ns,
        scaling_shots=args.scaling_shots,
        do_noise=args.with_noise,
        noise_backend_mode=args.noise_backend_mode,
        noise_backend=args.noise_backend,
        noise_outdir=args.noise_outdir,
        noise_shots=args.noise_shots,
        lam0=args.lam0, gamma1=args.gamma1, lam2=args.lam2, lam3=args.lam3,
        dry_run=args.dry_run,
    )


if __name__ == "__main__":
    main()
