# module_hybrid_opt_braket.py  (Azure Quantum edition)
# ------------------------------------------------------------
# Faithful Algorithm-3 (ACO -> PSO -> GA -> BA) with feasibility, repair,
# robustness tolerance, hardware-friendly ZNE (via gate-folding), and CSV logging.
#
# CSV: hybrid_log.csv with columns:
#   iteration,method,fidelity,feasible,repaired,elapsed_s
#
# Depends on braket_common.py (Azure edition) providing:
#   AzureQuantumConfig, get_backend, qc_create, qc_measure_all, run, Q, ez, ezz
#
# NOTE on ZNE: On real hardware we can't dial noise parameters directly.
# We emulate "more noise" by *folding* unitary layers (depth scaling),
# then linearly/quadratically extrapolate the observable to zero-depth.
# ------------------------------------------------------------

from __future__ import annotations

import os
import csv
import math
import time
import argparse
from dataclasses import dataclass
from typing import Dict, Tuple, Iterable, Optional

import numpy as np

from braket_common import (
    AzureQuantumConfig,
    qc_create,
    qc_measure_all,
    run,
    Q,
    ezz,
)

# ------------------- Global/problem config -------------------
NDIMS = 4                               # number of gate parameters θ0..θ3
PARAM_BOUNDS = (-math.pi, math.pi)      # per-parameter bounds
# Hardware-friendly ZNE uses *fold factors* (odd integers); we default to {1,3,5}.
DEFAULT_ZNE_FOLDS = (1, 3, 5)

LOG_FILE = "hybrid_log.csv"
LOG_HEADER = ["iteration", "method", "fidelity", "feasible", "repaired", "elapsed_s"]


# ------------------- Small helpers -------------------
def clip_params(x):
    lo, hi = PARAM_BOUNDS
    return np.clip(np.array(x, dtype=float), lo, hi)


def rand_vec(rng, radius):
    return rng.uniform(-radius, radius, NDIMS)


def append_csv_row(path, row_dict):
    """Append a single row to CSV, create file with header if missing."""
    file_exists = os.path.exists(path)
    with open(path, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=LOG_HEADER)
        if not file_exists:
            w.writeheader()
        w.writerow(row_dict)


# ------------------- Objective & hardware-friendly ZNE -------------------
@dataclass
class EvalConfig:
    """Execution config for Azure Quantum."""
    backend_name: str = os.getenv("AZURE_QUANTUM_BACKEND", "ionq.simulator")
    shots: int = 4000                      # use 0 only on local sims; hardware needs finite shots
    reverse_bits: bool = False             # set True if your postproc assumes reversed bitstrings
    transpile_optimization_level: int = 1
    seed_transpiler: Optional[int] = None


class NoiseAwareObjective:
    """
    Builds param circuits; evaluates ⟨Z0 Z1⟩ on Azure via Qiskit backends.
    If use_zne=True, performs gate-folding ZNE (depth scaling factors e.g. 1,3,5)
    and extrapolates y(fold)->y0 at fold=1→0 using linear fit.
    """

    def __init__(self,
                 eval_cfg: EvalConfig,
                 use_zne: bool = True,
                 zne_folds: Iterable[int] = DEFAULT_ZNE_FOLDS):
        self.cfg = eval_cfg
        self.use_zne = bool(use_zne)
        self.folds = tuple(int(k) for k in zne_folds)
        self._cache: Dict[Tuple[Tuple[float, ...], int, int], float] = {}

    # ----- circuit builders -----
    def _base_layers(self, qc, theta):
        # Matches your original param pattern: RX(0,θ0) · RY(1,θ1) · CX(0,1) · RZ(0,θ2) · RX(1,θ3)
        Q.rx(qc, float(theta[0]), 0)
        Q.ry(qc, float(theta[1]), 1)
        Q.cx(qc, 0, 1)
        Q.rz(qc, float(theta[2]), 0)
        Q.rx(qc, float(theta[3]), 1)

    def _build_param_circuit(self, theta, folds: int = 1):
        """
        Build a 2-qubit circuit and (optionally) fold the *unitary* layers to scale depth.
        Folding scheme: apply the base layers 'folds' times (folds must be odd in classic ZNE,
        but we accept any int>=1; odd numbers recommended).
        """
        theta = tuple(clip_params(theta))
        qc = qc_create(2, with_classical=True, name="hybrid_param")
        # Ensure at least one pass; for folds>1 we simply repeat the same block.
        rep = max(1, int(folds))
        for _ in range(rep):
            self._base_layers(qc, theta)
        # We measure both qubits and later compute ⟨Z0 Z1⟩ from counts.
        qc_measure_all(qc)
        return qc

    # ----- evaluation -----
    def _eval_once(self, theta, folds: int) -> float:
        theta = tuple(clip_params(theta))
        key = (theta, int(folds), int(self.cfg.shots))
        if key in self._cache:
            return self._cache[key]

        qc = self._build_param_circuit(theta, folds=folds)
        rr = run(
            qc,
            backend_name=self.cfg.backend_name,
            shots=self.cfg.shots,
            reverse_bits=self.cfg.reverse_bits,
            transpile_optimization_level=self.cfg.transpile_optimization_level,
            seed_transpiler=self.cfg.seed_transpiler,
        )
        # compute <Z0 Z1> from counts
        val = float(ezz(rr.counts, 0, 1))
        self._cache[key] = val
        return val

    def evaluate(self, theta):
        """
        Return ⟨Z0 Z1⟩ at theta.
        - If use_zne: evaluate at multiple fold factors and do a linear fit vs. effective depth.
        - Else: just run at fold=1.
        """
        if not self.use_zne or len(self.folds) <= 1:
            return self._eval_once(theta, folds=1)

        xs = np.array([int(k) for k in self.folds], dtype=float)
        ys = np.array([self._eval_once(theta, folds=int(k)) for k in self.folds], dtype=float)

        # Linear extrapolation y(x) = a*x + b, and we estimate y0 at x→0 ⇒ y0 = b.
        a, b = np.polyfit(xs, ys, deg=1)
        y0 = float(b)
        # Clamp to physical range [-1,1]
        return max(-1.0, min(1.0, y0))


# ------------------- Feasibility & repair -------------------
class Feasibility:
    """
    Is_Feasible and Repair_Solution (Algorithm 3):
    - Feasible if F(θ) >= F_threshold and robust under small perturbations δ: F(θ+δ) >= tau.
    - Repair projects to bounds, then does a short local backoff search to recover feasibility.
    """

    def __init__(self, objective: NoiseAwareObjective, F_threshold=0.95, tau=0.90, eps=0.02, rng=None):
        self.obj = objective
        self.F_threshold = float(F_threshold)
        self.tau = float(tau)
        self.eps = float(eps)
        self.rng = np.random.default_rng(None if rng is None else rng)

    def is_feasible(self, theta, checks=3):
        theta = clip_params(theta)
        f0 = self.obj.evaluate(theta)
        if f0 < self.F_threshold:
            return False, f0
        for _ in range(checks):
            cand = clip_params(theta + self.rng.uniform(-self.eps, self.eps, NDIMS))
            f = self.obj.evaluate(cand)
            if f < self.tau:
                return False, f0
        return True, f0

    def repair(self, theta, max_tries=20, step=0.05):
        """
        Returns (theta_repaired, f(theta_repaired), repaired_flag, feasible_flag)
        """
        theta = clip_params(theta)
        ok0, f0 = self.is_feasible(theta)
        repaired = False
        if ok0:
            return theta, f0, repaired, True

        best = theta.copy()
        fbest = f0
        for _ in range(max_tries):
            tried = []
            for _k in range(8):
                trial = clip_params(best + self.rng.uniform(-step, step, NDIMS))
                ok_tr, ftr = self.is_feasible(trial)
                tried.append((ok_tr, ftr, trial))
            tried.sort(key=lambda e: (e[0], e[1]), reverse=True)
            ok_b, f_b, x_b = tried[0]
            if ok_b:
                return x_b, f_b, True, True
            best = x_b
            fbest = f_b
            step *= 0.8
            repaired = True
        ok_final, _ = self.is_feasible(best)
        return best, fbest, repaired, ok_final

    def ensure_feasible(self, theta, **kwargs):
        """
        Convenience for stages: returns (theta2, f2, feasible_before, repaired_flag, feasible_after)
        """
        ok_before, _ = self.is_feasible(theta)
        theta2, f2, repaired, ok_after = self.repair(theta, **kwargs)
        return theta2, f2, ok_before, repaired, ok_after


# ------------------- Metaheuristics (faithful operators) -------------------
class FaithfulHybridOptimizer:
    """
    Faithful Algorithm-3 sequence per outer iteration:
    1) ACO step guided by pheromone -> candidate(s)
    2) PSO refinement using velocities and elite/global best
    3) GA crossover + mutation
    4) BA local neighborhood search (employed/onlooker), scouts on stagnation
    After each stage: Is_Feasible + Repair_Solution, elite forwarding, history.
    Logs CSV rows per stage per iteration.
    """

    def __init__(self, objective: NoiseAwareObjective, feasibility: Feasibility,
                 log_path=LOG_FILE, rng=None):
        self.obj = objective
        self.feas = feasibility
        self.log_path = log_path
        self.rng = np.random.default_rng(None if rng is None else rng)

        # ACO pheromone over parameters (vector form)
        self.pheromone = np.ones(NDIMS, dtype=float)
        self.ph_evap = 0.2
        self.ph_strength = 1.0

        # PSO params
        self.w_max, self.w_min = 0.9, 0.4
        self.c1, self.c2 = 1.6, 1.6
        self.v_clip = 0.35 * math.pi

        # Ensure CSV header exists
        if not os.path.exists(self.log_path):
            append_csv_row(self.log_path, dict(zip(LOG_HEADER, LOG_HEADER)))

    # ---------- ACO ----------
    def step_aco(self, base, ants=20, step=0.12):
        trail = self.pheromone / (self.pheromone.sum() + 1e-12)
        proto = clip_params(base)  # base guides; pheromone affects update, not sampling mean
        cand = []
        for _ in range(ants):
            x = clip_params(proto + self.rng.uniform(-step, step, NDIMS))
            # feasibility + repair
            x, f, _, _, _ = self.feas.ensure_feasible(x, max_tries=10, step=step)
            cand.append((f, x))
        cand.sort(key=lambda t: t[0], reverse=True)
        f_best, x_best = cand[0]
        # pheromone update (evaporation + reinforcement by |x_best|)
        self.pheromone = (1 - self.ph_evap) * self.pheromone + self.ph_strength * np.abs(x_best)
        return x_best, f_best

    # ---------- PSO ----------
    def step_pso(self, gbest_x, swarm=20, iters=6):
        x = self.rng.uniform(PARAM_BOUNDS[0], PARAM_BOUNDS[1], size=(swarm, NDIMS))
        v = np.zeros_like(x)
        # initial repair/evaluate
        for i in range(swarm):
            x[i], _, _, _, _ = self.feas.ensure_feasible(x[i], max_tries=6, step=0.06)
        pbest = x.copy()
        pbest_f = np.array([self.obj.evaluate(xx) for xx in x])
        gbest = pbest[pbest_f.argmax()].copy()
        gbest_f = float(pbest_f.max())
        if gbest_x is not None:
            gx, gf, _, _, _ = self.feas.ensure_feasible(gbest_x, max_tries=6, step=0.06)
            fx = self.obj.evaluate(gx)
            if fx > gbest_f:
                gbest, gbest_f = gx.copy(), fx

        for t in range(iters):
            w = self.w_max - (self.w_max - self.w_min) * (t / max(1, iters - 1))
            r1, r2 = self.rng.random(size=x.shape), self.rng.random(size=x.shape)
            v = w * v + self.c1 * r1 * (pbest - x) + self.c2 * r2 * (gbest - x)
            v = np.clip(v, -self.v_clip, self.v_clip)
            x = clip_params(x + v)
            # feasibility + repair
            for i in range(swarm):
                x[i], _, _, _, _ = self.feas.ensure_feasible(x[i], max_tries=6, step=0.06)
            f = np.array([self.obj.evaluate(xx) for xx in x])
            improved = f > pbest_f
            pbest[improved] = x[improved]
            pbest_f[improved] = f[improved]
            if pbest_f.max() > gbest_f:
                gbest = pbest[pbest_f.argmax()].copy()
                gbest_f = float(pbest_f.max())
        return gbest, gbest_f

    # ---------- GA ----------
    def step_ga(self, elite_x, pop_size=30, iters=6, cx_prob=0.85, mut_prob=0.12):
        pop = self.rng.uniform(PARAM_BOUNDS[0], PARAM_BOUNDS[1], size=(pop_size, NDIMS))
        pop[0] = elite_x.copy()
        # repair initial
        for i in range(pop_size):
            pop[i], _, _, _, _ = self.feas.ensure_feasible(pop[i], max_tries=6, step=0.06)
        fit = np.array([self.obj.evaluate(xx) for xx in pop])

        for t in range(iters):
            new = [pop[fit.argmax()].copy()]  # elitism
            while len(new) < pop_size:
                i, j = self.rng.integers(0, pop_size, 2)
                p1, p2 = pop[i], pop[j]
                child = p1.copy()
                if self.rng.random() < cx_prob:
                    alpha = self.rng.uniform(0.2, 0.8)
                    child = alpha * p1 + (1 - alpha) * p2
                if self.rng.random() < mut_prob:
                    strength = (1 - t / max(1, iters)) * 0.45
                    child = child + self.rng.normal(0, strength, size=NDIMS)
                child, _, _, _, _ = self.feas.ensure_feasible(child, max_tries=6, step=0.06)
                new.append(clip_params(child))
            pop = np.array(new[:pop_size])
            fit = np.array([self.obj.evaluate(xx) for xx in pop])

        best = fit.argmax()
        return pop[best], float(fit[best])

    # ---------- BA ----------
    def step_ba(self, seed_x, bees=24, elite=5, recruits=3, radius=0.06, iters=6, stagn_limit=3):
        pop = np.array([clip_params(seed_x + rand_vec(self.rng, radius)) for _ in range(bees)])
        pop[0] = seed_x.copy()
        for i in range(bees):
            pop[i], _, _, _, _ = self.feas.ensure_feasible(pop[i], max_tries=6, step=radius)
        fit = np.array([self.obj.evaluate(xx) for xx in pop])

        best_x = pop[fit.argmax()].copy()
        best_f = float(fit.max())
        stagn = 0

        for _ in range(iters):
            idx = np.argsort(-fit)[:elite]
            new = []
            for i in idx:
                center = pop[i]
                for _r in range(recruits):
                    cand = clip_params(center + rand_vec(self.rng, radius))
                    cand, _, _, _, _ = self.feas.ensure_feasible(cand, max_tries=6, step=radius)
                    new.append(cand)
            while len(new) < bees:
                x = clip_params(seed_x + rand_vec(self.rng, radius))
                x, _, _, _, _ = self.feas.ensure_feasible(x, max_tries=4, step=radius)
                new.append(x)

            pop = np.array(new[:bees])
            fit = np.array([self.obj.evaluate(xx) for xx in pop])

            if fit.max() > best_f:
                best_x = pop[fit.argmax()].copy()
                best_f = float(fit.max())
                stagn = 0
            else:
                stagn += 1
                if stagn >= stagn_limit:
                    # scouts: reinitialize half broadly
                    for k in range(bees // 2):
                        pop[k] = clip_params(self.rng.uniform(PARAM_BOUNDS[0], PARAM_BOUNDS[1], NDIMS))
                        pop[k], _, _, _, _ = self.feas.ensure_feasible(pop[k], max_tries=4, step=0.08)
                        fit[k] = self.obj.evaluate(pop[k])
                    stagn = 0
        return best_x, best_f

    # ---------- Orchestrated outer loop with CSV logging ----------
    def orchestrate(self, outer_iters=10,
                    aco_cfg=None, pso_cfg=None, ga_cfg=None, ba_cfg=None,
                    stop_patience=4, stop_tol=1e-3):
        aco_cfg = aco_cfg or {}
        pso_cfg = pso_cfg or {}
        ga_cfg  = ga_cfg or {}
        ba_cfg  = ba_cfg or {}

        # initialize elite (feasible)
        elite_x = clip_params(self.rng.uniform(PARAM_BOUNDS[0], PARAM_BOUNDS[1], NDIMS))
        elite_x, elite_f, _, _, _ = self.feas.ensure_feasible(elite_x)
        history = [elite_f]
        best_overall = elite_f
        no_improve = 0
        t0 = time.time()

        for it in range(1, outer_iters + 1):
            # 1) ACO
            ts = time.time()
            x_aco, f_aco = self.step_aco(elite_x, **aco_cfg)
            append_csv_row(self.log_path, {
                "iteration": it, "method": "ACO", "fidelity": f_aco,
                "feasible": "yes", "repaired": "maybe",
                "elapsed_s": round(time.time() - ts, 3),
            })
            if f_aco > elite_f:
                elite_x, elite_f = x_aco, f_aco

            # 2) PSO
            ts = time.time()
            x_pso, f_pso = self.step_pso(elite_x, **pso_cfg)
            append_csv_row(self.log_path, {
                "iteration": it, "method": "PSO", "fidelity": f_pso,
                "feasible": "yes", "repaired": "maybe",
                "elapsed_s": round(time.time() - ts, 3),
            })
            if f_pso > elite_f:
                elite_x, elite_f = x_pso, f_pso

            # 3) GA
            ts = time.time()
            x_ga, f_ga = self.step_ga(elite_x, **ga_cfg)
            append_csv_row(self.log_path, {
                "iteration": it, "method": "GA", "fidelity": f_ga,
                "feasible": "yes", "repaired": "maybe",
                "elapsed_s": round(time.time() - ts, 3),
            })
            if f_ga > elite_f:
                elite_x, elite_f = x_ga, f_ga

            # 4) BA
            ts = time.time()
            x_ba, f_ba = self.step_ba(elite_x, **ba_cfg)
            append_csv_row(self.log_path, {
                "iteration": it, "method": "BA", "fidelity": f_ba,
                "feasible": "yes", "repaired": "maybe",
                "elapsed_s": round(time.time() - ts, 3),
            })
            if f_ba > elite_f:
                elite_x, elite_f = x_ba, f_ba

            history.append(elite_f)
            # early stopping on plateau
            if elite_f > best_overall + stop_tol:
                best_overall = elite_f
                no_improve = 0
            else:
                no_improve += 1
                if no_improve >= stop_patience:
                    break

        return {
            "theta": elite_x.tolist(),
            "score": float(elite_f),
            "history": [float(x) for x in history],
            "elapsed_s": round(time.time() - t0, 3),
            "log_file": self.log_path,
        }


# ------------------- CLI -------------------
def parse_args():
    p = argparse.ArgumentParser(description="Faithful Algorithm-3 hybrid optimizer on Azure Quantum (with CSV logging)")

    # core iters/shots + zne
    p.add_argument("--iters", type=int, default=6, help="Outer iterations (ACO->PSO->GA->BA cycles)")
    p.add_argument("--shots", type=int, default=4000, help="Finite shots for hardware/sim")
    p.add_argument("--no-zne", action="store_true", help="Disable ZNE (gate-folding)")

    # backend & transpile
    p.add_argument("--backend", type=str, default=os.getenv("AZURE_QUANTUM_BACKEND", "ionq.simulator"),
                   help="Azure backend, e.g., ionq.simulator, ionq.qpu, quantinuum.h1-1e, rigetti.qpu.ankaa-3")
    p.add_argument("--opt-level", type=int, default=1, help="Qiskit transpile optimization_level (0-3)")
    p.add_argument("--seed-transpiler", type=int, default=None)

    # Feasibility thresholds
    p.add_argument("--F_threshold", type=float, default=0.95)
    p.add_argument("--tau", type=float, default=0.90)
    p.add_argument("--eps", type=float, default=0.02)

    # ACO config
    p.add_argument("--aco-ants", type=int, default=20)
    p.add_argument("--aco-step", type=float, default=0.12)
    p.add_argument("--aco-evap", type=float, default=0.2)
    p.add_argument("--aco-strength", type=float, default=1.0)

    # PSO config
    p.add_argument("--pso-swarm", type=int, default=20)
    p.add_argument("--pso-iters", type=int, default=6)

    # GA config
    p.add_argument("--ga-pop", type=int, default=30)
    p.add_argument("--ga-iters", type=int, default=6)
    p.add_argument("--ga-cx", type=float, default=0.85)
    p.add_argument("--ga-mut", type=float, default=0.12)

    # BA config
    p.add_argument("--ba-bees", type=int, default=24)
    p.add_argument("--ba-elite", type=int, default=5)
    p.add_argument("--ba-recruits", type=int, default=3)
    p.add_argument("--ba-radius", type=float, default=0.06)
    p.add_argument("--ba-iters", type=int, default=6)
    p.add_argument("--ba-stagn", type=int, default=3)

    # Early stop
    p.add_argument("--patience", type=int, default=4)
    p.add_argument("--tol", type=float, default=1e-3)

    # Log file path (optional)
    p.add_argument("--log", type=str, default=LOG_FILE)

    return p.parse_args()


def main():
    args = parse_args()

    eval_cfg = EvalConfig(
        backend_name=args.backend,
        shots=args.shots,
        reverse_bits=False,
        transpile_optimization_level=args.opt_level,
        seed_transpiler=args.seed_transpiler,
    )

    obj = NoiseAwareObjective(eval_cfg=eval_cfg, use_zne=not args.no_zne, zne_folds=DEFAULT_ZNE_FOLDS)
    feas = Feasibility(
        objective=obj,
        F_threshold=args.F_threshold,
        tau=args.tau,
        eps=args.eps,
        rng=None,
    )
    opt = FaithfulHybridOptimizer(objective=obj, feasibility=feas, log_path=args.log, rng=None)

    # wire ACO config knobs chosen by user
    opt.ph_evap = args.aco_evap
    opt.ph_strength = args.aco_strength

    result = opt.orchestrate(
        outer_iters=args.iters,
        aco_cfg={"ants": args.aco_ants, "step": args.aco_step},
        pso_cfg={"swarm": args.pso_swarm, "iters": args.pso_iters},
        ga_cfg={"pop_size": args.ga_pop, "iters": args.ga_iters, "cx_prob": args.ga_cx, "mut_prob": args.ga_mut},
        ba_cfg={"bees": args.ba_bees, "elite": args.ba_elite, "recruits": args.ba_recruits,
                "radius": args.ba_radius, "iters": args.ba_iters, "stagn_limit": args.ba_stagn},
        stop_patience=args.patience, stop_tol=args.tol
    )
    print(result)


if __name__ == "__main__":
    main()
