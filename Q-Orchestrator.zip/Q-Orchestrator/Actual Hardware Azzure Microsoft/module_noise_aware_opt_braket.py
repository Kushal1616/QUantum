# module_noise_aware_opt_braket.py  (Azure Quantum edition)
# ------------------------------------------------------------
# "Noise-aware optimization" on Azure using Qiskit:
#  - Objective: maximize fidelity to a Bell-type target using ⟨Z0 Z1⟩
#  - Noise handling: ZNE via gate-folding with folds {1,3,5}, linear extrapolation
#  - Robustness: average objective over small parameter jitters
#  - Optimizer: SPSA (stochastic gradient) with decaying step sizes
#  - Logging: CSV of per-iteration metrics
#
# Depends on: braket_common.py (Azure edition) providing:
#   qc_create, qc_measure_all, run, Q, ezz
# ------------------------------------------------------------

from __future__ import annotations

import os
import csv
import math
import time
import argparse
from dataclasses import dataclass
from typing import Iterable, Optional, Tuple, Dict

import numpy as np

from braket_common import (
    qc_create, qc_measure_all, run, Q, ezz
)

# ------------------- Config & small helpers -------------------

NDIMS = 4                      # gate parameter count (θ0..θ3)
PARAM_BOUNDS = (-math.pi, math.pi)

LOG_HEADER = [
    "iter", "score_zne", "score_raw_f1",
    "theta0", "theta1", "theta2", "theta3",
    "c_k", "a_k", "elapsed_s"
]


def clip_params(x):
    lo, hi = PARAM_BOUNDS
    return np.clip(np.array(x, dtype=float), lo, hi)


def append_csv_row(path, row_dict):
    file_exists = os.path.exists(path)
    with open(path, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=LOG_HEADER)
        if not file_exists:
            w.writeheader()
        w.writerow(row_dict)


# ------------------- Execution config -------------------

@dataclass
class EvalConfig:
    backend_name: str = os.getenv("AZURE_QUANTUM_BACKEND", "ionq.simulator")
    shots: int = 4000
    reverse_bits: bool = False
    opt_level: int = 1
    seed_transpiler: Optional[int] = None


# ------------------- ZNE + objective -------------------

class ZNEObjective:
    """
    Builds a 2-qubit parameterized circuit and evaluates ⟨Z0 Z1⟩.
    If use_zne, evaluate at fold factors (1,3,5) and extrapolate linearly to "zero noise".
    Also provides a "robust" expectation by averaging over small jitters in theta.
    """

    def __init__(self,
                 eval_cfg: EvalConfig,
                 use_zne: bool = True,
                 zne_folds: Iterable[int] = (1, 3, 5),
                 rng: Optional[np.random.Generator] = None):
        self.cfg = eval_cfg
        self.use_zne = bool(use_zne)
        self.folds = tuple(int(k) for k in zne_folds)
        self.rng = rng or np.random.default_rng()

        # memoization: ((theta tuple), fold, shots) -> value
        self._cache: Dict[Tuple[Tuple[float, ...], int, int], float] = {}

    # Circuit pattern compatible with your earlier modules
    def _base_layers(self, qc, theta):
        Q.rx(qc, float(theta[0]), 0)
        Q.ry(qc, float(theta[1]), 1)
        Q.cx(qc, 0, 1)
        Q.rz(qc, float(theta[2]), 0)
        Q.rx(qc, float(theta[3]), 1)

    def _build(self, theta, folds: int = 1):
        theta = tuple(clip_params(theta))
        qc = qc_create(2, with_classical=True, name="noise_aware_param")
        rep = max(1, int(folds))
        for _ in range(rep):
            self._base_layers(qc, theta)
        qc_measure_all(qc)
        return qc

    def _eval_fold(self, theta, folds: int) -> float:
        theta = tuple(clip_params(theta))
        key = (theta, int(folds), int(self.cfg.shots))
        if key in self._cache:
            return self._cache[key]

        qc = self._build(theta, folds=folds)
        rr = run(
            qc,
            backend_name=self.cfg.backend_name,
            shots=self.cfg.shots,
            reverse_bits=self.cfg.reverse_bits,
            transpile_optimization_level=self.cfg.opt_level,
            seed_transpiler=self.cfg.seed_transpiler,
        )
        val = float(ezz(rr.counts, 0, 1))   # ⟨Z0 Z1⟩ ∈ [-1, 1]
        self._cache[key] = val
        return val

    def _zne_extrapolate(self, theta) -> float:
        # If ZNE disabled or only one fold, return f(1)
        if not self.use_zne or len(self.folds) <= 1:
            return self._eval_fold(theta, 1)

        xs = np.array([int(k) for k in self.folds], dtype=float)
        ys = np.array([self._eval_fold(theta, int(k)) for k in self.folds], dtype=float)
        # Linear fit y = a*x + b; ZNE target is y(x->0) = b
        a, b = np.polyfit(xs, ys, deg=1)
        y0 = float(b)
        return max(-1.0, min(1.0, y0))

    def evaluate(self, theta, *, robust=False, jitter=0.02, samples=3) -> float:
        """
        Return ZNE-adjusted ⟨Z0 Z1⟩. If robust=True, average over 'samples'
        jitters sampled ~ U(-jitter, +jitter) per parameter.
        """
        theta = clip_params(theta)
        if not robust:
            return self._zne_extrapolate(theta)

        vals = []
        for _ in range(max(1, int(samples))):
            th = clip_params(theta + self.rng.uniform(-jitter, jitter, NDIMS))
            vals.append(self._zne_extrapolate(th))
        return float(np.mean(vals))

    @staticmethod
    def zz_to_fidelity(zz: float) -> float:
        """
        Map ⟨Z0 Z1⟩ → a simple 0..1 fidelity-like score for |Φ+⟩ alignment:
          score = (1 + ⟨Z0 Z1⟩) / 2
        """
        return 0.5 * (1.0 + float(zz))


# ------------------- SPSA optimizer (noise friendly) -------------------

@dataclass
class SPSAConfig:
    iters: int = 40
    a: float = 0.2            # initial step size for 'a_k'
    c: float = 0.1            # initial perturbation scale for 'c_k'
    alpha: float = 0.602      # decay exponent for 'a_k'
    gamma: float = 0.101      # decay exponent for 'c_k'
    a_min: float = 0.02
    c_min: float = 0.01
    avg_robust: bool = True
    robust_jitter: float = 0.02
    robust_samples: int = 3


class NoiseAwareSPSA:
    """
    Maximizes the fidelity-like score using SPSA:
       At each k, measure J(θ + c_k Δ) and J(θ - c_k Δ), estimate stochastic gradient, update θ.
    Suitable for hardware (few evals/iter, resilient to noise).
    """

    def __init__(self,
                 objective: ZNEObjective,
                 rng: Optional[np.random.Generator] = None):
        self.obj = objective
        self.rng = rng or np.random.default_rng()

    def optimize(self,
                 theta0: np.ndarray,
                 cfg: SPSAConfig,
                 log_path: str = "noise_aware_spsa.csv",
                 print_every: int = 5):
        theta = clip_params(theta0)
        a0, c0 = float(cfg.a), float(cfg.c)
        alpha, gamma = float(cfg.alpha), float(cfg.gamma)

        t_start = time.time()
        best_theta = theta.copy()
        best_score = -1.0

        for k in range(1, cfg.iters + 1):
            a_k = max(cfg.a_min, a0 / (k ** alpha))
            c_k = max(cfg.c_min, c0 / (k ** gamma))

            # Rademacher perturbation Δ ∈ {+1,-1}^d
            delta = self.rng.choice([-1.0, 1.0], size=NDIMS)

            theta_plus  = clip_params(theta + c_k * delta)
            theta_minus = clip_params(theta - c_k * delta)

            # Evaluate raw f(fold=1) for logging + ZNE-robust for gradient
            zz_p_raw = self.obj._eval_fold(theta_plus, 1)
            zz_m_raw = self.obj._eval_fold(theta_minus, 1)
            zz_p = self.obj.evaluate(theta_plus,  robust=cfg.avg_robust,
                                     jitter=cfg.robust_jitter, samples=cfg.robust_samples)
            zz_m = self.obj.evaluate(theta_minus, robust=cfg.avg_robust,
                                     jitter=cfg.robust_jitter, samples=cfg.robust_samples)

            # Gradient estimate (maximize score)
            g_hat = (zz_p - zz_m) / (2.0 * c_k * delta + 1e-15)

            theta = clip_params(theta + a_k * g_hat)

            # Score at current θ using ZNE+robust
            zz_now = self.obj.evaluate(theta, robust=cfg.avg_robust,
                                       jitter=cfg.robust_jitter, samples=cfg.robust_samples)
            score_now = self.obj.zz_to_fidelity(zz_now)

            if score_now > best_score:
                best_score = score_now
                best_theta = theta.copy()

            # CSV logging
            append_csv_row(log_path, {
                "iter": k,
                "score_zne": round(score_now, 6),
                "score_raw_f1": round(self.obj.zz_to_fidelity(self.obj._eval_fold(theta, 1)), 6),
                "theta0": round(float(theta[0]), 6),
                "theta1": round(float(theta[1]), 6),
                "theta2": round(float(theta[2]), 6),
                "theta3": round(float(theta[3]), 6),
                "c_k": round(c_k, 6),
                "a_k": round(a_k, 6),
                "elapsed_s": round(time.time() - t_start, 3),
            })

            if (k % max(1, print_every)) == 0:
                print(f"[SPSA] k={k:03d} score(zne)={score_now:.4f} "
                      f"| best={best_score:.4f} | a_k={a_k:.4f} c_k={c_k:.4f}")

        return {
            "theta": best_theta.tolist(),
            "score": float(best_score),
            "elapsed_s": round(time.time() - t_start, 3),
            "log_file": log_path,
        }


# ------------------- CLI wiring -------------------

def parse_args():
    p = argparse.ArgumentParser(description="Noise-aware optimization (ZNE + SPSA) on Azure Quantum")

    # Backend + shots
    p.add_argument("--backend", type=str, default=os.getenv("AZURE_QUANTUM_BACKEND", "ionq.simulator"),
                   help="Azure backend, e.g., ionq.simulator, ionq.qpu, quantinuum.h1-1e")
    p.add_argument("--shots", type=int, default=4000, help="Finite shots for hardware/sim")
    p.add_argument("--opt-level", type=int, default=1, help="Qiskit transpile optimization level (0-3)")
    p.add_argument("--seed-transpiler", type=int, default=None)

    # ZNE & robust averaging
    p.add_argument("--no-zne", action="store_true", help="Disable ZNE (use only fold=1)")
    p.add_argument("--zne-folds", type=int, nargs="+", default=[1, 3, 5], help="Gate-fold factors, e.g., 1 3 5")
    p.add_argument("--robust", action="store_true", help="Enable robust averaging over jitters")
    p.add_argument("--jitter", type=float, default=0.02, help="Uniform jitter size per parameter")
    p.add_argument("--samples", type=int, default=3, help="Number of jitter samples to average")

    # SPSA hyperparams
    p.add_argument("--iters", type=int, default=40)
    p.add_argument("--a", type=float, default=0.2)
    p.add_argument("--c", type=float, default=0.1)
    p.add_argument("--alpha", type=float, default=0.602)
    p.add_argument("--gamma", type=float, default=0.101)
    p.add_argument("--a-min", type=float, default=0.02)
    p.add_argument("--c-min", type=float, default=0.01)
    p.add_argument("--print-every", type=int, default=5)

    # Init parameters (optional)
    p.add_argument("--theta0", type=float, default=0.0)
    p.add_argument("--theta1", type=float, default=0.0)
    p.add_argument("--theta2", type=float, default=0.0)
    p.add_argument("--theta3", type=float, default=0.0)

    # Logging
    p.add_argument("--log", type=str, default="noise_aware_spsa.csv")

    return p.parse_args()


def main():
    args = parse_args()

    eval_cfg = EvalConfig(
        backend_name=args.backend,
        shots=args.shots,
        reverse_bits=False,
        opt_level=args.opt_level,
        seed_transpiler=args.seed_transpiler,
    )

    obj = ZNEObjective(
        eval_cfg=eval_cfg,
        use_zne=(not args.no_zne),
        zne_folds=args.zne_folds,
    )

    spsa_cfg = SPSAConfig(
        iters=args.iters,
        a=args.a, c=args.c,
        alpha=args.alpha, gamma=args.gamma,
        a_min=args.a_min, c_min=args.c_min,
        avg_robust=args.robust,
        robust_jitter=args.jitter,
        robust_samples=args.samples,
    )

    theta0 = clip_params([args.theta0, args.theta1, args.theta2, args.theta3])

    opt = NoiseAwareSPSA(objective=obj)
    result = opt.optimize(theta0=theta0, cfg=spsa_cfg, log_path=args.log, print_every=args.print_every)

    print("=== Noise-aware SPSA Result ===")
    print("best theta:", result["theta"])
    print("best score:", result["score"])
    print("elapsed s :", result["elapsed_s"])
    print("log file  :", result["log_file"])


if __name__ == "__main__":
    main()
