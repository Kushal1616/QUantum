# orchestrator.py
# Author: Kushal Anjaria
# Date: 2025-07-25
# Location: Anand, Gujarat, India
# Description: Main orchestrator to run different modules of the quantum optimization framework.

import sys
from module_noise_simulation import NoiseSimulator
from module_noise_aware_opt import NoiseAwareOptimizer
from module_hybrid_opt import HybridOptimizer

class Orchestrator:
    """
    Coordinates the execution of the different modules of the quantum
    optimization framework, as described in the research paper.
    """
    def __init__(self):
        """Initializes the orchestrator and its modules."""
        print("Quantum Optimization Orchestrator Initialized.")
        self.noise_simulator = NoiseSimulator()
        self.noise_aware_optimizer = NoiseAwareOptimizer()
        self.hybrid_optimizer = HybridOptimizer()

    def run_noise_simulation(self):
        """
        Executes Module 1: Noise Simulation.
        This demonstrates the impact of noise on a quantum circuit by comparing
        an ideal run with a noisy run. Corresponds to the logic in step1.py.
        """
        print("\n" + "="*50)
        print("Executing Module 1: Noise Simulation")
        print("="*50)
        self.noise_simulator.run_and_visualize()
        print("\nModule 1 Execution Complete.")
        print("="*50)


    def run_noise_aware_optimization(self):
        """
        Executes Module 2: Noise-Aware Optimization.
        This demonstrates noise mitigation techniques like Zero-Noise
        Extrapolation (ZNE) and circuit depth optimization.
        Corresponds to the logic in step2.py.
        """
        print("\n" + "="*50)
        print("Executing Module 2: Noise-Aware Optimization")
        print("="*50)
        self.noise_aware_optimizer.run_and_visualize()
        print("\nModule 2 Execution Complete.")
        print("="*50)


    def run_full_hybrid_optimization(self):
        """
        Executes Module 3 & 4: Hybrid Optimization and Evaluation.
        This runs the full, novel hybrid optimization framework combining
        ACO, PSO, GA, and BA to find robust circuit parameters.
        Corresponds to the logic in realfinal2.py.
        """
        print("\n" + "="*50)
        print("Executing Module 3 & 4: Full Hybrid Optimization & Evaluation")
        print("="*50)
        self.hybrid_optimizer.run_optimization()
        print("\nModule 3 & 4 Execution Complete.")
        print("="*50)


def display_menu():
    """Displays the user menu."""
    print("\n--- Quantum Optimization Framework ---")
    print("Select a module to run:")
    print("  1. Noise Simulation (Demonstrates noise impact)")
    print("  2. Noise-Aware Optimization (ZNE & Depth Optimization)")
    print("  3. Full Hybrid Optimization (ACO, PSO, GA, BA)")
    print("  4. Run All Modules Sequentially")
    print("  0. Exit")
    print("------------------------------------")

def main():
    """Main function to drive the orchestrator via a user menu."""
    orchestrator = Orchestrator()

    while True:
        display_menu()
        try:
            choice = int(input("Enter your choice (0-4): "))

            if choice == 1:
                orchestrator.run_noise_simulation()
            elif choice == 2:
                orchestrator.run_noise_aware_optimization()
            elif choice == 3:
                orchestrator.run_full_hybrid_optimization()
            elif choice == 4:
                print("\n>>> Running all modules sequentially...")
                orchestrator.run_noise_simulation()
                orchestrator.run_noise_aware_optimization()
                orchestrator.run_full_hybrid_optimization()
                print("\n>>> All modules executed.")
            elif choice == 0:
                print("Exiting the framework. Goodbye!")
                break
            else:
                print("Invalid choice. Please enter a number between 0 and 4.")
        except ValueError:
            print("Invalid input. Please enter a number.")
        except Exception as e:
            print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()
