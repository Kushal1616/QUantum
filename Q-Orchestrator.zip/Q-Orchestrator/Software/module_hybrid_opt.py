# module_hybrid_opt.py
# Author: Kushal Anjaria
# Date: 2025-07-27
# Location: Anand, Gujarat, India
# Description: Module 3 & 4 of the framework. A full implementation of the
#              hybrid optimization orchestrator, integrating ACO, PSO, GA, and BA.

import pennylane as qml
from pennylane import numpy as np
from scipy.linalg import sqrtm
import random
import matplotlib.pyplot as plt

class HybridOptimizer:
    """
    Encapsulates the full hybrid optimization framework combining ACO, PSO,
    GA, and BA to find robust quantum circuit parameters.
    """
    def __init__(self):
        """Initialize hyperparameters and settings for all algorithms."""
        # General settings
        self.dims = 4
        self.pop_size = 50
        self.iterations = 100
        self.bounds = [(-np.pi, np.pi) for _ in range(self.dims)]
        
        # Fidelity and constraint settings
        self.fidelity_threshold = 0.85
        self.robustness_threshold = 0.005
        self.perturbation_range = 0.1
        self.uncertainty = 0.1
        self.fidelity_cache = {}

        # --- Algorithm-specific hyperparameters ---
        # ACO settings
        self.pheromone_decay = 0.1
        self.pheromone_strength = 1.0

        # BA settings
        self.n_elite_bees = 5
        self.n_local_searches = 3
        self.stagnation_limit = 10


    def _calculate_fidelity(self, params):
        """Calculate fidelity of a noisy circuit against its ideal counterpart."""
        key = tuple(params)
        if key in self.fidelity_cache:
            return self.fidelity_cache[key]

        dev_ideal = qml.device("default.qubit", wires=2)
        dev_noisy = qml.device("default.mixed", wires=4)

        @qml.qnode(dev_ideal)
        def ideal_circuit(p):
            qml.RX(p[0], wires=0); qml.RY(p[1], wires=1)
            qml.CNOT(wires=[0, 1])
            qml.RZ(p[2], wires=0); qml.RX(p[3], wires=1)
            return qml.density_matrix([0, 1])

        @qml.qnode(dev_noisy)
        def noisy_circuit(p):
            qml.RX(p[0], wires=0); qml.RY(p[1], wires=1)
            qml.CNOT(wires=[0, 1])
            qml.RZ(p[2], wires=0); qml.RX(p[3], wires=1)
            qml.DepolarizingChannel(0.05, wires=0)
            qml.AmplitudeDamping(0.1, wires=1)
            return qml.density_matrix([0, 1])

        ideal_dm = ideal_circuit(params)
        noisy_dm = noisy_circuit(params)
        
        sqrt_ideal = sqrtm(ideal_dm)
        fidelity_matrix = sqrtm(sqrt_ideal @ noisy_dm @ sqrt_ideal)
        fidelity = np.trace(fidelity_matrix) ** 2
        
        fidelity_real = np.real(fidelity)
        self.fidelity_cache[key] = fidelity_real
        return fidelity_real

    def _repair_solution(self, solution):
        """Clips a solution to be within the defined bounds."""
        low_bounds = [b[0] for b in self.bounds]
        high_bounds = [b[1] for b in self.bounds]
        return np.clip(solution, low_bounds, high_bounds)

    def _run_sensitivity_analysis(self, best_solution):
        """Performs a sensitivity analysis on the final best solution."""
        print("\nRunning final sensitivity analysis on the best solution...")
        num_perturbations = 20
        fidelities = []
        for _ in range(num_perturbations):
            perturbed_solution = np.copy(best_solution)
            param_to_perturb = np.random.randint(self.dims)
            delta = np.random.uniform(-self.perturbation_range, self.perturbation_range)
            perturbed_solution[param_to_perturb] += delta
            perturbed_solution = self._repair_solution(perturbed_solution)
            fidelities.append(self._calculate_fidelity(perturbed_solution))

        plt.figure(figsize=(12, 6))
        perturbation_indices = range(num_perturbations)
        plt.bar(perturbation_indices, fidelities, color='blue', alpha=0.6, label='Fidelity (Bar)')
        plt.plot(perturbation_indices, fidelities, 'o-', color='red', label='Fidelity (Line)')
        plt.xlabel("Perturbation Index")
        plt.ylabel("Fidelity")
        plt.title("Sensitivity Analysis: Fidelity Under Parameter Perturbations")
        f_min, f_max = min(fidelities), max(fidelities)
        plt.ylim(f_min - 0.01, f_max + 0.01)  # shrinks the y-axis around data
        plt.legend()
        plt.grid(True)
        plt.show()
        print("Sensitivity analysis complete.")
        
    def run_optimization(self):
        """The main hybrid optimization loop orchestrating all four algorithms."""
        # --- Initialization ---
        population = np.random.uniform([b[0] for b in self.bounds], [b[1] for b in self.bounds], (self.pop_size, self.dims))
        population_values = np.array([self._calculate_fidelity(sol) for sol in population])
        
        # PSO variables
        velocities = np.zeros_like(population)
        personal_best = np.copy(population)
        personal_best_values = np.copy(population_values)
        
        # ACO variables
        pheromone_trail = np.ones(self.dims)
        
        # BA variables
        stagnation_counters = np.zeros(self.pop_size)
        
        # Global best tracking
        global_best_idx = np.argmax(personal_best_values)
        global_best = personal_best[global_best_idx]
        
        # History for plotting
        fidelity_progress = []
        parameter_progress = []

        print("Starting full hybrid optimization...")
        for iteration in range(self.iterations):
            
            # --- 1. Ant Colony Optimization (ACO) Step ---
            # Nudge the population based on the pheromone trail
            for i in range(self.pop_size):
                nudge = (pheromone_trail / np.sum(pheromone_trail)) * (np.random.random(self.dims) - 0.5) * 0.1
                population[i] += nudge

            # --- 2. Particle Swarm Optimization (PSO) Step ---
            inertia = 0.9 - 0.5 * (iteration / self.iterations)
            r1, r2 = np.random.random((2, self.pop_size, self.dims))
            velocities = inertia * velocities + 1.5 * r1 * (personal_best - population) + 1.5 * r2 * (global_best - population)
            population += velocities

            # --- 3. Genetic Algorithm (GA) Step ---
            for i in range(self.pop_size):
                if np.random.rand() < 0.8: # Crossover
                    p1, p2 = population[np.random.choice(self.pop_size, 2, replace=False)]
                    crossover_point = np.random.randint(1, self.dims)
                    population[i] = np.concatenate([p1[:crossover_point], p2[crossover_point:]])
                if np.random.rand() < 0.1: # Mutation
                    mutation_strength = (1 - iteration / self.iterations) * 0.5
                    population[i, np.random.randint(self.dims)] += np.random.uniform(-mutation_strength, mutation_strength)

            # --- 4. Bee Algorithm (BA) Step ---
            # Local search around elite solutions (employed/onlooker bees)
            elite_indices = np.argsort(population_values)[-self.n_elite_bees:]
            for idx in elite_indices:
                for _ in range(self.n_local_searches):
                    local_search_point = population[idx] + np.random.uniform(-0.05, 0.05, self.dims)
                    local_search_point = self._repair_solution(local_search_point)
                    local_fidelity = self._calculate_fidelity(local_search_point)
                    if local_fidelity > population_values[idx]:
                        population[idx] = local_search_point
                        population_values[idx] = local_fidelity
                        stagnation_counters[idx] = 0 # Reset stagnation
            
            # Replace stagnated solutions (scout bees)
            for i in range(self.pop_size):
                if stagnation_counters[i] > self.stagnation_limit:
                    population[i] = np.random.uniform([b[0] for b in self.bounds], [b[1] for b in self.bounds])
                    stagnation_counters[i] = 0

            # --- Evaluation and Updates ---
            for i in range(self.pop_size):
                population[i] = self._repair_solution(population[i])
                new_fidelity = self._calculate_fidelity(population[i])
                
                if new_fidelity > population_values[i]:
                    stagnation_counters[i] = 0
                else:
                    stagnation_counters[i] += 1
                population_values[i] = new_fidelity

                if new_fidelity > personal_best_values[i]:
                    personal_best[i], personal_best_values[i] = population[i], new_fidelity

            # Update global best
            global_best_idx = np.argmax(personal_best_values)
            global_best = personal_best[global_best_idx]
            current_best_fidelity = personal_best_values[global_best_idx]
            
            # Update ACO pheromone trail
            pheromone_trail *= (1 - self.pheromone_decay) # Evaporation
            pheromone_trail += self.pheromone_strength * np.abs(global_best) # Deposition
            
            # Store progress
            fidelity_progress.append(current_best_fidelity)
            parameter_progress.append(np.copy(global_best))

            print(f"Iteration {iteration + 1}/{self.iterations}: Best Fidelity = {current_best_fidelity:.6f}")

            if iteration > 10 and np.std(fidelity_progress[-10:]) < 1e-6:
                print("Convergence reached.")
                break
        
        print("\nOptimization Finished.")
        print(f"Best Solution Found: {global_best}")
        print(f"Best Fidelity Achieved: {np.max(personal_best_values):.6f}")

        # --- Plotting Results ---
        plt.figure(figsize=(12, 6))
        plt.plot(range(1, len(fidelity_progress) + 1), fidelity_progress, label="Best Fidelity", marker=".", linestyle="-", color="blue")
        plt.xlabel("Iteration")
        plt.ylabel("Best Fidelity")
        plt.title("Module 3: Full Hybrid Optimization Progress")
        plt.legend()
        plt.grid(True)
        plt.show()

        plt.figure(figsize=(12, 6))
        parameter_progress_array = np.array(parameter_progress)
        for i in range(self.dims):
            plt.plot(range(1, len(parameter_progress_array) + 1), parameter_progress_array[:, i], label=f'Parameter θ{i}', marker='.')
        plt.xlabel("Iteration")
        plt.ylabel("Parameter Value (Radians)")
        plt.title("Evolution of Optimized Circuit Parameters")
        plt.legend()
        plt.grid(True)
        plt.show()

        self._run_sensitivity_analysis(global_best)

if __name__ == '__main__':
    optimizer = HybridOptimizer()
    optimizer.run_optimization()
