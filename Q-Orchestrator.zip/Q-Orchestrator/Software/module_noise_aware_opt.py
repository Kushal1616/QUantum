# module_noise_aware_opt.py
# Author: Kushal Anjaria
# Date: 2025-07-26
# Location: Anand, Gujarat, India
# Description: Module 2 of the framework. Demonstrates noise mitigation techniques
#              with a physically-enforced ZNE result.

import pennylane as qml
from pennylane import numpy as np
import matplotlib.pyplot as plt

class NoiseAwareOptimizer:
    """
    Encapsulates noise-aware optimization techniques like ZNE and
    circuit depth optimization, based on the original step2.py.
    """
    def __init__(self, shots=1000):
        """Initializes the noisy quantum device."""
        self.dev_noisy = qml.device("default.mixed", wires=4, shots=shots)

    def _scaled_circuit(self, scale_factor):
        """Creates a scaled version of the noisy circuit for ZNE."""
        @qml.qnode(self.dev_noisy)
        def circuit_with_scaled_noise():
            qml.Hadamard(wires=0)
            qml.CNOT(wires=[0, 1])
            qml.DepolarizingChannel(p=0.01 * scale_factor, wires=0)
            qml.AmplitudeDamping(gamma=0.1 * scale_factor, wires=1)
            qml.CNOT(wires=[0, 2])
            qml.CNOT(wires=[1, 3])
            qml.DepolarizingChannel(p=0.1 * scale_factor, wires=2)
            qml.DepolarizingChannel(p=0.2 * scale_factor, wires=3)
            return qml.expval(qml.PauliZ(0) @ qml.PauliZ(1))
        return circuit_with_scaled_noise()

    def _zero_noise_extrapolation(self, scale_factors):
        """Performs ZNE and returns the extrapolated result."""
        results = [self._scaled_circuit(scale) for scale in scale_factors]
        # Linear extrapolation to estimate zero-noise limit
        fit_coeffs = np.polyfit(scale_factors, results, deg=1)
        estimated_result = fit_coeffs[-1] # The y-intercept

        # --- MODIFICATION: Enforce the physical boundary ---
        # This clamps the extrapolated value to a maximum of 1.0, preventing
        # unphysical results from linear "overshooting".
        estimated_result = min(estimated_result, 1.0)
        # --- END OF MODIFICATION ---

        # Plotting
        plt.figure(figsize=(10, 6))
        plt.plot(scale_factors, results, 'o-', color='blue', label="Measured Expectation Values")
        # The linear fit line might still show an overshoot, but the final reported value will be correct.
        plt.plot(np.insert(scale_factors, 0, 0), np.polyval(fit_coeffs, np.insert(scale_factors, 0, 0)), 'r--', label=f"Linear Fit")
        plt.axhline(y=estimated_result, color='red', linestyle=':', label=f"Extrapolated Zero-Noise: {estimated_result:.4f}")
        plt.xlabel("Noise Scale Factor")
        plt.ylabel("Expectation Value ⟨Z₀Z₁⟩")
        plt.title("Zero-Noise Extrapolation (ZNE) Trend")
        plt.legend()
        plt.grid(True)
        plt.show()

        return estimated_result

    def run_and_visualize(self):
        """Runs all mitigation techniques and compares them."""
        # 1. Original noisy expectation
        @qml.qnode(self.dev_noisy)
        def noisy_expectation():
            qml.Hadamard(wires=0)
            qml.CNOT(wires=[0, 1])
            qml.DepolarizingChannel(p=0.01, wires=0)
            qml.AmplitudeDamping(gamma=0.1, wires=1)
            qml.CNOT(wires=[0, 2])
            qml.CNOT(wires=[1, 3])
            qml.DepolarizingChannel(p=0.1, wires=2)
            qml.DepolarizingChannel(p=0.2, wires=3)
            return qml.expval(qml.PauliZ(0) @ qml.PauliZ(1))
        original_result = noisy_expectation()

        # 2. ZNE
        scale_factors = [1.0, 0.5, 0.1]
        zne_result = self._zero_noise_extrapolation(scale_factors)

        # 3. Depth Optimized
        @qml.qnode(self.dev_noisy)
        def optimized_circuit_depth():
            qml.Hadamard(wires=0)
            qml.CNOT(wires=[0, 1])
            # Noisy operations on primary qubits are removed
            qml.CNOT(wires=[0, 2])
            qml.CNOT(wires=[1, 3])
            qml.DepolarizingChannel(p=0.1, wires=2)
            qml.DepolarizingChannel(p=0.2, wires=3)
            return qml.expval(qml.PauliZ(0) @ qml.PauliZ(1))
        result_depth_optimized = optimized_circuit_depth()

        # Comparison Plot
        labels = ["Original Noisy", "ZNE Estimated", "Depth Optimized"]
        results = [original_result, zne_result, result_depth_optimized]
        plt.figure(figsize=(10, 6))
        bars = plt.bar(labels, results, color=['red', 'blue', 'green'], alpha=0.75)
        plt.ylabel("Expectation Value ⟨Z₀Z₁⟩")
        plt.title("Module 2: Comparison of Noise Mitigation Techniques")
        # Adjust y-axis limit to be slightly above 1.0 for better visualization
        plt.ylim(min(results) - 0.05, 1.05)
        for bar in bars:
            yval = bar.get_height()
            plt.text(bar.get_x() + bar.get_width()/2.0, yval, f'{yval:.4f}', va='bottom', ha='center')
        plt.show()

# This block allows the script to be run standalone for testing
if __name__ == '__main__':
    optimizer = NoiseAwareOptimizer()
    optimizer.run_and_visualize()
