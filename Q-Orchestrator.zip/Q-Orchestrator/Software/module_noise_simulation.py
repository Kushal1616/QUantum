# module_noise_simulation.py
# Author: Kushal Anjaria
# Date: 2025-07-25
# Location: Anand, Gujarat, India
# Description: Module 1 of the framework. Demonstrates the impact of noise.

import pennylane as qml
from pennylane import numpy as np
import matplotlib.pyplot as plt

class NoiseSimulator:
    """
    Encapsulates the logic for simulating and visualizing the effect of noise
    on a quantum circuit, based on the original step1.py.
    """
    def __init__(self, shots=1000):
        """Initializes the quantum devices."""
        self.dev_noisy = qml.device("default.mixed", wires=4, shots=shots)
        self.dev_ideal = qml.device("default.qubit", wires=2, shots=shots)

    def noisy_circuit(self):
        """Quantum circuit with noise modeling."""
        qml.Hadamard(wires=0)
        qml.CNOT(wires=[0, 1])
        qml.DepolarizingChannel(p=0.01, wires=0)
        qml.AmplitudeDamping(gamma=0.1, wires=1)
        qml.CNOT(wires=[0, 2])
        qml.CNOT(wires=[1, 3])
        qml.DepolarizingChannel(p=0.1, wires=2)
        qml.DepolarizingChannel(p=0.2, wires=3)
        return qml.probs(wires=[0, 1])

    def ideal_circuit(self):
        """Ideal quantum circuit without noise."""
        qml.Hadamard(wires=0)
        qml.CNOT(wires=[0, 1])
        return qml.probs(wires=[0, 1])

    def run_and_visualize(self):
        """Executes both circuits and plots the results."""
        # Create QNodes
        qnode_noisy = qml.QNode(self.noisy_circuit, self.dev_noisy)
        qnode_ideal = qml.QNode(self.ideal_circuit, self.dev_ideal)

        # Retrieve probabilities
        noisy_probs = qnode_noisy()
        ideal_probs = qnode_ideal()

        # Visualization
        labels = ["00", "01", "10", "11"]
        fig, ax = plt.subplots(1, 2, figsize=(12, 5))

        ax[0].bar(labels, ideal_probs, color='green', alpha=0.7)
        ax[0].set_title("Ideal Circuit Probability Distribution")
        ax[0].set_xlabel("Measured State")
        ax[0].set_ylabel("Probability")
        ax[0].set_ylim(0, 1)


        ax[1].bar(labels, noisy_probs, color='red', alpha=0.7)
        ax[1].set_title("Noisy Circuit Probability Distribution")
        ax[1].set_xlabel("Measured State")
        ax[1].set_ylabel("Probability")
        ax[1].set_ylim(0, 1)

        plt.suptitle("Module 1: Impact of Noise on Quantum Circuit")
        plt.tight_layout(rect=[0, 0.03, 1, 0.95])
        plt.show()

# This block allows the script to be run standalone for testing
if __name__ == '__main__':
    simulator = NoiseSimulator()
    simulator.run_and_visualize()
