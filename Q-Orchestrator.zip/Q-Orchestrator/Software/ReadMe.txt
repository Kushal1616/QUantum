Quantum Optimization Framework
Author: Kushal Anjaria

Date: July 2025

Location: Anand, Gujarat, India

1. Overview
This framework is a Python-based simulation environment for exploring and evaluating advanced optimization techniques for noisy quantum circuits. It provides a modular approach to:

Visualize the impact of noise on quantum computations.

Apply and assess noise mitigation techniques like Zero-Noise Extrapolation (ZNE).

Implement and test a novel hybrid optimization algorithm that combines Ant Colony Optimization (ACO), Particle Swarm Optimization (PSO), Genetic Algorithms (GA), and the Bee Algorithm (BA) to find robust quantum circuit parameters.

The project is structured into distinct modules, each focusing on a specific aspect of the optimization workflow. The main orchestrator.py script provides a command-line interface to run each module independently or all of them in sequence.

2. Requirements
To run this framework, you need Python 3 and the following libraries:

PennyLane: For quantum circuit simulation and automatic differentiation.

NumPy: For numerical operations.

Matplotlib: For plotting and data visualization.

SciPy: For scientific computing utilities (specifically sqrtm).

You can install these dependencies using pip:

pip install pennylane numpy matplotlib scipy

3. How to Run
The main entry point for the framework is orchestrator.py. To run the application, navigate to the project directory in your terminal and execute the script:

python orchestrator.py

This will launch an interactive menu in the console:

--- Quantum Optimization Framework ---
Select a module to run:
  1. Noise Simulation (Demonstrates noise impact)
  2. Noise-Aware Optimization (ZNE & Depth Optimization)
  3. Full Hybrid Optimization (ACO, PSO, GA, BA)
  4. Run All Modules Sequentially
  0. Exit
------------------------------------
Enter your choice (0-4):

Simply enter the number corresponding to the module you wish to run and press Enter. The script will execute the selected module and display the results, including plots for visualization.

4. Project Structure and Modules
The framework is organized into the following Python files:

orchestrator.py
Purpose: The main controller of the framework.

Functionality: It initializes all modules and provides a user-friendly command-line interface (CLI) to select and run the different simulations.

module_noise_simulation.py
Module 1: Noise Simulation

Purpose: To demonstrate the fundamental impact of noise on a quantum circuit's output.

Functionality: It runs a simple quantum circuit in two modes: an ideal, noise-free simulation and a noisy simulation (incorporating depolarizing and amplitude damping channels). It then plots the resulting probability distributions side-by-side for comparison.

module_noise_aware_opt.py
Module 2: Noise-Aware Optimization

Purpose: To showcase common noise mitigation strategies.

Functionality: This module implements and compares:

A baseline noisy circuit execution.

Zero-Noise Extrapolation (ZNE): A technique where the noise is intentionally scaled at different levels, and the results are extrapolated back to the zero-noise limit. This implementation includes a physical constraint to prevent unphysical results.

Circuit Depth Optimization: A simplified approach where noisy gates are rearranged or removed to lessen their impact on the final measurement.

The results are visualized in a bar chart for easy comparison.

module_hybrid_opt.py
Module 3 & 4: Full Hybrid Optimization & Evaluation

Purpose: To implement a novel, sophisticated hybrid optimization algorithm designed to find robust parameters for a quantum circuit in the presence of noise.

Functionality: This is the core of the research framework. It integrates four metaheuristic algorithms into a single, cohesive optimizer:

Ant Colony Optimization (ACO): Guides the search using pheromone trails.

Particle Swarm Optimization (PSO): Explores the parameter space using a population of particles influenced by personal and global bests.

Genetic Algorithm (GA): Evolves solutions through crossover and mutation.

Bee Algorithm (BA): Performs local and global searches inspired by the foraging behavior of honey bees.

The module's goal is to maximize the fidelity of a noisy quantum circuit. It includes progress plots for fidelity and parameter evolution, and concludes with a sensitivity analysis to evaluate the robustness of the final solution.